
package TP1.Model.Modulos.Calendario.Intervalos;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;

/**
 * Descreve um conjunto iterável de datas do tipo LocalDate
 */
public interface IntervaloInterface extends Iterable<LocalDate> {

    /**
     * Recebe um objeto e compara-o com um objeto que implemente esta Interface
     *
     * @param obj
     * @return
     */
    @Override
    public boolean equals(Object obj);

    /**
     * Devolve a data de fim desta instância do intervalo
     *
     * @return data fim
     */
    public LocalDate getDataFim();

    /**
     * Devolve a data de inicio desta instância do intervalo
     *
     * @return data inicio
     */
    public LocalDate getDataInicio();

    /**
     * hashCode, devolve um codigo hash para um objeto que implemente esta Interface
     *
     * @return codigo hash
     */
    @Override
    public int hashCode();

    /**
     * Devolve um iterador desta instância de intervalo de datas
     *
     * @return iterador
     */
    @Override
    public Iterator<LocalDate> iterator();

    /**
     * Devolve um stream do intervalo de datas relativo a esta instância
     *
     * @return stream
     */
    public Stream<LocalDate> stream();

    /**
     * Devolve uma lista com todas as datas no intervalo desta instância
     *
     * @return lista
     */
    public List<LocalDate> toList();

    /**
     * Devolve uma lista com todas as datas no intervalo desta instância em formato de String
     *
     * @return lista
     */
    public List<String> toListToString();
    
}
