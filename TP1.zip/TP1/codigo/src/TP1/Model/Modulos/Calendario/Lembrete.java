

package TP1.Model.Modulos.Calendario;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Objects;

/**
 * 
 *
 * Esta classe representa um Lembrete e implementa a Interface
 * LembreteInterface.
 * 
 * Este Lembrete contém os seguintes campos exigidos pela interface:
 * 1) String nome, 2) String descrição, 3) LocalDate dia, 4) LocalTime hora,
 * 5) int ID.
 * 
 * deve-se ter o cuidado de usar o método clone sempre que um objeto
 * desta classe for consultado.
 * 
 * Pode ser colonado e serializado.
 * 
 */
public class Lembrete implements LembreteInterface, Serializable{

    
    /**
     * ID do lembrete
     */
    private int       ID;
    
    /**
     * Nome do lembrete
     */
    private String    nome;
    
    /**
     * Descricao do lembrete
     */
    private String    descricao;
    
    /**
     * Hora do lembrete (HH:mm)
     */
    private LocalTime hora;
    
    /**
     * Dia do lembrete (uuuu-MM-dd)
     */
    private LocalDate dia;

    /**
     * Construtor parameterizado, recebe todos os campos
     * e preenche-os. Apenas não recebe o ID que é inicializado a -1.
     * 
     * @param nome
     * @param descricao
     * @param hora
     * @param dia 
     */
    public Lembrete(String nome, String descricao, LocalTime hora, LocalDate dia) {
        this.nome      = nome;
        this.descricao = descricao;
        this.hora      = hora;
        this.dia       = dia;
        this.ID        = -1;
    }

    /**
     * Construtor de cópia
     * 
     * Recebe um outro lembrete epreenche os seus campos com os do
     * lembrete argumento
     * 
     * @param l 
     */
    public Lembrete(Lembrete l) {
        this.nome      = l.getNome();
        this.descricao = l.getDescricao();
        this.hora      = l.getHora();
        this.dia       = l.getDia();
        this.ID        = l.getID();
    }

    /**
     * @return ID do lembrete
     */
    @Override
    public int getID() {
        return ID;
    }
    
    /**
     * Modifica o ID do lembrete.
     * Caso o ID seja menor que 0 é ignorado e nada é feito.
     * 
     * @param ID 
     */
    @Override
    public void setID(int ID) {
        if (ID>=0) this.ID = ID;
    }

    
    /**
     * @return nome do lembrete
     */
    @Override
    public String getNome() {
        return nome;
    }

    /**
     * @return descricao do lembrete
     */
    @Override
    public String getDescricao() {
        return descricao;
    }

    /**
     * @return hora do lembrete
     */
    @Override
    public LocalTime getHora() {
        return hora;
    }

    /**
     * @return dia do lembrete
     */
    @Override
    public LocalDate getDia() {
        return dia;
    }

    
    
    /**
     * 
     * @return Representacao do lembrete em forma de String 
     */
    @Override
    public String toString() {
        return "ID: " + ID + "; " + nome + "; " + LocalDateTime.of(dia,hora);
    }

    /**
     * 
     * @return codigo hash 
     */
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + Objects.hashCode(this.nome);
        hash = 59 * hash + Objects.hashCode(this.descricao);
        hash = 59 * hash + Objects.hashCode(this.hora);
        hash = 59 * hash + Objects.hashCode(this.dia);
        return hash;
    }

    /**
     * método equals
     * 
     * @param obj
     * @return True se obj for igual a this e false caso contrário 
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Lembrete other = (Lembrete) obj;
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        if (!Objects.equals(this.hora, other.hora)) {
            return false;
        }
        return Objects.equals(this.dia, other.dia);
    }
    
    /**
     * Colona este lembrete
     * 
     * @return o novo Lembrete colonado 
     */
    @Override
    public Lembrete clone(){
        return new Lembrete(this);
    }

    /**
     * modifica o nome
     * 
     * @param nome
     */
    @Override
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * modifica a descricao
     * 
     * @param descricao
     */
    @Override
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    /**
     * modifica a hora
     * 
     * @param hora
     */
    @Override
    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    /**
     * modifica o dia
     * 
     * @param dia
     */
    @Override
    public void setDia(LocalDate dia) {
        this.dia = dia;
    }
    
}
