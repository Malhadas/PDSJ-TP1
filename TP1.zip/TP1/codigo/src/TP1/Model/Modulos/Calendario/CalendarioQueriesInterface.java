
package TP1.Model.Modulos.Calendario;

import TP1.Main.MenusModos.MenuModoInterface.Modo;

/**
 *
 * Esta Interface caracteriz as queries existentes para um model
 * que a implemente
 */
public interface CalendarioQueriesInterface {
    /**
     * Modo do model que implemente esta interface
     */
    public static final Modo MODO = Modo.M4;
        
    /**
     * Enum que caracteriza as queries do model
     * que implemente esta Interface
     */
    public enum QuerieCalendario{
        INICIALIZAR, ADDICIONAR, ADDICIONAR_SISTEMATICO, APAGAR, 
        LISTARLEMBRETES, LISTARLEMBRETES_DATA, LISTARLEMBRETES_ENTREDATAS, 
        LISTARDATAS, QUANTORECEBO, LER, CONSULTAR
    }
}
