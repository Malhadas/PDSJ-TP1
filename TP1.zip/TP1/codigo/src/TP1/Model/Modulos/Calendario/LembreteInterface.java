package TP1.Model.Modulos.Calendario;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * Interface que descreve um Lembrete que deve
 * ter pelo menos os seguintes campos: 1) String nome,
 * 2) String descrição, 3) LocalDate dia, 4) LocalTime hora,
 * 5) int ID.
 * 
 * deve-se ter o cuidado de usar o método clone sempre que um objeto
 * de uma classe que implemente esta interface for consultado.
 * 
 * Pode ser colonado e serializado.
 * 
 */
public interface LembreteInterface extends Cloneable, Serializable {
    
    /**
     * Colona o Lembrete específico
     * 
     * @return o novo Lembrete 
     */
    public Lembrete clone();

    /**
     * Verifica se o obj argumento é igual
     * ao objecto em que o método for chamado
     * 
     * @param obj
     * @return True se for igual, False se for diferente
     */
    @Override
    public boolean equals(Object obj);

    /**
     * @return campo descricao
     */
    public String getDescricao();

    /**
     * @return campo dia
     */
    public LocalDate getDia();

    /**
     * @return campo hora
     */
    public LocalTime getHora();

    /**
     * @return campo nome
     */
    public String getNome();

    /**
     * 
     * @return campo ID
     */
    public int getID();
    
    /**
     * Modifica o campo ID com o
     * ID argumento
     * 
     * @param ID 
     */
    public void setID(int ID);

    @Override
    public int hashCode();

    /**
     * altera campo descrição
     * 
     * @param descricao
     */
    public void setDescricao(String descricao);

    /**
     * altera campo dia 
     * 
     * @param dia
     */
    public void setDia(LocalDate dia);

    /**
     * altera campo hora
     * 
     * @param hora
     */
    public void setHora(LocalTime hora);

    /**
     * Altera campo nome
     * 
     * @param nome
     */
    public void setNome(String nome);

    /**
     * 
     * @return representação do Lembrete sobre forma de String
     */
    @Override
    public String toString();
    
}
