
package TP1.Model.Modulos.Calendario;

import TP1.Exceptions.LembreteInexistenteException;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.List;

/**
 *
 * Interface que descreve um calendário e um Registo de Lembretes que devem
 * implementar a Interface LembreteInterface. Embora tal não seja
 * obrigatório é fortemente aconselhado, caso contrário haverá necessidade
 * de "converter" a representação do Lembrete usada para uma dessa
 * Interface já que há métodos nesta interface que recebem e
 * devolvem essa representação.
 * 
 */
public interface RegistoLembretesInterface {

    /**
     * Adiciona um lembrete l ao registo
     * 
     * @param l
     * @throws DateTimeException caso o lembrete não esteja nas datas definidas para o calendário 
     */
    public void adicionaLembrete(LembreteInterface l) throws DateTimeException;

    /**
     * Adiciona um lembrete l que deve
     * ser repetido para todas as datas contidas
     * 
     * @param l
     * @throws DateTimeException caso o lembrete não esteja nas datas definidas para o calendário 
     */
    public void adicionaLembreteSistematico(LembreteInterface l) throws DateTimeException;

    /**
     * 
     * @return data de fim do calendario
     */
    public LocalDate getDataFim();

    /**
     * 
     * @return data de início do calendário 
     */
    public LocalDate getDataInicio();

    /**
     * 
     * @return Lista da datas do calendário
     */
    public List<LocalDate> getListaDatas();

    /**
     * 
     * @param ld1
     * @param ld2
     * @return Lista de datas do calendário entre datas argumento
     */
    public List<LocalDate> getListaDatas(LocalDate ld1, LocalDate ld2);

    /**
     * 
     * @return Lista de datas do calendário sobre forma de String
     */
    public List<String> getListaDatasToString();

    /**
     * 
     * @param ld1
     * @param ld2
     * @return Lista de datas do calendário sobre forma de String entre as datas argumento
     */
    public List<String> getListaDatasToString(LocalDate ld1, LocalDate ld2);

    /**
     * 
     * @return Lista de Lembretes registados
     */
    public List<LembreteInterface> getListaLembretes();

    /**
     * 
     * @param ld1
     * @param ld2
     * @return Lista de Lembretes registados entre as datas argumento
     */
    public List<LembreteInterface> getListaLembretes(LocalDate ld1, LocalDate ld2);

    /**
     * 
     * @param ld
     * @return Lista de Lembretes registados na data argumento
     */
    public List<LembreteInterface> getListaLembretes(LocalDate ld);

    /**
     * 
     * @return Lista de lembretes registados sobre forma d eString
     */
    public List<String> getListaLembretesToString();

    /**
     * 
     * @param ld1
     * @param ld2
     * @return Lista de lembretes registados sobre forma de String entre duas datas argumento
     */
    public List<String> getListaLembretesToString(LocalDate ld1, LocalDate ld2);

    /**
     * 
     * @param ld
     * @return Lista de lembretes registados sobre forma de String na data argumento 
     */
    public List<String> getListaLembretesToString(LocalDate ld);

    /**
     * 
     * @return Lembretes inseridos desde a última vez que este método foi chamado
     */
    public int getInseridosDesdeUltimaVez();

    /**
     * Mudificar as datas do calendário para as datas
     * inicio e fim argumentos.
     * 
     * @param inicio
     * @param fim 
     */
    public void mudarDatas(LocalDate inicio, LocalDate fim);

    /**
     * Consulta o Conteudo do lembrete com ID argumento. 
     * 
     * @param id
     * @return
     * @throws LembreteInexistenteException caso o ID argumento não represente nenhum lembrete
     */    
    public Lembrete consultar(int id) throws LembreteInexistenteException;

    /**
     * Dado um dia de pagamento, um valor de pagamento e uma data de término
     * calcula o valor total que terá recebido. 
     * 
     * @param diaPagamento
     * @param pagamento
     * @param ate
     * @return Resultado do pagamento sistemático
     * @throws DateTimeException 
     */
    public double quantoTerei(int diaPagamento, double pagamento, LocalDate ate) throws DateTimeException;

    /**
     * Remove o lembrete com o id argumento.
     * 
     * @param id
     * @throws LembreteInexistenteException caso o id não seja relativo a nenhum lembrete inserido
     */
    public void removeLembrete(int id) throws LembreteInexistenteException;
    
}
