
package TP1.Model.Modulos.Calendario;

import TP1.Model.Modulos.Calendario.Intervalos.IntervaloDatas.IntervaloDatas;
import TP1.Exceptions.LembreteInexistenteException;
import TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries.FiltroEntreDatas;
import TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries.PagamentoSistematico;
import java.io.Serializable;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * Classe que implementa RegistoLembretesInterface e por isso apresenta
 * um calendário e um Registo de Lembretes que implementam a interface
 * LembreteInterface.
 * 
 */
public class RegistoLembretes implements RegistoLembretesInterface, Serializable {
    
    /**
     * Lista de lembretes registados
     */
    private List<LembreteInterface> lembretes;
    
    /**
     * Intervalo de datas do calendario
     */
    private IntervaloDatas datas;
    
    /**
     * Número de elementos inseridos desde que foi chamada o método
     * getInseridosDesdeUltimaVez()
     */
    private int inseridos;

    /**
     * Construtor vazio
     * 
     */
    public RegistoLembretes(){
        this.lembretes = new ArrayList<>();
        this.datas     = new IntervaloDatas();
        this.inseridos = 0;
    }
    
    /**
     * Construtor
     * 
     * recebe a data de inicio e de fim do calendario
     * 
     * @param inicio
     * @param fim 
     */
    public RegistoLembretes(LocalDate inicio, LocalDate fim){
        this.lembretes = new ArrayList<>();
        this.datas     = new IntervaloDatas(inicio,fim);
        this.inseridos = 0;
    }
    
    /**
     * Recebe a data de fim e de inicio do calendario e uam
     * collection de lembretes.
     * 
     * Apenas insere os lembretes que estiverem entre as datas argumento
     * 
     * @param inicio
     * @param fim
     * @param lembretes 
     */
    public RegistoLembretes(LocalDate inicio, LocalDate fim, Collection<Lembrete> lembretes){
        this.lembretes = new ArrayList<>(lembretes.size());
        lembretes.stream()
                 .filter(a -> a.getDia().isAfter(inicio) && a.getDia().isBefore(fim))
                 .forEach(a -> this.lembretes.add(a.clone()));
        this.datas     = new IntervaloDatas(inicio,fim);
        this.inseridos = 0;
    }
    
    /**
     * Construtor de cópia
     * 
     * Preenche os campos da classe com os campos do RegistoLembretes argumento
     * 
     * @param rl 
     */
    public RegistoLembretes(RegistoLembretes rl){
        this.datas = new IntervaloDatas(rl.getDataInicio(),
                                        rl.getDataFim());
        this.lembretes = rl.getListaLembretes();
        this.inseridos = 0;
    }
    
    /**
     * 
     * adiciona o lembrete argumento aos registos
     * 
     * @param l
     * @throws DateTimeException caso a data do Lembrete não esteja dentro das datas do calendário
     */
    @Override
    public void adicionaLembrete(LembreteInterface l) throws DateTimeException{
        if (l.getDia().isBefore(this.getDataInicio()))
            throw new DateTimeException(l.getDia() + "<" + this.getDataInicio());
        if (l.getDia().isAfter(this.getDataFim()))
            throw new DateTimeException(l.getDia() + ">" + this.getDataFim());
        
        l.setID(this.lembretes.size());
        this.lembretes.add(l.clone());
        
        this.inseridos++;
    }
    
    /**
     * 
     * @return número de lembretes inseridos desde a última vez que
     * este método foi chamado (remoções de lembretes retiram a este valor
     * nunca descendo abaixo de 0)
     * 
     */
    @Override
    public int getInseridosDesdeUltimaVez(){
        int temp = this.inseridos;
        this.inseridos = 0;
        return temp;
    }
    
    /**
     * Adiciona um lembrete sistemático. Isto é, um lembrete
     * que se repete todos os dias à mesma hora desde a sua data
     * até à data final do calendário
     * 
     * @param l
     * @throws DateTimeException se a data do lembrete não está contida nas datas que caracterizam o calendário
     */
    @Override
    public void adicionaLembreteSistematico(LembreteInterface l) throws DateTimeException{
        LocalDate inicio;
        if (l.getDia().isAfter(this.getDataFim()))
            throw new DateTimeException(l.getDia() + ">" + this.getDataFim());
        if (l.getDia().isBefore(this.getDataInicio())) inicio = this.getDataInicio();
        else inicio = l.getDia();
        
        IntervaloDatas id = new IntervaloDatas(inicio, this.getDataFim());
        id.stream().forEach(a -> {
                    l.setDia(a);
                    this.adicionaLembrete(l);
                });
    }

    /**
     * Calcula o resultado de um pagamento sistemático.
     * 
     * Calcula o valor pago na data ate começando em LocalDate.now()
     * 
     * quando o dia do pagamento é maior que o maior dia do mês este ocorre
     * no último dia do mês.
     * 
     * quando o dia do pagamento calha a um fim de semana este ocorre na sexta-feira
     * anterior.
     * 
     * @param diaPagamento
     * @param pagamento
     * @param ate
     * @return
     * @throws DateTimeException 
     */
    @Override
    public double quantoTerei(int diaPagamento, double pagamento, LocalDate ate) throws DateTimeException{
        LocalDate fim;
        
        if(ate.isAfter(this.getDataFim())) fim = this.getDataFim();
        else fim = ate;
        
        return fim.query(new PagamentoSistematico(diaPagamento, pagamento));
    }
    
    /**
     * Remove o lembrete de id argumento.
     * 
     * O id de todos os lembretes posteriores é subtraido de forma a
     * evitar "saltos" nos ID's
     * 
     * @param id
     * @throws LembreteInexistenteException quando não existe um lembrete com o id argumento
     */
    @Override
    public void removeLembrete(int id) throws LembreteInexistenteException{
        if (id < 0                      || 
            id >= this.lembretes.size() || 
                  this.lembretes.isEmpty()
           ) throw new LembreteInexistenteException();
        
        this.lembretes.remove(id);
        
        this.lembretes.forEach(a -> {
                          if (a.getID()>id)
                              a.setID(a.getID()-1);
                      });
        
        if (this.inseridos>0) this.inseridos--;
    }

    /**
     * Consultar lembrete de id argumento
     * 
     * @param id
     * @return o Lembrete com o id argumento
     * @throws LembreteInexistenteException Se não existir um lembrete com o id argumento
     */
    @Override
    public Lembrete consultar(int id) throws LembreteInexistenteException{
        if (id < 0                      || 
            id >= this.lembretes.size() || 
                  this.lembretes.isEmpty()
           ) throw new LembreteInexistenteException();
        
        return this.lembretes.get(id).clone();
    }


    /**
     * 
     * @return data de inicio do calendario 
     */
    @Override
    public LocalDate getDataInicio() {
        return this.datas.getDataInicio();
    }
    
    /**
     * 
     * @return data de fim do calendario
     */
    @Override
    public LocalDate getDataFim() {
        return this.datas.getDataFim();
    }

    /**
     * 
     * @return Lista de lembretes registados
     */
    @Override
    public List<LembreteInterface> getListaLembretes() {
        return this.lembretes.stream()
                             .map(a -> a.clone())
                             .collect(Collectors.toList());
    }
    
    /**
     * 
     * @param ld1
     * @param ld2
     * @return Lista de lembretes registados entre as datas argumento
     */
    @Override
    public List<LembreteInterface> getListaLembretes(LocalDate ld1, LocalDate ld2) {
        return this.lembretes.stream()
                             .filter(a -> a.getDia().query(new FiltroEntreDatas(ld1,ld2)))
                             .collect(Collectors.toList());
    }

    /**
     * 
     * @param ld
     * @return Lista de lembretes registados na data argumento
     */
    @Override
    public List<LembreteInterface> getListaLembretes(LocalDate ld) {
        return this.lembretes.stream()
                             .filter(a -> a.getDia().equals(ld))
                             .map(a -> a.clone())
                             .collect(Collectors.toList());
    }

    /**
     * 
     * @return Lista de lembretes em forma de String 
     */
    @Override
    public List<String> getListaLembretesToString() {
        return this.lembretes.stream()
                             .map(a -> a.clone().toString())
                             .collect(Collectors.toList());
    }

    /**
     * 
     * @param ld1
     * @param ld2
     * @return Lista de lembretes registados entre as datas argumento em formato String
     */
    @Override
    public List<String> getListaLembretesToString(LocalDate ld1, LocalDate ld2) {
        return this.lembretes.stream()
                             .filter(a -> a.getDia().query(new FiltroEntreDatas(ld1,ld2)))
                             .map(a -> a.toString())
                             .collect(Collectors.toList());
    }

    /**
     * 
     * @param ld
     * @return Lista de lembretes registados na data argumento em formato String 
     */
    @Override
    public List<String> getListaLembretesToString(LocalDate ld) {
        return this.lembretes.stream()
                             .filter(a -> a.getDia().equals(ld))
                             .map(a -> a.toString())
                             .collect(Collectors.toList());
    }

    /**
     * 
     * @return Lista de datas no calendário
     */
    @Override
    public List<LocalDate> getListaDatas() {
        return this.datas.toList();
    }
    
    /**
     * 
     * @return Lista de datas no calendário em formato String
     */
    @Override
    public List<String> getListaDatasToString() {
        return this.datas.toListToString();
    }

    /**
     * 
     * @param ld1
     * @param ld2
     * @return Lista de datas no calendário entre as datas argumento
     */
    @Override
    public List<LocalDate> getListaDatas(LocalDate ld1, LocalDate ld2) {
        return this.datas.stream()
                         .filter(a -> a.query(new FiltroEntreDatas(ld1,ld2)))
                         .collect(Collectors.toList());
    }
    

    /**
     * 
     * @param ld1
     * @param ld2
     * @return Lista de datas no calendário entre as datas argumento no formato String
     */
    @Override
    public List<String> getListaDatasToString(LocalDate ld1, LocalDate ld2) {
        return this.datas.stream()
                         .filter(a -> a.query(new FiltroEntreDatas(ld1,ld2)))
                         .map(a -> a.toString())
                         .collect(Collectors.toList());
    }
    
    /**
     * Redefine datas do calendario com as datas argumento.
     * 
     * @param inicio
     * @param fim 
     */
    @Override
    public void mudarDatas(LocalDate inicio, LocalDate fim){        
        Collection<LembreteInterface> temp;
        int i = 0;
        
        temp = this.lembretes.stream()
                             .filter( a -> (a.getDia().query(new FiltroEntreDatas(inicio,fim))))
                             .collect(Collectors.toList());
                                                          
        this.lembretes = new ArrayList<>(temp.size());
        
        for (LembreteInterface l : temp){
            l.setID(i);
            this.lembretes.add(l);
            i++;   
        }
        
        this.datas     = new IntervaloDatas(inicio,fim);
        this.inseridos = 0;
    }
    
}
