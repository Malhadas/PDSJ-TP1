
package TP1.Model.Modulos.Calendario;

import TP1.Controler.Controler;
import TP1.Exceptions.LembreteInexistenteException;
import TP1.Exceptions.QuerieInvalidaException;
import TP1.Exceptions.ResultadoInvalidoException;
import TP1.Model.Model;
import TP1.Model.Modulos.AuxiliaresModulos.FormatacaoDeDatas;
import TP1.Utils.ApresentacaoListada.ApresentacaoInterface;
import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import java.io.Serializable;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Model que encapsula o estado e realiza queries do modo 4
 * 
 * É responsável pelo modo do calendario
 */
public class CalendarioModel implements Serializable, Model, CalendarioQueriesInterface, Cloneable{
    
    /**
     * Registo de lembretes
     */
    RegistoLembretesInterface rv;
    
    /**
     * Strings que indicam a representacao textual da informação das
     * datas do calendario
     */
    String diaAno, bissexto, naoBissexto;
    
    /**
     * Construtor que recebe a data de inicio e fim do calendario
     * 
     * @param inicio
     * @param fim 
     */
    public CalendarioModel(LocalDate inicio, LocalDate fim){
        this.rv = new RegistoLembretes(inicio, fim);
        diaAno = bissexto = naoBissexto = "";
        
    }
    
    /**
     * Construtor que recebe a data de inicio e fim do calendario e
     * 3 strings que indicam como deve ser mencionadas as informações sobre
     * datas do calendário
     * 
     * @param inicio
     * @param fim
     * @param diaAno
     * @param bissexto
     * @param naoBissexto 
     */
    public CalendarioModel(LocalDate inicio, LocalDate fim, String diaAno, String bissexto, String naoBissexto){
        this.rv = new RegistoLembretes(inicio, fim);
        this.diaAno      = diaAno;
        this.bissexto    = bissexto;
        this.naoBissexto = naoBissexto;
    }
    
    /**
     * Construtor que recebe a data de inicio e fim do calendario sobre forma de String
     * junto com o seu formato e 3 strings que indicam como deve ser mencionadas as informações sobre
     * datas do calendário
     * 
     * @param data1
     * @param formato1
     * @param data2
     * @param formato2
     * @param diaAno
     * @param bissexto
     * @param naoBissexto 
     */
    public CalendarioModel(String data1, String formato1, 
                           String data2, String formato2,
                           String diaAno, String bissexto, String naoBissexto){
        this.rv = new RegistoLembretes(FormatacaoDeDatas.stringParaDia(data1, formato1),
                                       FormatacaoDeDatas.stringParaDia(data2, formato2));
        this.diaAno      = diaAno;
        this.bissexto    = bissexto;
        this.naoBissexto = naoBissexto;
    }
    
    /**
     * Construtor que recebe 3 strings que indicam como deve ser mencionadas as 
     * informações sobre datas do calendário
     * 
     * @param diaAno
     * @param bissexto
     * @param naoBissexto 
     */
    public CalendarioModel(String diaAno, String bissexto, String naoBissexto){
        this.rv          = new RegistoLembretes();
        this.diaAno      = diaAno;
        this.bissexto    = bissexto;
        this.naoBissexto = naoBissexto;
    }
    
    /**
     * 
     * realiza uma querie estando os tipos de querie possíveis representados no enum
     * QuerieCalendario na interface CalendarioQueriesInterface
     * 
     * este tuplo t é recebido apartir de um controler por isso o valor número
     * 0 deve ser ignorado já que era relativo ao tipo de pedido
     * 
     * o valor número 1 é então o tipo da querie
     * 
     * @param t
     * @return tuplo para controler enviar à view respetiva
     * @throws QuerieInvalidaException caso o tuplo t caracteriza uma querie que não existe
     * @throws ResultadoInvalidoException Caso o tuplo t tenha valores errados
     */
    @Override
    public Tuplo realizaQuerie(Tuplo t) throws QuerieInvalidaException, ResultadoInvalidoException {
        try {
            QuerieCalendario qm = t.getValor(1);
            
            switch(qm) {
                case ADDICIONAR:
                case ADDICIONAR_SISTEMATICO:
                    return querieAdd(t,qm);
                case APAGAR:
                    return querieRem(t);
                case CONSULTAR:
                    return querieConsultar(t);
                case LISTARLEMBRETES:
                case LISTARLEMBRETES_DATA:
                case LISTARLEMBRETES_ENTREDATAS:
                case LISTARDATAS:
                    return querieList(t,qm);
                case QUANTORECEBO:
                    return querieQuantoRecebo(t);
                case LER:
                    return querieLer(t);
                case INICIALIZAR:
                    return querieInicializar(t);
                default:
                    throw new QuerieInvalidaException();  
            }
        } catch (LembreteInexistenteException | DateTimeException ex) {
            throw new ResultadoInvalidoException(ex.toString());
        }
    }

    private Tuplo querieLer(Tuplo t){
        Collection<String> c = t.getValor(2);
            c.stream().forEach(s -> {
                String[] linha = s.split(";");
                try {
                    int sist = Integer.parseInt(linha[6]);
                    if(sist == 0)
                        rv.adicionaLembrete(new Lembrete(linha[0],linha[1],
                               FormatacaoDeDatas.stringParaHora(linha[2], linha[3]),
                               FormatacaoDeDatas.stringParaDia(linha[4], linha[5])));
                    if(sist == 1)
                        rv.adicionaLembreteSistematico(new Lembrete(linha[0],linha[1],
                               FormatacaoDeDatas.stringParaHora(linha[2], linha[3]),
                               FormatacaoDeDatas.stringParaDia(linha[4], linha[5])));
                } catch(DateTimeException | NumberFormatException | IndexOutOfBoundsException ex){
                    //nao adicionar esta viagem
                }
            });
           
            
            final TuploTipo tt = TuploTipo.DefaultFactory
                             .create(Number.class,Number.class,Number.class);
            return tt.criar(99,rv.getInseridosDesdeUltimaVez(),
                                     rv.getListaLembretes().size());
    }
    
    private Tuplo querieAdd(Tuplo t, QuerieCalendario qc) throws DateTimeParseException, DateTimeException{
        Lembrete l = new Lembrete(t.getValor(2), t.getValor(3),
                         FormatacaoDeDatas.stringParaHora(t.getValor(4), t.getValor(5)),
                         FormatacaoDeDatas.stringParaDia(t.getValor(6), t.getValor(7)));
        
        switch(qc){
            case ADDICIONAR:
                rv.adicionaLembrete(l);
                break;
            case ADDICIONAR_SISTEMATICO:
                rv.adicionaLembreteSistematico(l);
                break;       
        }

        final TuploTipo tt = TuploTipo.DefaultFactory.create(Number.class);
        return tt.criar(0);
    }
    
    private Tuplo querieRem(Tuplo t) throws LembreteInexistenteException{
        rv.removeLembrete(t.getValor(2));
        
        final TuploTipo tt = TuploTipo.DefaultFactory.create(Number.class);
        return tt.criar(51);
    }
    
    private Tuplo querieInicializar(Tuplo t) throws LembreteInexistenteException, DateTimeException{
        rv.mudarDatas(FormatacaoDeDatas.stringParaDia(t.getValor(2),t.getValor(3)),
                      FormatacaoDeDatas.stringParaDia(t.getValor(4),t.getValor(5)));
        
        final TuploTipo tt = TuploTipo.DefaultFactory.create(Number.class);
        return tt.criar(1);
    }
    
    private Tuplo querieConsultar(Tuplo t) throws LembreteInexistenteException{
        Lembrete l = rv.consultar(t.getValor(2));
        
        final TuploTipo tt = TuploTipo.DefaultFactory.create(Number.class, Number.class,
                                                             String.class, String.class,
                                                             String.class, String.class);
        return tt.criar(500, l.getID(), l.getNome(),l.getDescricao(),
                              l.getDia().toString(), l.getHora().toString());
    }
    
    
    private Tuplo querieQuantoRecebo(Tuplo t) throws DateTimeException{
        final TuploTipo tt = TuploTipo.DefaultFactory
                                      .create(Number.class,Number.class,Number.class,
                                              String.class, String.class, Number.class);
        
        LocalDate data = FormatacaoDeDatas.stringParaDia(t.getValor(4), 
                                                         t.getValor(5));
        
        double pagamento = rv.quantoTerei(t.getValor(3),t.getValor(2),data);
        
        return tt.criar(102,t.getValor(2), t.getValor(3),
                        LocalDate.now().toString(),  data.toString(), pagamento);
    }
    
    private Tuplo querieList(Tuplo t, QuerieCalendario qc) throws DateTimeException{
        final TuploTipo tt, req;
        final Tuplo ttesp;
        ApresentacaoInterface a;
        Collection<String> c = new ArrayList<>();
        Controler cont = t.getValor(2);

        req = TuploTipo.DefaultFactory.create(Controler.TipoPedido.class,Tuplo.class);
        tt = TuploTipo.DefaultFactory.create(Number.class, ApresentacaoInterface.class);

        switch(qc){
            case LISTARLEMBRETES:
                c  = rv.getListaLembretesToString();
                break;
            case LISTARLEMBRETES_DATA:
                c = rv.getListaLembretesToString(FormatacaoDeDatas.stringParaDia(t.getValor(3),t.getValor(4)));
                break;
            case LISTARLEMBRETES_ENTREDATAS:
                c = rv.getListaLembretesToString(FormatacaoDeDatas.stringParaDia(t.getValor(3),t.getValor(4)),
                                                 FormatacaoDeDatas.stringParaDia(t.getValor(5),t.getValor(6)));
                break;
            case LISTARDATAS:
                c = datasToStringPormenorizada(rv.getListaDatas());
                break;
        }
        a  = ApresentacaoInterface.DefaultFactory.create(c);
        ttesp = tt.criar(14, a);
        cont.realizaPedido(req.criar(Controler.TipoPedido.VIEW, ttesp));
        
        return null;
    }

    /**
     * metodo clone
     * 
     * @return 
     */
    @Override
    public Model clone() {
        return new CalendarioModel(rv.getDataInicio(),rv.getDataFim());
    }

    private Collection<String> datasToStringPormenorizada(List<LocalDate> listaDatas) {
        return listaDatas.stream()
                         .map(a -> a.toString()+"; "+
                                   a.getDayOfWeek()+"; "+
                                   diaAno+" "+a.getDayOfYear()+"; "+
                                   anoBissexto(a.isLeapYear()))
                         .collect(Collectors.toList());
    }

    private String anoBissexto(boolean leapYear) {
        if (leapYear) return this.bissexto;
        return this.naoBissexto;
    }
}
