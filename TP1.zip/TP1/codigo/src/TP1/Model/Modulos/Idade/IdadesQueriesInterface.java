
package TP1.Model.Modulos.Idade;

import TP1.Main.MenusModos.MenuModoInterface.Modo;
import static TP1.Main.MenusModos.MenuModoInterface.Modo.M2;


/**
 *
 * Esta Interface caracteriz as queries existentes para um model
 * que a implemente
 */
public interface IdadesQueriesInterface {
    /**
     * Modo do model que implemente esta Interface
     */
    public static final Modo MODO = M2;
    
    /**
     * Enum ue caracteriza as queries de um model que implemnete esta Interface
     */
    public enum QuerieIdade{
        QUEIDADE, QUANDOIDADE, QUANTOFALTA, MUDARZONA
    }
}
