
package TP1.Model.Modulos.Idade;

import TP1.Exceptions.QuerieInvalidaException;
import TP1.Exceptions.ResultadoInvalidoException;
import TP1.Main.ValoresFixos.IntervaloTempo;
import static TP1.Main.ValoresFixos.intervalotoString;
import TP1.Model.Model;
import TP1.Model.Modulos.AuxiliaresModulos.FormatacaoDeDatas;
import TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries.AteAniversario;
import TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries.DiferencaIdades;
import TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries.SomarUnidades;
import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import java.io.Serializable;
import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalQuery;

/**
 * Model que encapsula o estado e realiza queries do modo 2
 * 
 * É responsável pelo modo de idades
 */
public class IdadesModel implements Model, Serializable, IdadesQueriesInterface{
    
    /**
     * construtor vazio
     */
    public IdadesModel(){
    }
    
    /**
     * 
     * realiza uma querie estando os tipos de querie possíveis representados no enum
     * QuerieIdades na interface IdadesQueriesInterface
     * 
     * este tuplo t é recebido apartir de um controler por isso o valor número
     * 0 deve ser ignorado já que era relativo ao tipo de pedido
     * 
     * o valor número 1 é então o tipo da querie
     * 
     * @param t
     * @return tuplo para enviar à view respetiva pelo controler
     * @throws QuerieInvalidaException caso o tuplo t caracteriza uma querie que não existe
     * @throws ResultadoInvalidoException Caso o tuplo t tenha valores errados
     */
    @Override
    public Tuplo realizaQuerie(Tuplo t) throws QuerieInvalidaException, ResultadoInvalidoException {
        QuerieIdade qm = t.getValor(1);
        
        try {
            switch(qm) {
                case QUEIDADE:
                    return querie1(t);
                
                case QUANDOIDADE:
                    return querie2(t);
                
                case QUANTOFALTA:
                    return querie3(t);
                
                default:
                    throw new QuerieInvalidaException();
            }
        } catch(DateTimeException d){
            throw new ResultadoInvalidoException();
        }
    }

    private Tuplo querie1(Tuplo t)  throws DateTimeException{
        LocalDateTime l1, l2;
        l1 = FormatacaoDeDatas.stringParaData((String)t.getValor(2),
                                              (String)t.getValor(4));
        l2 = FormatacaoDeDatas.stringParaData((String)t.getValor(3),
                                              (String)t.getValor(5));

        final TuploTipo tt = TuploTipo.DefaultFactory
                     .create(Number.class, String.class, 
                             String.class, Number.class, String.class);

        TemporalQuery<Long> tq = new DiferencaIdades(l1, (IntervaloTempo) t.getValor(6));
        long l = l2.query(tq);
        
        return tt.criar(3,t.getValor(2), t.getValor(3),l,
                              intervalotoString((IntervaloTempo) t.getValor(6)));
    }

    private Tuplo querie2(Tuplo t)  throws DateTimeException{
        LocalDateTime l1,l2;
        l1 = FormatacaoDeDatas.stringParaData((String)t.getValor(2),
                                              (String)t.getValor(3));

        final TuploTipo tt = TuploTipo.DefaultFactory
                     .create(Number.class, String.class, Number.class, 
                             String.class, String.class);

        TemporalQuery<TemporalAccessor> tq = new SomarUnidades(t.getValor(4),
                                                              (IntervaloTempo) t.getValor(5));
        l2 = LocalDateTime.from(l1.query(tq));
        
        return tt.criar(2,t.getValor(2),t.getValor(4),l2.toString(),
                              intervalotoString((IntervaloTempo) t.getValor(5)));
    }

    private Tuplo querie3(Tuplo t) throws DateTimeException{
        LocalDateTime l1,l2; long p;
        final TuploTipo tt;
        
        tt = TuploTipo.DefaultFactory
                      .create(Number.class, String.class, String.class,
                              Number.class, String.class);
        
        l1 = FormatacaoDeDatas.stringParaData((String)t.getValor(2),
                                              (String)t.getValor(3));  
        
        TemporalQuery<Long> tq = new AteAniversario((IntervaloTempo) t.getValor(4));
        p = l1.query(tq);
        l2 = LocalDateTime.now();   
        
        return tt.criar(1,t.getValor(2),l2.toString(),p,
                              intervalotoString((IntervaloTempo) t.getValor(4)));
    }

    /**
     * metodo clone
     * 
     * @return 
     */
    @Override
    public Model clone() {
        return new IdadesModel();
    }

    
    
}
