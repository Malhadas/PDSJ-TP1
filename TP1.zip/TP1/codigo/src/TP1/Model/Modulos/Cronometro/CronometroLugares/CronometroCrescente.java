package TP1.Model.Modulos.Cronometro.CronometroLugares;

import TP1.Model.Modulos.Cronometro.Cronometro;
import TP1.Utils.ApresentacaoListada.ApresentacaoInterface;
import java.io.Serializable;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 
 * Cronometro crescente (conta o tempo a partir do zero até ser parado) 
 * que implementa a interface Cronometro e por isso é capaz de começar 
 * a contagem de tempo, parar, reiniciar e registar um ponto de paragem.
 * 
 * Tem precisão até aos milisegundos
 */
public class CronometroCrescente implements Cronometro, Serializable {
    
  /**
   * instante do inicio do cronometro
   */
  private Instant inicio;
  
  /**
   * instante em que se verifica a contagem do tempo
   */
  private Instant fim;
  
  /**
   * booleano que é true se o Cronometro estiver a correr
   * e false se tiver sido parado.
   */
  private boolean continuar;
  
  /**
   * Mapeamento entre o lugar de um ponto de paragem e
   * os milisegundos desde o começo da cronometragem
   */
  private final Map<Integer,Long> paragens;
  
  
  /**
   * Construtor vazio que inicializa o cronometro
   */
  public CronometroCrescente(){
      inicio    = Instant.now();
      paragens  = new HashMap<>();
      continuar = true;
  }
  
  /**
   * True caso o cronometro nao tenha siado parado
   * 
   * False se o cronómetro tiver sido parado
   * 
   * O método end() permite parar o cronómetro
   * 
   * @return True se ativo, False se inativo
   */
  @Override
  public boolean continuar(){
      return this.continuar;
  }
  
  /**
   * Reinicia o cronometro
   */
  @Override
  public void start() { 
      paragens.clear();
      inicio = Instant.now();
  }
  
/**
 * Marca um ponto de paragem
 */
  @Override
  public void stop() { 
      fim = Instant.now();
      long t =  Duration.between(inicio,fim).toMillis();
      paragens.put(paragens.size()+1, t);
  }
  
  /**
   * Para o cronometro
   * 
   * @return uma ApresentacaoInterface com os pontos de paragem marcados 
   */
  @Override
  public ApresentacaoInterface end(){
      this.continuar = false;
      
      List<String> l = new ArrayList<>(paragens.size());
      paragens.forEach((k, v) -> {
          StringBuilder r = new StringBuilder();
          r.append(v/(1E3)).
                  append("s:").
                  append(v).
                  append("ms");
          l.add(r.toString());
      });
      
      return ApresentacaoInterface.DefaultFactory.create(l);
  }
  
  /**
   * 
   * @return Representacao do cronometro em forma de String
   */
  @Override
  public String toString(){
      StringBuilder r = new StringBuilder();
   
      /*
      int i;
      for(i = 1; i <= paragens.size(); i++){
        long l = paragens.get(i);
        r.append("     | ").append(i).
                              append(" -> ").
                              append(l/(1E3)).
                              append("s:").
                              append(l).
                              append("ms\n");
      }
      */
      
      fim = Instant.now();
      long t =  Duration.between(inicio,fim).toMillis();
      r.append("     | ").append(t/(1E3)).
                            append("s:").
                            append(t).
                            append("ms, (").
                            append(paragens.size()).
                            append(')');
      
      return r.toString();
  }
  
}
