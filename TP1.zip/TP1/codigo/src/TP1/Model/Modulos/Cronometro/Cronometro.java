
package TP1.Model.Modulos.Cronometro;

import TP1.Utils.ApresentacaoListada.ApresentacaoInterface;

/**
 * 
 * Descreve um cronometro capaz de começar
 * a contagem de tempo, parar, reiniciar
 * e registar um ponto de paragem.
 * 
 */
public interface Cronometro {

    /**
     * Inicializa a contagem de tempo.
     * 
     * Pode ser usado para reiniciar o cronómetro.
     */
    public void start();
    
    /**
     * Marca um ponto de paragem
     */
    public void stop();
    
    /**
     * 
     * @return representação do cronómetro sobre forma de String 
     */
    @Override
    public String toString();

    /**
     * 
     * @return True se o cronómetro está em funcionamento, False se está parado
     */
    public boolean continuar();

    /**
     * 
     * @return Apresentacao Listada dos pontos de paragem marcados
     */
    public ApresentacaoInterface end();
}
