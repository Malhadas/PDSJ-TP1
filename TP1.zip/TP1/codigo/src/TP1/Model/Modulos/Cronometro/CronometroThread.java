
package TP1.Model.Modulos.Cronometro;

import TP1.Controler.Controler;
import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import java.io.Serializable;

/**
 * 
 * Implementa Runnable para definir uma Thread que observa o Cronometro
 * até que este termine. A cada meio segundo envia para uma view através de um
 * controler a representação em String do cronometro
 * 
 * 
 */
public class CronometroThread implements Serializable, Runnable{
    
    /**
     * Cronometro a observar
     */
    private final Cronometro c;
    
    /**
     * Controler para comunicação com a View
     */
    private final Controler cont;
    
    /**
     * Construtor
     * 
     * recebe o Cronometro a observar e o COntroler para
     * comunicação com a View
     * 
     * @param c
     * @param cont 
     */
    public CronometroThread(Cronometro c, Controler cont){
        this.c    = c;
        this.cont = cont;
    }
    
    /**
     * Metodo Run a ser invocado aquando da Invocação do método start() de
     * Thread.
     * 
     * Observa o Cronometro até que este termine. 
     * A cada meio segundo envia para uma view através de um
     * controler a representação em String do cronometro
     */
    @Override
    public void run() {
        final TuploTipo ttt = TuploTipo.DefaultFactory
                             .create(Number.class,String.class);
        final TuploTipo req = TuploTipo.DefaultFactory.create(Controler.TipoPedido.class,
                                                              Tuplo.class);
        while(c.continuar()){
            Tuplo tttesp = ttt.criar(16, c.toString());
            cont.realizaPedido(req.criar(Controler.TipoPedido.VIEW, tttesp));
            try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {}
        }
    }

}
