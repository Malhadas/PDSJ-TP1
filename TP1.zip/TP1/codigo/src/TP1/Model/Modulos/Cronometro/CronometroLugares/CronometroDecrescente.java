

package TP1.Model.Modulos.Cronometro.CronometroLugares;

import TP1.Model.Modulos.Cronometro.Cronometro;
import TP1.Utils.ApresentacaoListada.ApresentacaoInterface;
import java.io.Serializable;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 
 * Cronometro decrescente, temporizador (desde um certo valor até ao zero) 
 * que implementa a interface Cronometro e por isso é capaz de começar 
 * a contagem de tempo, parar, reiniciar e registar um ponto de paragem.
 * 
 * Tem precisão até aos milisegundos
 */
public class CronometroDecrescente implements Cronometro, Serializable {
    
  /**
   * Instante de início do cronometro
   */
  private Instant inicio;
  
  /**
   * instante em que se verifica a contagem do tempo
   */
  private Instant fim;
  
  /**
   * booleano que é true se o Cronometro estiver a correr
   * e false se tiver sido parado.
   */
  private boolean continuar;
  
  /**
   * milisegundos a temporizar
   */
  private final long milis;
  
  /**
   * Mapeamento entre o lugar de um ponto de paragem e
   * os milisegundos desde o começo da cronometragem
   */
  private final Map<Integer,Long> paragens;
  
  /**
   * Construtor que inicializa o cronometro e começa a temporizar
   * desde os milisegundos dados como argumento
   * 
   * @param milis 
   */
  public CronometroDecrescente(long milis){
      inicio    = Instant.now();
      paragens  = new HashMap<>();
      continuar = true;
      this.milis = milis;
  }
  
  /**
   * True caso os milisegundos fornecidos no construtor não tenham ainda terminado
   * e o cronometro nao tenha siado parado
   * 
   * False se o os milisegundos fornecidos no construtor já tiverem terminado ou
   * se o cronómetro tiver sido parado
   * 
   * O método end() permite parar o cronómetro
   * 
   * @return True se ativo, False se inativo
   */
  @Override
  public boolean continuar(){
      fim    = Instant.now();
      long t =  Duration.between(inicio,fim).toMillis();
      if (t > milis) this.continuar = false;
      return this.continuar;
  }
  
  /**
   * Reinicia o cronometro
   */
  @Override
  public void start() { 
      paragens.clear();
      inicio = Instant.now();
  }
  

  /**
   * Marca um ponto de paragem
   */
  @Override
  public void stop() { 
      fim = Instant.now();
      long t =  Duration.between(inicio,fim).toMillis();
      paragens.put(paragens.size()+1, (milis-t));
  }
  
  /**
   * Para o cronometro
   * 
   * @return uma ApresentacaoInterface com os pontos de paragem marcados 
   */
  @Override
  public ApresentacaoInterface end(){
      this.continuar = false;
      
      List<String> l = new ArrayList<>(paragens.size());
      paragens.forEach((k,v) -> {
          StringBuilder r = new StringBuilder();
          r.append(v/(1E3)).
            append("s:").
            append(v).
            append("ms");
          l.add(r.toString());
      });
      
      return ApresentacaoInterface.DefaultFactory.create(l);
  }
  
  /**
   * Representação textual do cronometro 
   * 
   * @return Representacao do cronometro em forma de String
   */
  @Override
  public String toString(){
      StringBuilder r = new StringBuilder();
   
      /*
      int i;
      for(i = 1; i <= paragens.size(); i++){
        long l = paragens.get(i);
        r.append("     | ").append(i).
                              append(" -> ").
                              append(l/(1E3)).
                              append("s:").
                              append(l).
                              append("ms\n");
      }
      */
      
      fim = Instant.now();
      long t =  Duration.between(inicio,fim).toMillis();
      if(milis-t > 0){
          r.append("     | ").append((milis-t)/(1E3)).
                            append("s:").
                            append((milis-t)).
                            append("ms, (").
                            append(paragens.size()).
                            append(')');
      }
      else{
          r.append("     | ")
           .append("0s:")
           .append("0ms, (")
           .append(paragens.size())
           .append(')');
      }
      return r.toString();
  }
  
}
