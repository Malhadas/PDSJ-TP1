
package TP1.Model.Modulos.Cronometro;

import TP1.Main.MenusModos.MenuModoInterface.Modo;
import static TP1.Main.MenusModos.MenuModoInterface.Modo.M1;


/**
 *
 * Esta Interface caracteriz as queries existentes para um model
 * que a implemente
 */
public interface CronometroQueriesInterface {
    /**
     * Modo do model que implemente esta interface
     */
    public static final Modo MODO = M1;
    
    /**
     * Enum ue caracteriza as queries de um model que implemnete esta Interface
     */
    public enum QuerieCronometro{
        START, STOP, END
    }
}
