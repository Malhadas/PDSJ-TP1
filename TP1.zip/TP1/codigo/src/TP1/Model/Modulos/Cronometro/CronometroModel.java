/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package TP1.Model.Modulos.Cronometro;

import TP1.Controler.Controler;
import TP1.Controler.Controler.TipoPedido;
import TP1.Exceptions.QuerieInvalidaException;
import TP1.Exceptions.ResultadoInvalidoException;
import TP1.Model.Model;
import TP1.Utils.ApresentacaoListada.ApresentacaoInterface;
import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import java.io.Serializable;

/**
 * Model que encapsula o estado e realiza queries do modo 1
 * 
 * É responsável pelo cronometro
 */
public class CronometroModel implements Serializable, Model, CronometroQueriesInterface{
    
    /**
     * cronometro
     */
    private final Cronometro c;
    
    /**
     * indica se o cronometro está parado (false) ou não (true)
     */
    private boolean started = false;
    
    /**
     * Construtor que recebe um cronometro c
     * 
     * @param c 
     */
    public CronometroModel(Cronometro c){
        this.c = c;
    }
    
    /**
     * 
     * realiza uma querie estando os tipos de querie possíveis representados no enum
     * QuerieCronometro na interface CronometroQueriesInterface
     * 
     * este tuplo t é recebido apartir de um controler por isso o valor número
     * 0 deve ser ignorado já que era relativo ao tipo de pedido
     * 
     * o valor número 1 é então o tipo da querie
     * 
     * @param t
     * @return tuplo para enviar pelo controler à view respetiva
     * @throws QuerieInvalidaException caso o tuplo t caracteriza uma querie que não existe
     * @throws ResultadoInvalidoException Caso o tuplo t tenha valores errados
     */
    @Override
    public Tuplo realizaQuerie(Tuplo t) throws QuerieInvalidaException, ResultadoInvalidoException {
        QuerieCronometro qm = t.getValor(1);
        switch(qm) {
            case START:
                if (!started) {
                    c.start();
                    Thread th = new Thread(new CronometroThread(c,
                                                                t.getValor(2)
                                                               ));
                    th.start();
                    
                    started = true;
                } else c.start();
                break;
            case STOP:
                c.stop();
                break;
            case END:
                final TuploTipo ttt = TuploTipo.DefaultFactory
                             .create(Number.class,ApresentacaoInterface.class);
                final TuploTipo req = TuploTipo.DefaultFactory.create(TipoPedido.class,
                                                                      Tuplo.class);
                Controler ap = t.getValor(2);
                Tuplo tttesp = ttt.criar(14, c.end());
                ap.realizaPedido(req.criar(TipoPedido.VIEW, tttesp));
                break;
        }
        
        return null;
    }

    /**
     * metodo clone 
     * 
     * @return 
     */
    @Override
    public Model clone() {
        return new CronometroModel(c);
    }

    
    
}
