

package TP1.Model.Modulos.AuxiliaresModulos;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.time.zone.ZoneRulesException;
import java.util.Locale;

/**
 * Classe que implementa métodos que permitem formatar datas
 * a partir de Strings
 */
public class FormatacaoDeDatas {

    
    /**
     * Converte um continente e uma cidade argumentos sobre forma
     * de String para um objeto ZoneId. Lança ZonaInvalidaException
     * caso seja fornecida uma zona argumento que a biblioteca não
     * conheça.
     * 
     * @param continente
     * @param cidade
     * @return zona convertida
     * @throws DateTimeException quando a data é inválida
     * @throws ZoneRulesException  caso seja fornecida uma zona argumento que a biblioteca não conheça
     */
    public static ZoneId stringParaRegiao(String continente, String cidade) throws DateTimeException, ZoneRulesException  {
        String zona = continente + "/" + cidade;
        return stringParaRegiao(zona);
    }
    
    /**
     * Converte um continente e uma cidade sobre a forma de uma só
     * String separada pelo caracter '/' para um objeto ZoneId. 
     * Lança ZonaInvalidaException caso seja fornecida uma zona 
     * argumento que a biblioteca não conheça.
     * 
     * @param zona
     * @return zona
     * @throws DateTimeException quando a data é inválida
     * @throws ZoneRulesException  caso seja fornecida uma zona argumento que a biblioteca não conheça
     */
    public static ZoneId stringParaRegiao(String zona) throws DateTimeException, ZoneRulesException  {
        return ZoneId.of(zona);
    }

    /**
     * Converte um offset argumento sobre forma
     * de String para um objeto ZoneOffset
     * 
     * @param offset
     * @return offset
     */
    public static ZoneOffset stringParaOffset(String offset) throws DateTimeException {
        return ZoneOffset.of(offset);
    }
    
    /**
     * Converte uma data argumento em formato String para um objeto
     * ZonedDateTime de acordo com um determinado formato argumento e
     * com o local argumento pretendido.
     *
     * @param data
     * @param formato
     * @param local
     * @return ZonedDateTime
     * @throws DateTimeException quando a data é inválida
     */
    public static ZonedDateTime stringParaData(String data,     //data em formato string 
                                    String formato, //formato da data argumento, por exemplo: uuuu-MM-dd
                                    String local    //País relativo à data argumento
                                   ) throws DateTimeException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(formato);
        formatter = formatter.withResolverStyle(ResolverStyle.STRICT)
                             .withLocale(new Locale(local)); 
        return ZonedDateTime.parse(data, formatter);
    }

    /**
     * Converte uma data argumento em formato String para um objeto
     * LocalDateTime de acordo com um determinado formato.
     *
     * @param data
     * @param formato
     * @return LocalDateTime
     * @throws DateTimeException quando a data é inválida
     */
    public static LocalDateTime stringParaData(String data,     //data em formato string 
                                    String formato  //formato da data argumento, por exemplo: uuuu-MM-dd
                                   ) throws DateTimeException{
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(formato);
        formatter = formatter.withResolverStyle(ResolverStyle.STRICT); 
        
        return LocalDateTime.parse(data, formatter);
    }
    
    /**
     * Converte uma data argumento em formato String para um objeto
     * LocalTime de acordo com um determinado formato.
     *
     * @param data
     * @param formato
     * @return
     * @throws DateTimeException quando a data é inválida
     */
    public static LocalTime stringParaHora(String data,     //data em formato string 
                                               String formato  //formato da data argumento, por exemplo: uuuu-MM-dd
                                              ) throws DateTimeException{
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(formato);
        formatter = formatter.withResolverStyle(ResolverStyle.STRICT); 
        
        return LocalTime.parse(data, formatter);
    }
    
    /**
     * Converte uma data argumento em formato String para um objeto
     * LocalDate de acordo com um determinado formato.
     *
     * @param data
     * @param formato
     * @return
     * @throws DateTimeException quando a data é inválida
     */
    public static LocalDate stringParaDia(String data,     //data em formato string 
                                           String formato  //formato da data argumento, por exemplo: uuuu-MM-dd
                                          ) throws DateTimeException{
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(formato);
        formatter = formatter.withResolverStyle(ResolverStyle.STRICT); 
        
        return LocalDate.parse(data, formatter);
    }
    
    /**
     * Converte uma data argumento em formato String para um objeto
     * ZonedDateTime de acordo com um determinado formato argumento e
     * com o local pretendido.
     *
     * @param data
     * @param formato
     * @param local
     * @return ZonedDateTime
     * @throws DateTimeException quando a data é inválida
     */
    public static ZonedDateTime stringParaDataHora(String data, 
                                                String formato, 
                                                String local    
                                               ) throws DateTimeException, DateTimeParseException {
        
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(formato);
        formatter = formatter.withLocale(new Locale(local));
        formatter = formatter.withResolverStyle(ResolverStyle.STRICT); 
        
        return ZonedDateTime.parse(data, formatter);
    }
    
}
