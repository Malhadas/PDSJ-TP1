
package TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries;

import TP1.Main.ValoresFixos;
import TP1.Main.ValoresFixos.IntervaloTempo;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalQuery;

/**
 * Classe que implementa TemporalQuery e que deve ser
 * usada apartir do método query de um objeto TemporalAcessor
 *
 * Permite somar unidades numa certa unidade a uma data 
 */
public class SomarUnidades implements TemporalQuery<TemporalAccessor>{
    
    /**
     * unidade a somar
     */
    private final IntervaloTempo unidade;
    
    /**
     * quantidade a somar
     */
    private final long quantidade;
    
    /**
     * Construtor
     * 
     * Recebe quantidade a somar e a unidade em que essa
     * quantidade se encontra
     * 
     * @param quantidade
     * @param unidade 
     */
    public SomarUnidades(long quantidade, IntervaloTempo unidade){
        this.quantidade = quantidade;
        this.unidade    = unidade;
    }
    
    /**
     * Soma a quantidade na unidade dadas no construtor à data d argumento
     * 
     * @param d
     * @return 
     */
    @Override
    public TemporalAccessor queryFrom(TemporalAccessor d){
        ChronoUnit c = ValoresFixos.parserDeUnidadeTemporal(unidade);
        return LocalDateTime.from(d)
                            .plus(quantidade, c);
    }
}
