
package TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalQuery;

/**
 * Classe que implementa TemporalQuery e que deve ser
 * usada apartir do método query de um objeto TemporalAcessor
 *
 * Permite determinar o resultado de um pagamento mensal sistemático 
 */
public class PagamentoSistematico implements TemporalQuery<Double>{
    
    /**
     * Dia do pagamento
     */
    private final int dia;
    
    /**
     * Valor do pagamento
     */
    private final double pagamento;
    
    /**
     * Construtor
     * 
     * recebe o dia em que recebe o pagamento todos os meses
     * e o valor do pagamento
     * 
     * @param dia
     * @param pagamento 
     */
    public PagamentoSistematico(int dia, double pagamento){
        this.dia       = dia;
        this.pagamento = pagamento;
    }
    
    /**
     * Calcula o valor pago na data d começando em LocalDat.now()
     * 
     * quando o dia do pagamento é maior que o maior dia do mês este ocorre
     * no último dia do mês.
     * 
     * quando o dia do pagamento calha a um fim de semana este ocorre na sexta-feira
     * anterior.
     * 
     * @param d
     * @return 
     */
    @Override
    public Double queryFrom(TemporalAccessor d){
        LocalDate inicio = LocalDate.now();
        LocalDate fim    = LocalDate.from(d);
        LocalDate prox_pagamento;
                
        long meses   = ChronoUnit.MONTHS.between(inicio.withDayOfMonth(1), 
                                                 fim.withDayOfMonth(1));
        int dia_data = d.get(ChronoField.DAY_OF_MONTH);
        int dia_ini  = inicio.getDayOfMonth();
         
        if (meses==0){
            if (dia_ini < dia && (dia_data > dia || dia_data==fim.lengthOfMonth())) 
                return pagamento;
            else return 0.0;
        }
        
        if(dia_ini > dia) meses --;
        
        if (dia_data < dia) {
            if (dia <= fim.lengthOfMonth())
                //se o maior dia do mês é maior ou igual ao dia do pagamento
                prox_pagamento = fim.withDayOfMonth(dia);
            else
                //caso o dia de pagamento seja maior que o maior do mês
                prox_pagamento = fim.withDayOfMonth(fim.lengthOfMonth());
            
            if(prox_pagamento.query(new IsFimSemana())) {
                //se o dia do prox pagamento calhar num fim de semana
                if(fim.getDayOfWeek() == DayOfWeek.FRIDAY && 
                    ChronoUnit.DAYS.between(fim, prox_pagamento) <= 2)
                    //neste caso já o recebeu
                    meses++;
                }
            }
        return this.pagamento * meses;
    }
    
}

