
package TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalQuery;

/**
 * Classe que implementa TemporalQuery e que deve ser
 * usada apartir do método query de um objeto TemporalAcessor
 * 
 * Permite calcular a diferença de minutos entre duas zonas
 */
public class DiferencaHoraEntreZonas implements TemporalQuery<Duration>{
    
    /**
     * zona 1
     */
    private final ZoneId z1;
    
    /**
     * zona 2
     */
    private final ZoneId z2;
    
    /**
     * Construtor
     * 
     * recebe a primeira zona e a segunda
     * 
     * @param z1
     * @param z2 
     */
    public DiferencaHoraEntreZonas(ZoneId z1, ZoneId z2){
        this.z1 = z1;
        this.z2 = z2;
    }
    
    /**
     * Calcula a diferença de minutos na segunda zona comparativamente
     * com a primeira zona para o TemporalAccessor d
     * 
     * @param d
     * @return 
     */
    @Override
    public Duration queryFrom(TemporalAccessor d){
        LocalDateTime data = LocalDateTime.from(d);
        ZonedDateTime partida = ZonedDateTime.of(data, z1);
        ZonedDateTime chegada = ZonedDateTime.of(data, z2);
        
        //Obter diferenca de hora em minutos
        return Duration.of(ChronoUnit.MINUTES.between(partida,chegada), 
                           ChronoUnit.MINUTES
                          );
    }
}
