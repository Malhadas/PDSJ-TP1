
package TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries;

import TP1.Main.ValoresFixos;
import TP1.Main.ValoresFixos.IntervaloTempo;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalQuery;

/**
 * Classe que implementa TemporalQuery e que deve ser
 * usada apartir do método query de um objeto TemporalAcessor
 * 
 * Tem como intuito calcular o tempo até ao próximo aniversário
 */
public class AteAniversario implements TemporalQuery<Long>{
    
    /**
     * unidade em que se pretende obter os resultados
     */
    private final IntervaloTempo unidade;
    
    /**
     * Construtor
     * Recebe a unidade em que se pretendem os resultados
     * 
     * @param unidade 
     */
    public AteAniversario(IntervaloTempo unidade){
        this.unidade = unidade;
    }
    
    /**
     * Calcula o tempo até ao próximo aniversário argumento desde a
     * LocalDateTime.now() e devolve o resultado na unidade data ao
     * construtor da classe
     * 
     * @param aniversario
     * @return tempo até ao próximo aniversário
     */
    @Override
    public Long queryFrom(TemporalAccessor aniversario){
        
        LocalDateTime agora = LocalDateTime.now();
        LocalDateTime prox = LocalDateTime.from(aniversario)
                                          .withYear(agora.getYear());

        //Adicionar um ano se o aniv ja aconteceu
        if (prox.isBefore(agora) || prox.isEqual(agora))
            prox = prox.plusYears(1);
    
        ChronoUnit u = ValoresFixos.parserDeUnidadeTemporal(unidade);
        return u.between(agora, prox);
    }
}
