
package TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalQuery;

/**
 * Classe que implementa TemporalQuery e que deve ser
 * usada apartir do método query de um objeto TemporalAcessor
 *
 * Permite determinar se uma dada data calha num fim de semana
 */
public class IsFimSemana implements TemporalQuery<Boolean>{

    /**
     * construtor vazio, logo esta TemporalQuery poderia ser 
     * implementada com uma expressão Lambda
     */
    public IsFimSemana(){
    }

    /**
     * Determina se a data argumento calha ou não num fim de semana
     * 
     * @param d
     * @return 
     */
    @Override
    public Boolean queryFrom(TemporalAccessor d){
        LocalDate data = LocalDate.from(d);
        
        return data.getDayOfWeek() == DayOfWeek.SATURDAY ||
               data.getDayOfWeek() == DayOfWeek.SUNDAY;
    }
}
