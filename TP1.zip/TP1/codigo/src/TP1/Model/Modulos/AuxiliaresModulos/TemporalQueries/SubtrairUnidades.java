
package TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries;

import TP1.Main.ValoresFixos;
import TP1.Main.ValoresFixos.IntervaloTempo;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalQuery;

/**
 * Classe que implementa TemporalQuery e que deve ser
 * usada apartir do método query de um objeto TemporalAcessor
 *
 * Permite subtrair uma dada quantidade numa certa unidade a uma dada data
 */
public class SubtrairUnidades implements TemporalQuery<TemporalAccessor>{
   
    /**
     * unidade a subtrair
     */
    private final IntervaloTempo unidade;

    /**
     * quantidade a subtrair
     */
    private final int quantidade;
    
    /**
     * Construtor
     * 
     * Recebe a quantidade e a unidade dessa quantidade a subtrair
     * @param quantidade
     * @param unidade 
     */
    public SubtrairUnidades(int quantidade, IntervaloTempo unidade){
        this.quantidade = quantidade;
        this.unidade    = unidade;
    }
    
    /**
     * Subtrai a quantidade na unidade dadas no construtor à data d argumento
     * 
     * @param d
     * @return 
     */
    @Override
    public TemporalAccessor queryFrom(TemporalAccessor d){
        ChronoUnit c = ValoresFixos.parserDeUnidadeTemporal(unidade);
        return LocalDateTime.from(d)
                            .minus(quantidade, c);
    }
}
