
package TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries;

import TP1.Main.ValoresFixos;
import TP1.Main.ValoresFixos.IntervaloTempo;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalQuery;

/**
 * Classe que implementa TemporalQuery e que deve ser
 * usada apartir do método query de um objeto TemporalAcessor
 * 
 * Permite calcular a diferença entre duas datas
 */
public class DiferencaIdades implements TemporalQuery<Long>{
    
    /**
     * Unidade em que se pretendem obter os resultados
     */
    private final IntervaloTempo unidade;
    
    /**
     * TemporalAcessor referente à primeira data
     */
    private final TemporalAccessor d1;
    
    /**
     * Construtor
     * 
     * recebe a primeira data t e a unidade em que pretende os resultados
     * 
     * @param t
     * @param unidade 
     */
    public DiferencaIdades(TemporalAccessor t, IntervaloTempo unidade){
        this.d1 = t;
        this.unidade = unidade;
    }
    
    /**
     * Calcula a diferença de idades entre o TemporalAcessor d1 e d2
     * na unidade fornecida no construtor
     * 
     * @param d2
     * @return 
     */
    @Override
    public Long queryFrom(TemporalAccessor d2){
        
        ChronoUnit u = ValoresFixos.parserDeUnidadeTemporal(unidade);
        
        return u.between(LocalDateTime.from(d1),
                         LocalDateTime.from(d2));
    }
}
