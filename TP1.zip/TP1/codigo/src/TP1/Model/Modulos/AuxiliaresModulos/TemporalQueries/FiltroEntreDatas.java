
package TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalQuery;

/**
 * Classe que implementa TemporalQuery e que deve ser
 * usada apartir do método query de um objeto TemporalAcessor
 * 
 * Permite determinar se uma data se encontra ou não entre outras duas datas
 */
public class FiltroEntreDatas implements TemporalQuery<Boolean>{

    /**
     * Primeira data
     */
    private final TemporalAccessor d1;
    
    /**
     * Segunda data
     */
    private final TemporalAccessor d2;
    
    /**
     * Construtor
     * 
     * recebe as duas datas
     * 
     * @param d1
     * @param d2 
     */
    public FiltroEntreDatas(TemporalAccessor d1, TemporalAccessor d2){
        this.d1 = d1;
        this.d2 = d2;
    }
    
    /**
     * Determina se o TemporalAcessor d se encontra entre d1 e d2 ou não
     * 
     * O temporalAcessor pode ser um LocalDateTime ou um LocalDate
     * 
     * @param d
     * @return 
     */
    @Override
    public Boolean queryFrom(TemporalAccessor d){
        try{
            LocalDateTime ldt = LocalDateTime.from(d);
            return ldt.isAfter (LocalDateTime.from(d1)) && 
                   ldt.isBefore(LocalDateTime.from(d2));
        } catch(DateTimeException ex){
            //Se o Temporal Accessor não for um LocalDateTime então é um
            //LocalDate
            LocalDate ldt = LocalDate.from(d);
            return ldt.isAfter (LocalDate.from(d1)) && 
                   ldt.isBefore(LocalDate.from(d2));
        }
    }
}
