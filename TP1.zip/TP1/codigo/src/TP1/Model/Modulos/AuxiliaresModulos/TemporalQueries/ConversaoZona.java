
package TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalQuery;

/**
 * Classe que implementa TemporalQuery e que deve ser
 * usada apartir do método query de um objeto TemporalAcessor
 * 
 * Tem como intuito converter uma data para uma zona distinta
 */
public class ConversaoZona implements TemporalQuery<TemporalAccessor>{

    /**
     * Zona original da data a fornecer
     */
    private final ZoneId z1;

    /**
     * Zona em que se pretende a data final
     */
    private final ZoneId z2;
    
    /**
     * Construtor
     * 
     * Recebe a zona original na qual a data se encontra (z1) e a 
     * zona na qual se quer converter (z2).
     * 
     * @param z1
     * @param z2 
     */
    public ConversaoZona(ZoneId z1, ZoneId z2){
        this.z1 = z1;
        this.z2 = z2;
    }
    
    /**
     * atribui a zona z1 ao TemporalAcessor d argumento e devolve
     * essa data no mesmo instante para a zona z2
     * 
     * @param d
     * @return data na zona z2
     */
    @Override
    public TemporalAccessor queryFrom(TemporalAccessor d){
        ZonedDateTime partida = ZonedDateTime.of(LocalDateTime.from(d), z1);
        return partida.withZoneSameInstant(z2);
    }
}
