

package TP1.Model.Modulos.Intervalos;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

/**
 * Class que gera e encapsula um intervalo iteravel entre
 * duas datas.
 */
public class IntervaloDatas implements Iterable<LocalDate> {

    //Variáveis de classe
    private final LocalDate dataInicio; // Data de início para o intervalo
    private final LocalDate dataFim;   // Data de fim para o intervalo

    /** Construtores **/
  
    /**
     * Construtor que recebe uma data de inicio e fim.
     * Caso a data de inicio seja posterior à de fim lança a exceção
     * DataInvalidaException. Caso qualquer uma delas seja nula
     * lança NullPointerException.
     * 
     * @param dataInicio
     * @param dataFim
     * @throws DateTimeException caso a data de início seja posterior à de fim
     * @throws NullPointerException caso uma das datas seja nula
     */
    public IntervaloDatas(LocalDate dataInicio, LocalDate dataFim) throws DateTimeException,  NullPointerException {
        if (dataInicio == null || dataFim == null) 
            throw new NullPointerException();
        if (dataInicio.isAfter(dataFim)) 
            throw new DateTimeException(dataInicio.toString() + " > " + dataFim.toString());
    
        this.dataInicio = dataInicio;
        this.dataFim    = dataFim;
    }


    /** Getters **/
  
    /**
     * Devolve a data de inicio desta instância do intervalo
     * 
     * @return 
     */
    public LocalDate getDataInicio() {
        return dataInicio;
    }

    /**
     * Devolve a data de fim desta instância do intervalo
     * 
     * @return 
     */
    public LocalDate getDataFim() {
        return dataFim;
    }
    
    
    /**
     * Devolve um iterador desta instância de intervalo de datas
     * 
     * @return 
     */
    @Override
    public Iterator<LocalDate> iterator() {
        return stream().iterator();
    }

    /**
     * Devolve um stream do intervalo de datas relativo a esta instância
     * 
     * @return 
     */
    public Stream<LocalDate> stream() {
        return Stream.iterate(dataInicio, d -> d.plusDays(1))
                     .limit(ChronoUnit.DAYS.between(dataInicio, dataFim) + 1);
    }

    /**
     * Devolve uma lista com todas as datas no intervalo desta instância
     * 
     * @return 
     */
    public List<LocalDate> toList() {
        List<LocalDate> dates = new ArrayList<> ();
        for (LocalDate d = dataInicio; !d.isAfter(dataFim); d = d.plusDays(1)) {
            dates.add(d);
        }
        return dates;
    }

    
    
    /**
     * hashCode, devolve um codigo hash para um objeto desta classe
     * 
     * @return 
     */
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.dataInicio);
        hash = 97 * hash + Objects.hashCode(this.dataFim);
        return hash;
    }

    /**
     * Recebe um objeto e compara-o com um objeto desta classe
     * 
     * @param obj
     * @return 
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final IntervaloDatas other = (IntervaloDatas) obj;
        if (!Objects.equals(this.dataInicio, other.dataInicio)) {
            return false;
        }
        return Objects.equals(this.dataFim, other.dataFim);
    }
  
}
