
package TP1.Model.Modulos.Viagens;

import TP1.Controler.Controler;
import TP1.Exceptions.QuerieInvalidaException;
import TP1.Exceptions.ResultadoInvalidoException;
import TP1.Exceptions.ViagemInexistenteException;
import TP1.Model.Model;
import TP1.Model.Modulos.AuxiliaresModulos.FormatacaoDeDatas;
import TP1.Utils.ApresentacaoListada.ApresentacaoInterface;
import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import java.io.Serializable;
import java.time.DateTimeException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Model que encapsula o estado e realiza queries do modo 3
 * 
 * É responsável pelo modo de viagens
 */
public class ViagensModel implements Serializable, Model, ViagensQueriesInterface{
    
    /**
     * Strings que indicam como identificar alguns campos das viagens para listar
     */
    private String preco, duracao, data = "";
    
    /**
     * registo de viagens
     */
    private RegistoViagens rv;
    
    /**
     * Construtor vazio
     */
    public ViagensModel(){
        rv = new RegistoViagens();
    }
    
    /**
     * construtor que recebe a representacao de 3 strings usadas para
     * descrever certos campos na listagem de viagens
     * 
     * @param preco
     * @param duracao
     * @param data 
     */
    public ViagensModel(String preco, String duracao, String data){
        this.rv      = new RegistoViagens();
        this.preco   = preco;
        this.duracao = duracao;
        this.data    = data;
    }
    
    
    /**
     * construtor que recebe um registo de viagens rv e a representacao 
     * de 3 strings usadas para descrever certos campos na listagem de 
     * viagens
     * 
     * @param preco
     * @param duracao
     * @param data
     * @param rv 
     */
    public ViagensModel(String preco, String duracao, String data, RegistoViagens rv){
        this.rv      = new RegistoViagens(rv.getListaViagens());
        this.preco   = preco;
        this.duracao = duracao;
        this.data    = data;
    }
    
    /**
     * 
     * realiza uma querie estando os tipos de querie possíveis representados no enum
     * QuerieViagens na interface ViagensQueriesInterface
     * 
     * este tuplo t é recebido apartir de um controler por isso o valor número
     * 0 deve ser ignorado já que era relativo ao tipo de pedido
     * 
     * o valor número 1 é então o tipo da querie
     * 
     * @param t
     * @return tuplo para enviar à view respetiva pelo controler
     * @throws QuerieInvalidaException caso o tuplo t caracteriza uma querie que não existe
     * @throws ResultadoInvalidoException Caso o tuplo t tenha valores errados
     */
    @Override
    public Tuplo realizaQuerie(Tuplo t) throws QuerieInvalidaException, ResultadoInvalidoException {
        try {
            QuerieViagens qm = t.getValor(1);
            
            switch(qm) {
                case ADDICIONAR:
                    return querieAdd(t);
                case APAGAR:
                    return querieRem(t);
                case LISTAR:
                    return querieList(t);
                case LISTARTOP_PRECODEC:
                    return querieTopPrecoDec(t);
                case LISTARTOP_PRECOCRESC:
                    return querieTopPrecoCresc(t);
                case LISTARTOP_TEMPODEC:
                    return querieTopTempoDec(t);
                case LISTARTOP_TEMPOCRESC:
                    return querieTopTempoCresc(t);
                case LISTARENTRE_DATASCRESC:
                    return querieEntreDatasCresc(t);
                case LISTARENTRE_DATASDEC:
                    return querieEntreDatasDec(t);
                case DATACHEGADA:
                    return querieDataChegada(t);
                case TOTALPAGO:
                    return querieTotalPago(t);
                case TOTALTEMPO:
                    return querieTotalTempo(t);
                case TOTALTEMPOGANHO:
                    return querieTotalTempoGanho(t);
                case LER:
                    return querieLer(t);
                default:
                    throw new QuerieInvalidaException();  
            }
        } catch (ViagemInexistenteException | DateTimeException ex) {
            throw new ResultadoInvalidoException(ex.toString());
        }
    }

    private Tuplo querieLer(Tuplo t){
        Collection<String> c = t.getValor(2);
            c.stream().forEach(s -> {
                String[] linha = s.split(";");
                try {
                    rv.adicionaViagem(new Viagem(FormatacaoDeDatas.stringParaRegiao(linha[0]),
                           FormatacaoDeDatas.stringParaRegiao(linha[1]),
                           Duration.ofMinutes(Long.parseLong(linha[2])), 
                           FormatacaoDeDatas.stringParaData(linha[3], linha[4]),
                           Double.parseDouble(linha[5])));
                } catch(DateTimeException | NumberFormatException | IndexOutOfBoundsException ex){
                    //nao adicionar esta viagem
                }
            });
           
            
            final TuploTipo tt = TuploTipo.DefaultFactory
                             .create(Number.class,Number.class,Number.class);
            return tt.criar(99,rv.getInseridosDesdeUltimaVez(),rv.getListaViagens().size());
    }
    
    private Tuplo querieEntreDatasCresc(Tuplo t)throws DateTimeParseException, DateTimeException{
        LocalDateTime l1,l2;
        final TuploTipo tt, req;
        final Tuplo ttesp;
        ApresentacaoInterface a;
        Collection<String> c;
        Controler cont = t.getValor(2);

        req = TuploTipo.DefaultFactory.create(Controler.TipoPedido.class,Tuplo.class);
        tt = TuploTipo.DefaultFactory.create(Number.class, ApresentacaoInterface.class);
        l1 = FormatacaoDeDatas.stringParaData(t.getValor(3), t.getValor(4));
        l2 = FormatacaoDeDatas.stringParaData(t.getValor(5), t.getValor(6));
        c  = listaViagensToString(rv.getViagensEntreDatasCrescente(l1,l2), true);
        a  = ApresentacaoInterface.DefaultFactory.create(c);

        ttesp = tt.criar(14, a);
        cont.realizaPedido(req.criar(Controler.TipoPedido.VIEW, ttesp));
        return null;
    }    
    
    private Tuplo querieEntreDatasDec(Tuplo t)throws DateTimeParseException, DateTimeException{
        LocalDateTime l1,l2;
        final TuploTipo tt, req;
        final Tuplo ttesp;
        ApresentacaoInterface a;
        Collection<String> c;
        Controler cont = t.getValor(2);

        req = TuploTipo.DefaultFactory.create(Controler.TipoPedido.class,Tuplo.class);
        tt = TuploTipo.DefaultFactory.create(Number.class, ApresentacaoInterface.class);
        l1 = FormatacaoDeDatas.stringParaData(t.getValor(3), t.getValor(4));
        l2 = FormatacaoDeDatas.stringParaData(t.getValor(5), t.getValor(6));
        c  = listaViagensToString(rv.getViagensEntreDatasDecrescente(l1,l2), true);
        a  = ApresentacaoInterface.DefaultFactory.create(c);

        ttesp = tt.criar(14, a);
        cont.realizaPedido(req.criar(Controler.TipoPedido.VIEW, ttesp));

        return null;
    }    
    
    private Tuplo querieTopTempoCresc(Tuplo t){
        final TuploTipo tt, req;
        final Tuplo ttesp;
        ApresentacaoInterface a;
        Collection<String> c;
        Controler cont = t.getValor(2);

        req = TuploTipo.DefaultFactory.create(Controler.TipoPedido.class,Tuplo.class);
        tt = TuploTipo.DefaultFactory.create(Number.class, ApresentacaoInterface.class);
        c  = listaViagensToString(rv.getTopViagensMaisCurtas(t.getValor(3)), false);
        a  = ApresentacaoInterface.DefaultFactory.create(c);

        ttesp = tt.criar(14, a);
        cont.realizaPedido(req.criar(Controler.TipoPedido.VIEW, ttesp));
 
        return null;
    }    
    
    private Tuplo querieTopTempoDec(Tuplo t){
        final TuploTipo tt, req;
        final Tuplo ttesp;
        ApresentacaoInterface a;
        Collection<String> c;
        Controler cont = t.getValor(2);

        req = TuploTipo.DefaultFactory.create(Controler.TipoPedido.class,Tuplo.class);
        tt = TuploTipo.DefaultFactory.create(Number.class, ApresentacaoInterface.class);
        c  = listaViagensToString(rv.getTopViagensMaisLongas(t.getValor(3)), false);
        a  = ApresentacaoInterface.DefaultFactory.create(c);

        ttesp = tt.criar(14, a);
        cont.realizaPedido(req.criar(Controler.TipoPedido.VIEW, ttesp));
        
        return null;
    }
    
    private Tuplo querieTopPrecoCresc(Tuplo t){
        final TuploTipo tt, req;
        final Tuplo ttesp;
        ApresentacaoInterface a;
        Collection<String> c;
        Controler cont = t.getValor(2);

        req = TuploTipo.DefaultFactory.create(Controler.TipoPedido.class,Tuplo.class);
        tt = TuploTipo.DefaultFactory.create(Number.class, ApresentacaoInterface.class);
        c  = listaViagensToString(rv.getTopViagensMaisBaratas(t.getValor(3)), false);
        a  = ApresentacaoInterface.DefaultFactory.create(c);

        ttesp = tt.criar(14, a);
        cont.realizaPedido(req.criar(Controler.TipoPedido.VIEW, ttesp));

        return null;
    }
    
    private Tuplo querieTopPrecoDec(Tuplo t){
        final TuploTipo tt, req;
        final Tuplo ttesp;
        ApresentacaoInterface a;
        Collection<String> c;
        Controler cont = t.getValor(2);

        req = TuploTipo.DefaultFactory.create(Controler.TipoPedido.class,Tuplo.class);
        tt = TuploTipo.DefaultFactory.create(Number.class, ApresentacaoInterface.class);
        c  = listaViagensToString(rv.getTopViagensMaisCaras(t.getValor(3)), false);
        a  = ApresentacaoInterface.DefaultFactory.create(c);

        ttesp = tt.criar(14, a);
        cont.realizaPedido(req.criar(Controler.TipoPedido.VIEW, ttesp));
        
        return null;
    }
    
    private Tuplo querieAdd(Tuplo t) throws DateTimeParseException, DateTimeException{
        Viagem v;
        v = new Viagem(FormatacaoDeDatas.stringParaRegiao(t.getValor(2)),
                       FormatacaoDeDatas.stringParaRegiao(t.getValor(3)),
                       Duration.ofMinutes(t.getValor(4)), 
                       FormatacaoDeDatas.stringParaData(t.getValor(5), t.getValor(6)),
                       t.getValor(7)
                      );
        rv.adicionaViagem(v);

        final TuploTipo tt = TuploTipo.DefaultFactory
                         .create(Number.class);
        return tt.criar(0);
    }
    
    private Tuplo querieRem(Tuplo t) throws ViagemInexistenteException{
        rv.removeViagem(t.getValor(2));
        final TuploTipo tt = TuploTipo.DefaultFactory
                         .create(Number.class);
        return tt.criar(51);
    }
    
    private Tuplo querieDataChegada(Tuplo t) throws ViagemInexistenteException{
        final TuploTipo tt = TuploTipo.DefaultFactory
                         .create(Number.class, String.class);
        return tt.criar(3,rv.getHoraChegada(t.getValor(2)).toString());
    }
    
    private Tuplo querieList(Tuplo t){
        final TuploTipo tt, req;
        final Tuplo ttesp;
        ApresentacaoInterface a;
        Collection<String> c;
        Controler cont = t.getValor(2);

        req = TuploTipo.DefaultFactory.create(Controler.TipoPedido.class,Tuplo.class);
        tt = TuploTipo.DefaultFactory.create(Number.class, ApresentacaoInterface.class);
        c  = listaViagensToString(rv.getListaViagens(), true);
        a  = ApresentacaoInterface.DefaultFactory.create(c);

        ttesp = tt.criar(14, a);
        cont.realizaPedido(req.criar(Controler.TipoPedido.VIEW, ttesp));
 
        return null;
    }
    
    private Collection<String> listaViagensToString(Collection<Viagem> c, Boolean tudo){
        int i = 0;
        List<String> r = new ArrayList<>(c.size());
        for (Viagem v : c){
            StringBuilder sb = new StringBuilder();
            if(tudo) {
                sb.append("ID ").append(i).append(" : ");
                i++;
            }
            sb.append(v.getOrigem()).append(" -> ").append(v.getDestino()).append(", ");
            sb.append(preco).append(" ").append(v.getPreco()).append(", ");
            sb.append(duracao).append(" ").append(v.getDuracao()).append(", ");
            sb.append(data).append(" ").append(v.getData());
            
            r.add(sb.toString());
        }
        
        return r;
    }

    private Tuplo querieTotalTempo(Tuplo t) throws DateTimeParseException, DateTimeException{
        final TuploTipo tt;
        LocalDateTime l1,l2;
        
        tt = TuploTipo.DefaultFactory.create(Number.class, Number.class, Number.class);
        l1 = FormatacaoDeDatas.stringParaData(t.getValor(2), t.getValor(3));
        l2 = FormatacaoDeDatas.stringParaData(t.getValor(4), t.getValor(5));
        
        return tt.criar(75,rv.getMinutosEntreDatas(l1, l2), 1);
    }

    private Tuplo querieTotalTempoGanho(Tuplo t) throws DateTimeParseException, DateTimeException{
        final TuploTipo tt;
        LocalDateTime l1,l2;
        
        tt = TuploTipo.DefaultFactory.create(Number.class, Number.class, Number.class);
        l1 = FormatacaoDeDatas.stringParaData(t.getValor(2), t.getValor(3));
        l2 = FormatacaoDeDatas.stringParaData(t.getValor(4), t.getValor(5));
        
        return tt.criar(75,rv.getPoupancaDeHoraEntrDatas(l1, l2), 2);
    }

    private Tuplo querieTotalPago(Tuplo t) throws DateTimeParseException, DateTimeException{
        final TuploTipo tt;
        LocalDateTime l1,l2;
        
        tt = TuploTipo.DefaultFactory.create(Number.class, Number.class, Number.class);
        l1 = FormatacaoDeDatas.stringParaData(t.getValor(2), t.getValor(3));
        l2 = FormatacaoDeDatas.stringParaData(t.getValor(4), t.getValor(5));
        
        return tt.criar(75,rv.getPrecoEntreDatas(l1, l2), 3);
    }

    @Override
    public Model clone() {
        return new ViagensModel(preco,duracao,data,rv);
    }
}
