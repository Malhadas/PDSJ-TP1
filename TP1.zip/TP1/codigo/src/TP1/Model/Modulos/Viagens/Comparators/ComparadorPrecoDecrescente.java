
package TP1.Model.Modulos.Viagens.Comparators;

import TP1.Model.Modulos.Viagens.Viagem;
import java.io.Serializable;
import java.util.Comparator;

/**
 *
 * Implementa Comparator para ordenar viagens desde a mais cara para a mais barata.
 */
public class ComparadorPrecoDecrescente implements Comparator<Viagem>, Serializable
{
    
    /**
     * -1 se v1 for mais cara que v2, 1 se mais barata e 0 se for igual igual
     * @param v1
     * @param v2
     * @return -1 se v1 for mais cara que v2, 1 se mais barata e 0 se for igual igual
    */
    @Override
    public int compare(Viagem v1, Viagem v2){
        double d1 = v1.getPreco();
        double d2 = v2.getPreco();
        return d1<d2 ? 1 : (d1>d2 ? (-1) : 0);
    }
}
