
package TP1.Model.Modulos.Viagens;

import TP1.Exceptions.ViagemInexistenteException;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.List;

/**
 *
 * Interface que Registo de Viagens que devem
 * implementar a Interface ViagemInterface. Embora tal não seja
 * obrigatório é fortemente aconselhado, caso contrário haverá necessidade
 * de "converter" a representação da Viagem usada para uma dessa
 * Interface já que há métodos nesta interface que recebem e
 * devolvem essa representação.
 * 
 * Pode ser colonado e serializado.
 * 
 */
public interface RegistoViagensInterface extends Cloneable, Serializable {

    /**
     * Adiciona um regista da viagem v argumento.
     * 
     * @param v 
     */
    public void adicionaViagem(ViagemInterface v);

    /**
     * Colona este registo de viagens.
     * 
     * @return novo Registo de viagens
     */
    public RegistoViagens clone();

    /**
     * Verifica igualdade
     * 
     * @param obj
     * @return True se for igual, False se não for
     */
    @Override
    public boolean equals(Object obj);

    /**
     * Para uma viagem de ID argumento determina
     * a hora de chegada no fuso horário do local
     * de destino.
     * 
     * @param id
     * @return
     * @throws ViagemInexistenteException caso o id argumento não represente nenhuma viagem registada
     */
    public ZonedDateTime getHoraChegada(int id) throws ViagemInexistenteException;

    /**
     * 
     * @return O número de viagens inseridas desde a última vez que este método foi chamado 
     */
    public int getInseridosDesdeUltimaVez();

    /**
     * 
     * @return Lista de viagens inseridas
     */
    public List<ViagemInterface> getListaViagens();

    /**
     * 
     * @param d1
     * @param d2
     * @return Total de minutos despendidos em viagens entre as datas argumento
     */
    public long getMinutosEntreDatas(LocalDateTime d1, LocalDateTime d2);

    /**
     * 
     * @param d1
     * @param d2
     * @return Total de diferença de horas amontoado em minutos em viagens entre duas datas 
     */
    public long getPoupancaDeHoraEntrDatas(LocalDateTime d1, LocalDateTime d2);

    /**
     * 
     * @param d1
     * @param d2
     * @return Total pago em viagens entre duas datas
     */
    public double getPrecoEntreDatas(LocalDateTime d1, LocalDateTime d2);

    /**
     * 
     * @param top
     * @return top viagens mais baratas
     */
    public List<ViagemInterface> getTopViagensMaisBaratas(int top);

    /**
     * 
     * @param top
     * @return top viagens mais caras
     */
    public List<ViagemInterface> getTopViagensMaisCaras(int top);

    /**
     * 
     * @param top
     * @return top viagens mais curtas
     */
    public List<ViagemInterface> getTopViagensMaisCurtas(int top);

    /**
     * 
     * @param top
     * @return top viagens mais longas
     */
    public List<ViagemInterface> getTopViagensMaisLongas(int top);

    /**
     * 
     * @param d1
     * @param d2
     * @return lista de viagens entre datas argumento ordenadas por datas crescentes
     */
    public List<ViagemInterface> getViagensEntreDatasCrescente(LocalDateTime d1, LocalDateTime d2);

    /**
     * 
     * @param d1
     * @param d2
     * @return lista de viagens entre datas argumento ordenadas por datas decrescentes
     */
    public List<ViagemInterface> getViagensEntreDatasDecrescente(LocalDateTime d1, LocalDateTime d2);

    /**
     * 
     * @return codigo hash 
     */
    @Override
    public int hashCode();

    /**
     * Remove viagem com id argumento.
     * 
     * @param id
     * @throws ViagemInexistenteException caso o id argumento não represente nenhuma viagem registada
     */
    public void removeViagem(int id) throws ViagemInexistenteException;

    /**
     * 
     * @return Representação do registo de viagem sobre forma de String
     */
    @Override
    public String toString();
    
}
