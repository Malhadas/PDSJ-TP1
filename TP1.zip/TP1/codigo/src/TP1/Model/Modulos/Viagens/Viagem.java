package TP1.Model.Modulos.Viagens;

import TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries.ConversaoZona;
import TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries.DiferencaHoraEntreZonas;
import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Objects;

/**
 * 
 *
 * Esta classe representa uma Viagem e implementa a Interface
 * ViagemInterface.
 * 
 * Esta viagem deve ter pelo menos os seguintes campos: 
 * 1) ZoneID zona de origem, 2) ZoneID zona de destino, 3) Duration duração da viagem,
 * 4) LocalDateTime data de partida no local de origem, 5) double preço.
 * 
 * Pode ser colonado e serializado.
 * 
 */
public class Viagem implements Comparable<Viagem>, ViagemInterface, Cloneable, Serializable{
    
    /**
     * zona de origem
     */
    private final ZoneId paisorigem;
    
    /**
     * zona de destino
     */
    private final ZoneId paisdestino;
    
    /**
     * duracao da viagem
     */
    private final Duration duracao; 
    
    /**
     * data de partida na origem
     */
    private final LocalDateTime data;
    
    /**
     * preço da viagem
     */
    private final double preco;

    
    /**
     * Construtor paramétrico
     * @param paisorigem
     * @param paisdestino
     * @param duracao
     * @param data
     * @param preco
     */
    public Viagem (ZoneId paisorigem, ZoneId paisdestino,
                   Duration duracao, LocalDateTime data,
                   double preco
                  ){
        this.paisorigem  = paisorigem;
        this.paisdestino = paisdestino;
        this.duracao     = duracao;
        this.data        = data;
        this.preco       = preco;
    }
    
    /**
     * Construtor por cópia
     * @param a
     */
    public Viagem(Viagem a){
        this.paisorigem  = a.getOrigem();
        this.paisdestino = a.getDestino();
        this.duracao     = a.getDuracao();
        this.data        = a.getData();
        this.preco       = a.getPreco();
    }
    
    
    /**
     * @return Pais de origem
     */
    public ZoneId getOrigem(){
        return this.paisorigem;
    }
    
    /**
     * @return Pais de destino
     */
    public ZoneId getDestino(){
        return this.paisdestino;
    }
    
    /**
     * @return duracao
     */
    public Duration getDuracao(){
        return this.duracao;
    }
    
    /**
     * @return data da viagem.
     */
    public LocalDateTime getData(){
        return this.data;
    }
    
    /**
     * Devolve o preço da viagem
     * @return preço
     */
    public double getPreco(){
        return this.preco;
    }


    /**
     * 
     * @return ZonedDateTime de chegada na zona de destino
     */
    public ZonedDateTime getHoraChegada(){
        return ZonedDateTime.from(data.query(new ConversaoZona(paisorigem,paisdestino)))
                            .plusMinutes(this.duracao.toMinutes());
    }
    
    /**
     * 
     * @return Duration de diferença de hora entre as zonas de origem e de chegada
     */
    public Duration getPoupancaHora(){
        return data.query(new DiferencaHoraEntreZonas(paisorigem,paisdestino));
    }
        
    
    /**
    * Metodo Compare
     * @param b
    */
    @Override
   public int compareTo(Viagem b){
        int r;
        
        if(this.preco<b.getPreco()) r = -1;
        else {
            if(this.preco==b.getPreco()) r = 0;
            else r = 1;
        }
        
        if(r==0) {
            if(this.data.isBefore((b.getData()))) r = -1;
            else {
                if(this.data.equals(b.getData())) r = 0;
                else r = 1;   
            }
        }
       
       return r;
   }
   
    /**
     * Método clone.
     * @return 
     */
    @Override
    public Viagem clone(){
        return new Viagem(this);
    }

    /**
     * 
     * @return código hash 
     */
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + Objects.hashCode(this.paisorigem);
        hash = 59 * hash + Objects.hashCode(this.paisdestino);
        hash = 59 * hash + Objects.hashCode(this.duracao);
        hash = 59 * hash + Objects.hashCode(this.data);
        hash = 59 * hash + (int) (Double.doubleToLongBits(this.preco) ^ (Double.doubleToLongBits(this.preco) >>> 32));
        return hash;
    }

    /**
     * método equals
     * @param obj
     * @return 
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Viagem other = (Viagem) obj;
        if (Double.doubleToLongBits(this.preco) != Double.doubleToLongBits(other.preco)) {
            return false;
        }
        if (!Objects.equals(this.paisorigem, other.paisorigem)) {
            return false;
        }
        if (!Objects.equals(this.paisdestino, other.paisdestino)) {
            return false;
        }
        if (!Objects.equals(this.duracao, other.duracao)) {
            return false;
        }
        return Objects.equals(this.data, other.data);
    }

    /**
     * Representação da viagem sobre forma de String
     * 
     * @return viagem sobre forma de String
     */
    @Override
    public String toString() {
        return "Viagem{" + "paisorigem=" + paisorigem + ", paisdestino=" 
                         + paisdestino + ", duracao=" + duracao 
                         + ", data=" + data + ", preco=" + preco + 
                     '}';
    }
   
    
}
