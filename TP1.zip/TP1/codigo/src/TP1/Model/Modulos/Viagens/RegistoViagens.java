
package TP1.Model.Modulos.Viagens;

import TP1.Exceptions.ViagemInexistenteException;
import TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries.FiltroEntreDatas;
import TP1.Model.Modulos.Viagens.Comparators.ComparadorPrecoDecrescente;
import TP1.Model.Modulos.Viagens.Comparators.ComparadorPrecoCrescente;
import TP1.Model.Modulos.Viagens.Comparators.ComparadorDuracaoDecrescente;
import TP1.Model.Modulos.Viagens.Comparators.ComparadorDuracaoCrescente;
import TP1.Model.Modulos.Viagens.Comparators.ComparadorDataDecrescente;
import TP1.Model.Modulos.Viagens.Comparators.ComparadorDataCrescente;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 *
 * Classe de Registo de Viagens
 * 
 * Pode ser colonado e serializado.
 * 
 */
public class RegistoViagens implements Serializable, Cloneable{
    private final List<Viagem> viagens;
    
    /**
     * Número de elementos inseridos desde que foi chamada o método
     *getInseridosDesdeUltimaVez()
     */
    private int inseridos;
    
    /**
     * Construtor vazio
     */
    public RegistoViagens(){
        this.viagens = new ArrayList<>();
        this.inseridos    = 0;
    }
    
    /**
     * construtor que recebe collection de viagens
     * 
     * @param viagens 
     */
    public RegistoViagens(Collection<Viagem> viagens){
        this.viagens = new ArrayList<>(viagens.size());
        viagens.forEach(a -> this.viagens.add(a.clone()));
    }
    
    /**
     * construtor que recebe registo de viagens
     * 
     * @param rv 
     */
    public RegistoViagens(RegistoViagens rv){
        this.viagens = new ArrayList<>(rv.getListaViagens());
    }
    
    /**
     * adiciona viagem v
     * 
     * @param v 
     */
    public void adicionaViagem(Viagem v){
        this.viagens.add(v.clone());
        this.inseridos++;
    }
    
    /**
     * 
     * @return inseridos desde ultima vez que se chamou esta função
     */
    public int getInseridosDesdeUltimaVez(){
        int temp = this.inseridos;
        this.inseridos = 0;
        return temp;
    }
    
    /**
     * remove viagem de id argumento
     * 
     * @param id
     * @throws ViagemInexistenteException caso a viagem de id argumento nao exista 
     */
    public void removeViagem(int id) throws ViagemInexistenteException{
        if (id < 0                    || 
            id >= this.viagens.size() || 
                 this.viagens.isEmpty()
           ) throw new ViagemInexistenteException();
        this.viagens.remove(id);
        
        if (this.inseridos>0) this.inseridos--;
    }
    
    /**
     * 
     * @param id
     * @return hora de chegada
     * @throws ViagemInexistenteException 
     */
    public ZonedDateTime getHoraChegada(int id) throws ViagemInexistenteException{
        if (id < 0                    || 
            id >= this.viagens.size() || 
                 this.viagens.isEmpty()
           ) throw new ViagemInexistenteException();
        return this.viagens.get(id).getHoraChegada();
    }
    
    /**
     * 
     * @return lista de viagens registadas
     */
    public List<Viagem> getListaViagens(){
        return this.viagens.stream()
                           .map(Viagem :: clone) //garantir encapsulamento
                           .collect(Collectors.toList());
    }
    
    /**
     * 
     * @param top
     * @return lista das top viagens mais caras 
     */
    public List<Viagem> getTopViagensMaisCaras(int top){
        return this.viagens.stream()
                           .map(Viagem :: clone) //garantir encapsulamento
                           .sorted(new ComparadorPrecoDecrescente())
                           .limit(top)
                           .collect(Collectors.toList());
    }

    /**
     * 
     * @param top
     * @return lista das top viagens mais baratas 
     */    
    public List<Viagem> getTopViagensMaisBaratas(int top){
        return this.viagens.stream()
                           .map(Viagem :: clone) //garantir encapsulamento
                           .sorted(new ComparadorPrecoCrescente())
                           .limit(top)
                           .collect(Collectors.toList());
    }
    
    /**
     * 
     * @param d1
     * @param d2
     * @return lista de viagens entre as datas argumento desde a mais recente até a mais antiga
     */
    public List<Viagem> getViagensEntreDatasDecrescente(LocalDateTime d1, LocalDateTime d2){
        return this.viagens.stream()
                           .filter(a -> (a.getData().query(new FiltroEntreDatas(d1,d2))))
                           .map(Viagem :: clone) //garantir encapsulamento
                           .sorted(new ComparadorDataDecrescente())
                           .collect(Collectors.toList());
    }
    
    /**
     * 
     * @param d1
     * @param d2
     * @return lista de viagens entre as datas argumento desde a mais antiga até a mais recente
     */
    public List<Viagem> getViagensEntreDatasCrescente(LocalDateTime d1, LocalDateTime d2){
        return this.viagens.stream()
                           .filter(a -> (a.getData().query(new FiltroEntreDatas(d1,d2))))
                           .map(Viagem :: clone) //garantir encapsulamento
                           .sorted(new ComparadorDataCrescente())
                           .collect(Collectors.toList());
    }
    
    
    /**
     * 
     * @param top
     * @return lista de top de viagens mais curtas
     */
    public List<Viagem> getTopViagensMaisCurtas(int top){
        return this.viagens.stream()
                           .map(Viagem :: clone) //garantir encapsulamento
                           .sorted(new ComparadorDuracaoCrescente())
                           .limit(top)
                           .collect(Collectors.toList());
    }

    /**
     * 
     * @param top
     * @return lista de top de viagens mais longas 
     */
    public List<Viagem> getTopViagensMaisLongas(int top){
        return this.viagens.stream()
                           .map(Viagem :: clone) //garantir encapsulamento
                           .sorted(new ComparadorDuracaoDecrescente())
                           .limit(top)
                           .collect(Collectors.toList());
    }
    
    /**
     * 
     * @param d1
     * @param d2
     * @return total pago entre datas argumento 
     */
    public double getPrecoEntreDatas(LocalDateTime d1, LocalDateTime d2){
        double soma = 0;
        return this.viagens.stream()
                           .filter(a -> (a.getData().query(new FiltroEntreDatas(d1,d2))))
                           .map(Viagem :: getPreco)
                           .reduce(soma, (ac, i) -> ac + i);
    }    
    
    /**
     * 
     * @param d1
     * @param d2
     * @return minutos de viagem entre datas argumento 
     */
    public long getMinutosEntreDatas(LocalDateTime d1, LocalDateTime d2){
        long soma = 0;
        return viagens.stream()
                      .filter(a -> (a.getData().query(new FiltroEntreDatas(d1,d2))))
                      .map((v) -> v.getDuracao().toMinutes())
                      .reduce(soma, (ac, i) -> ac + i);
    }  
    
    /**
     * 
     * @param d1
     * @param d2
     * @return tempo de mudança de hora em minutos entre datas argumento 
     */
    public long getPoupancaDeHoraEntrDatas(LocalDateTime d1, LocalDateTime d2){
        long soma = 0;
        return viagens.stream()
                      .filter(a -> (a.getData().query(new FiltroEntreDatas(d1,d2))))
                      .map((v) -> v.getPoupancaHora().toMinutes())
                      .reduce(soma, (ac, i) -> ac + i);
    }  
    
    /**
     * metodo clone
     * 
     * @return 
     */
    @Override
    public RegistoViagens clone() {
        return new RegistoViagens(this);
    }

    /**
     * 
     * @return codigo hash 
     */
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 11 * hash + Objects.hashCode(this.viagens);
        return hash;
    }

    /**
     * metodo equals
     * 
     * @param obj
     * @return 
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final RegistoViagens other = (RegistoViagens) obj;
        return Objects.equals(this.viagens, other.viagens);
    }

    /**
     * 
     * @return representacao sobre forma de string 
     */
    @Override
    public String toString() {
        return "RegistoViagens{" + "viagens=" + viagens + '}';
    }
    
    
}
