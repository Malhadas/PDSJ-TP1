
package TP1.Model.Modulos.Viagens;

import TP1.Main.MenusModos.MenuModoInterface.Modo;
import static TP1.Main.MenusModos.MenuModoInterface.Modo.M3;

/**
 *
 * Esta Interface caracteriz as queries existentes para um model
 * que a implemente
 */
public interface ViagensQueriesInterface {
    /**
     * Modo do model que implemente esta Interface
     */
    public static final Modo MODO = M3;

    /**
     * Enum ue caracteriza as queries de um model que implemnete esta Interface
     */
    public enum QuerieViagens{
        ADDICIONAR, APAGAR, LISTAR, LISTARTOP_PRECODEC, LISTARTOP_PRECOCRESC,
        LISTARTOP_TEMPODEC, LISTARTOP_TEMPOCRESC, LISTARENTRE_DATASCRESC,
        LISTARENTRE_DATASDEC, DATACHEGADA,TOTALPAGO,TOTALTEMPO,TOTALTEMPOGANHO,
        LER, CONSULTAR
    }
}
