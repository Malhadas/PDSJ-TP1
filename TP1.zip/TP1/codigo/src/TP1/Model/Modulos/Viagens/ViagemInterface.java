/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TP1.Model.Modulos.Viagens;

import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

/**
 *
 * Interface que descreve uma Viagem e que deve
 * ter pelo menos os seguintes campos: 1) ZoneID zona de origem,
 * 2) ZoneID zona de destino, 3) Duration duração da viagem,
 * 4) LocalDateTime data de partida no local de origem, 5) double preço.
 * 
 * Pode ser colonado e serializado.
 * 
 */
public interface ViagemInterface extends Cloneable, Comparable<Viagem>, Serializable {

    /**
     * Método clone.
     * @return
     */
    public Viagem clone();

    /**
     * Metodo Compare
     * @param b
     */
    @Override
    public int compareTo(Viagem b);

    /**
     * método equals
     * 
     * @param obj
     * @return 
     */
    @Override
    public boolean equals(Object obj);

    /**
     * @return data da viagem.
     */
    public LocalDateTime getData();

    /**
     * @return Pais de destino
     */
    public ZoneId getDestino();

    /**
     * @return duracao
     */
    public Duration getDuracao();

    /**
     *
     * @return Data de chegada no fuso horário da zona de destino 
     */
    public ZonedDateTime getHoraChegada();

    /**
     * @return zona de origem
     */
    public ZoneId getOrigem();

    public Duration getPoupancaHora();

    /**
     * Devolve o preço da viagem
     * @return preço da viagem
     */
    public double getPreco();

    /**
     * 
     * @return codigo hash 
     */
    @Override
    public int hashCode();

    /**
     * 
     * @return Representção da viagem sobre forma de String
     */
    @Override
    public String toString();
    
}
