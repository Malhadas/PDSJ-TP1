
package TP1.Model.EstadoConfiguracao;

import TP1.Exceptions.QuerieInvalidaException;
import TP1.Exceptions.ResultadoInvalidoException;
import TP1.Main.MenusModos.MenuModoInterface;
import TP1.Main.MenusModos.MenuModoInterface.Modo;
import TP1.Main.ValoresFixos;
import TP1.Model.Model;
import TP1.Model.Modulos.AuxiliaresModulos.FormatacaoDeDatas;
import TP1.Utils.ApresentacaoListada.ApresentacaoInterface;
import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import java.io.Serializable;
import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.TemporalQueries;

/**
 * Model que encapsula o estado e realiza queries do modo 5
 * 
 * É responsável pelo header da aplicação
 */
public class CalculadoraEstadoModel implements Serializable, Cloneable, Model, CalculadoraEstadoQueriesInterface{
    
    /**
     * Ultimo modo da calculadora usado
     */
    private Modo ultimo_modo;
    
    /**
     * Zona configurada para o header da aplicação
     */
    private ZoneId zona;
    
    /**
     * Construtor vazio
     */
    public CalculadoraEstadoModel(){
        this.ultimo_modo = MenuModoInterface.ULTIMO_MODO;
        try {
            this.zona = FormatacaoDeDatas.
                        stringParaRegiao(ValoresFixos.CONTINENTE_DEFEITO, 
                                         ValoresFixos.CIDADE_DEFEITO
                                        );
        } catch (DateTimeException d) {}
    }

    /**
     * Construtor parametrizado
     * 
     * @param m
     * @param z 
     */
    public CalculadoraEstadoModel(Modo m, ZoneId z){
        this.ultimo_modo = m;
        this.zona       = z;
    }

    
    /**
     * Construtor parameterizado
     * 
     * @param m
     * @param continete
     * @param cidade 
     */
    public CalculadoraEstadoModel(Modo m, String continete, String cidade){
        this.ultimo_modo = m;
        try {
            this.zona = FormatacaoDeDatas.stringParaRegiao(continete, cidade);
        } catch (DateTimeException d) {
        }
    }
    
    
    private void setZona(String cont, String ci) throws DateTimeException {
        this.zona = FormatacaoDeDatas.stringParaRegiao(cont, ci);
    }
    
    private ZoneId getZona() {
        return zona;
    }

    private Modo getModo(){
        return ultimo_modo;
    }
    
    private void setModo(Modo modo){
        this.ultimo_modo = modo;
    }

    private Tuplo getInfo(){
        final TuploTipo tt = TuploTipo.DefaultFactory
                              .create(String.class,String.class,String.class,
                                      String.class,String.class,String.class,
                                      String.class,String.class,Number.class);
        
        LocalDateTime d = LocalDateTime.now();

        return tt.criar(d.query(TemporalQueries.localDate()).toString(),
                              d.query(TemporalQueries.localTime()).toString(),
                              this.zona.toString(),
                              d.query(TemporalQueries.precision()).toString(),
                              ZonedDateTime.of(d,zona).query(TemporalQueries.chronology()).toString(),
                              ZonedDateTime.of(d,zona).query(TemporalQueries.offset()).toString(),
                              ZonedDateTime.of(d,zona).toString(),
                              ZonedDateTime.of(d,zona).getDayOfWeek().toString(), ZonedDateTime.of(d,zona).getDayOfYear()
                             );
    }
    
    /**
     * 
     * realiza uma querie estando os tipos de querie possíveis representados no enum
     * QuerieConfiguração na interface CalculadoraEstadoQueriesInterface
     * 
     * este tuplo t é recebido apartir de um controler por isso o valor número
     * 0 deve ser ignorado já que era relativo ao tipo de pedido
     * 
     * o valor número 1 é então o tipo da querie
     * 
     * @param t
     * @return tuplo para enviar pelo controler à view respetiva
     * @throws QuerieInvalidaException caso o tuplo t caracteriza uma querie que não existe
     * @throws ResultadoInvalidoException Caso o tuplo t tenha valores errados
     */
    @Override
    public Tuplo realizaQuerie(Tuplo t) throws QuerieInvalidaException, ResultadoInvalidoException {
        QuerieConfiguracao querie = t.getValor(1);
        final TuploTipo tt;

        switch(querie){
            
            case SETZONA:
                try {
                    //set zona
                    setZona(t.getValor(2), t.getValor(3));
                    return null;
                } catch (DateTimeException d) {
                    throw new ResultadoInvalidoException();
                }
            case SETMODO:
                //set modo    
                setModo(t.getValor(2));
                return null;
            case GETZONA:
                //get zona
                tt = TuploTipo.DefaultFactory
                              .create(Number.class,Tuplo.class);
                return tt.criar(t.getValor(2),getInfo());
                
            case GETMODO:
                //get modo
                tt = TuploTipo.DefaultFactory
                              .create(Number.class, Modo.class);
                return tt.criar(t.getValor(2),getModo());
                
            case GETZONA_GETMODO:
                //get zona e modo
                tt = TuploTipo.DefaultFactory
                              .create(Number.class, Tuplo.class, Modo.class);
                return tt.criar(t.getValor(2),getInfo(),getModo());
                
            case GETZONAS_DISPONIVEIS:
                //get zona e modo
                tt = TuploTipo.DefaultFactory
                              .create(Number.class, ApresentacaoInterface.class);
                ApresentacaoInterface ap = ApresentacaoInterface.DefaultFactory.create(ZoneId.getAvailableZoneIds());
                return tt.criar(t.getValor(2),ap);

            default :
                throw new QuerieInvalidaException();
        }
    }
   
    @Override
    public Model clone(){
        return new CalculadoraEstadoModel(ultimo_modo, zona);
    }
    
}