
package TP1.Model.EstadoConfiguracao;


/**
 *
 * Esta Interface caracteriz as queries existentes para um model
 * que a implemente
 */
public interface CalculadoraEstadoQueriesInterface {
    
    /**
     * Enum que identifica as queries existentes num model que implemente
     * esta interface
     */
    public enum QuerieConfiguracao{
        GETZONA, GETMODO, SETZONA, SETMODO, GETZONA_GETMODO, GETZONAS_DISPONIVEIS,
        GETZONAMODEL
    }
}
