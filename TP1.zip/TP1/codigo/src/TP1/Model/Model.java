
package TP1.Model;

import TP1.Exceptions.QuerieInvalidaException;
import TP1.Exceptions.ResultadoInvalidoException;
import TP1.Main.MenusModos.MenuModoInterface.Modo;
import TP1.Model.EstadoConfiguracao.CalculadoraEstadoModel;
import TP1.Model.Modulos.Calendario.CalendarioModel;
import TP1.Model.Modulos.Cronometro.Cronometro;
import TP1.Model.Modulos.Cronometro.CronometroModel;
import TP1.Model.Modulos.Idade.IdadesModel;
import TP1.Model.Modulos.Viagens.ViagensModel;
import TP1.Utils.Tuplo.Tuplo;


/**
 *
 * Descreve uma entidade que encapsula estado.
 * 
 * Implementações desta interface não devem fazer nenhum tipo
 * de input/output entre um utilizador. Servem apenas para encapsular
 * estado. Da mesma forma, entende-se que não devem comunicar diretamente
 * com uma View para apresentar resultados mas sim com um Controler que
 * encapsule essa view. Um model não deve também ter conhecimento sobre outros
 * Models distintos e deve ser capaz de funcionar completamente de forma 
 * independente.
 */
public interface Model{
    
    /**
     * Este método recebe um tuplo t que de alguma forma caracteriza a
     * querie que está a ser realizada sobre o model específico que imaplementa
     * esta Interface.
     * 
     * Cabe ao programador que implemente esta interface definir o
     * formato e conteúdo que este Tuplo deve ter.
     * 
     * Devolve depois um tuplo com os resultados que deve ser enviado
     * para uma view que o reconheça através de um Controler
     * 
     * @param t
     * @return Devolve um Tuplo com o resultado da querie
     * @throws QuerieInvalidaException quando é requerida uma querie inexistente
     * @throws ResultadoInvalidoException quando são fornecidos valores errados
     */
    public Tuplo realizaQuerie(Tuplo t) throws QuerieInvalidaException, ResultadoInvalidoException;

    /**
     * Colona o model específico e o seu estado.
     * 
     * @return o novo Model
     */
    public Model clone();
    
    /**
     * Design Pattern DefaultFactory
     * 
     * Esta classe permite instanciar um novo Mode sem que 
     * quem o faça tenha de ter conhecimento algum sobre o 
     * Model específico que implementa esta interface.
     * 
     * Isto pode ser ignorado por quem decidir fazer uma classe que
     * implemente esta Interface e pode simplesmente instânciar novos
     * models não definidos no DefaultFactory se assim entender.
     */
    public class DefaultFactory {
   
        /**
         * Cria um Model recebendo um Tuplo t. O primeiro
         * elemento do Tuplo deve ser o Modo do Model e os
         * restantes elementos ficam reservados para algum
         * argumento que o Modo específico necessite para ser
         * instanciado.
         * 
         * @param t
         * @return Devolve uma instância do model específico
         */
        public static Model create(Tuplo t) {
            switch((Modo)t.getValor(0)){
                case M5:
                    return new CalculadoraEstadoModel();
                case M1:
                    Cronometro c = t.getValor(1);
                    return new CronometroModel(c);
                case M2:
                    return new IdadesModel();
                case M3:
                    String pr = t.getValor(1);
                    String du = t.getValor(2);
                    String da = t.getValor(3);
                    return new ViagensModel(pr,du,da);
                case M4:
                    return new CalendarioModel(t.getValor(1),t.getValor(2),
                                               t.getValor(3));
                default:
                    return null;
            }
        }
    }
}
