
package TP1.View.Output;

import TP1.Controler.Controler;
import TP1.Utils.Tuplo.Tuplo;
import TP1.View.Output.Portugues.ApresentacaoViewPortugues;
import TP1.View.Output.Portugues.CalendarioViewPortugues;
import TP1.View.Output.Portugues.ConfiguracaoViewPortugues;
import TP1.View.Output.Portugues.CronometroViewPortugues;
import TP1.View.Output.Portugues.IdadesViewPortugues;
import TP1.View.Output.Portugues.ViagensViewPortugues;
import java.io.BufferedReader;
import java.io.PrintStream;

/**
 *
 * Descreve uma entidade que encapsula o output de informação para o ecrã.
 * 
 * Implementações desta interface não devem comunicar diretamente
 * com um Model para consultar o estado mas sim com um Controler que
 * encapsule esse Model. Uma View não deve também ter conhecimento sobre outras
 * Views distintas e deve ser capaz de funcionar completamente de forma 
 * independente.
 */
public interface View {
    
    /**
     * enum que descreve Línguas existentes para as views
     */
    public enum Lingua{
        PORTUGUES, INGLES
    }

    /**
     * Enum que define um tipo de view para depois ser usado
     * no DefaultFactory desta Interface e instanciar uma nova
     * View sem que quem o faça tenha de ter conhecimento
     * algum sobre a View específica que implementa esta
     * interface.
     * 
     * Isto pode ser ignorado por quem decidir fazer uma classe que
     * implemente esta Interface e pode simplesmente instânciar novos
     * Views não definidos no DefaultFactory se assim entender.
     */
    public enum TipoView{
        APRESENTACAO, CONFIGURACAO, CRONOMETRO, IDADES, VIAGENS, CALENDARIO
    }
 
    /**
     * 
     * Este método recebe um tuplo t que de alguma forma caracteriza os dados
     * a apresentar no ecrã.
     * 
     * Cabe ao programador que implemente esta interface definir o
     * formato e conteúdo que este Tuplo deve ter assim como a forma
     * de apresentação no ecrã.
     * 
     * @param t
     */
    public void imprime(Tuplo t);
    
    /**
     * 
     * @return a língua em que esta View apresenta os resultados
     */
    public Lingua getLingua();

    /**
     * Permite definir os PrintWritter onde imprimir output
     * 
     * @param ps 
     */
    public void setOutput(PrintStream ps);
    
    /**
     * Permite definir o BufferedReader onde receber Input
     * @param br 
     */
    public void setInput (BufferedReader br);

    /**
     * Design Pattern DefaultFactory
     * 
     * Esta classe permite instanciar uma nova View sem que 
     * quem o faça tenha de ter conhecimento algum sobre a
     * View específica que implementa esta interface.
     * 
     * Isto pode ser ignorado por quem decidir fazer uma classe que
     * implemente esta Interface e pode simplesmente instânciar novas
     * Views não definidas no DefaultFactory se assim entender.
     */    
    public class DefaultFactory {
    
        /**
         * Cria uma View recebendo uma Lingua l que indica a língua da
         * View a instânciar, um TipoView t que indica o tipo da View
         * pretendido de acordo com o enum definido na Interface View,
         * um BufferedReader br de onde a View receberá input, um Controler c,
         * no caso de uma View necessitar de contactar com alguma outra View
         * ou Model.
         * 
         * @param l
         * @param t
         * @param br
         * @param pw
         * @param c
         * @return Devolve uma instância da View específica
         */
        public static View create(Lingua l, TipoView t, BufferedReader br, PrintStream pw, Controler c) {
            switch(t){
                case APRESENTACAO:
                    if (l==Lingua.PORTUGUES) return new ApresentacaoViewPortugues(br,pw,c);
                    //if (l==Lingua.INGLES) return new ApresentacaoViewPortugues(br,pw,c);
                case CONFIGURACAO:
                    if (l==Lingua.PORTUGUES) return new ConfiguracaoViewPortugues(br,pw);
                    //if (l==Lingua.INGLES) return new ApresentacaoViewPortugues(br,pw,c);
                case CRONOMETRO:
                    if (l==Lingua.PORTUGUES) return new CronometroViewPortugues(br,pw);
                    //if (l==Lingua.INGLES) return new ApresentacaoViewPortugues(br,pw,c);
                case IDADES:
                    if (l==Lingua.PORTUGUES) return new IdadesViewPortugues(br,pw);
                    //if (l==Lingua.INGLES) return new ApresentacaoViewPortugues(br,pw,c);
                case VIAGENS:
                    if (l==Lingua.PORTUGUES) return new ViagensViewPortugues(br,pw);
                    //if (l==Lingua.INGLES) return new ApresentacaoViewPortugues(br,pw,c);
                case CALENDARIO:
                    if (l==Lingua.PORTUGUES) return new CalendarioViewPortugues(br,pw);
                    //if (l==Lingua.INGLES) return new ApresentacaoViewPortugues(br,pw,c);
                default:
                    return null;
            }
        }
    }
}
