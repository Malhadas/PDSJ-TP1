
package TP1.View.Output.Portugues;

import java.io.BufferedReader;
import java.io.Serializable;
import TP1.Utils.Tuplo.Tuplo;
import static TP1.View.Output.View.Lingua.PORTUGUES;
import java.io.PrintStream;
import TP1.View.Output.View;

/**
 *  
 * Classe utilizada para apresentação dos menus
 * 
 */
public class CronometroViewPortugues implements Cloneable, Serializable, View{
    
    /**
     * Lingua em que esta classe vai imprimir
     */
    private final static Lingua L = PORTUGUES;
    
    /**
     * Buffered Reader onde esta classe deve receber input
     */
    private BufferedReader br;
    
    /**
     * Print Stream onde esta classe deve imprimir
     */
    private PrintStream ps;
    
    /**
     * Construtor
     * 
     * @param br
     * @param ps 
     */
    public CronometroViewPortugues (BufferedReader br, PrintStream ps) {
        this.br = br;
        this.ps = ps;
    }
    
    /**
     * 
     * @return a língua desta View 
     */
    @Override
    public Lingua getLingua(){
        return L;
    }
    
    /**
     * set input
     * 
     * @param br 
     */
    @Override
    public void setInput(BufferedReader br){
        this.br = br;
    }
    
    /**
     * set output
     * 
     * @param ps 
     */
    @Override
    public void setOutput(PrintStream ps){
        this.ps = ps;
    }
    
    @Override
    public void imprime (Tuplo t){
        
        //ignorar
        if (t==null) return;
        
        int opcao = t.getValor(0);

	switch(opcao) {

            case 13:
                ps.print("\n      ______________CRONOMETRO____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Cronometro Decrescente:            |");
                ps.print("\n     |------------------------            |");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o número de milisegundos   |");
                ps.print("\n     | para o cronometro decrescente.     |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Milisegundos: ");
                break;
            
            case 14:
                
                ps.print("\n      _____________________________________CRONOMETRO____________________________________");
                ps.print("\n     /                                                                                   \\");
                ps.print("\n     | Escolha do Cronometro:                                                             |");
                ps.print("\n     |-----------------------                                                             |");
                ps.print("\n     |                                                              Modo 1 - Cronometro   |");
                ps.print("\n     | ---------------------------------------------------------------------------------- |");
                ps.print("\n     | 1 - Escreva '1' para cronometrar com um cronometro crescente.                      |");
                ps.print("\n     | 2 - Escreva '2' para cronometrar com um cronometro decrescente.                    |");
                ps.print("\n     | ---------------------------------------------------------------------------------- |");
                ps.print("\n     | 3 - Escreva '<-' para retroceder.                                                  |");
                ps.print("\n     \\___________________________________________________________________________________/\n");
                break;
                
            case 18:
                instrucoes();
                break;
               
            case 16:
                String ss = t.getValor(1);
                ps.print("\r"+ss);
                break;
        }

    }   
    
    private void instrucoes(){
        ps.print("\n      _____________________________________CRONOMETRO____________________________________");
        ps.print("\n     /                                                                                   \\");
        ps.print("\n     | Cronometro Instruções:                                                             |");
        ps.print("\n     |-----------------------                                                             |");
        ps.print("\n     |                                                              Modo 1 - Cronometro   |");
        ps.print("\n     | ---------------------------------------------------------------------------------- |");
        ps.print("\n     | 1 - Escreva '1' para parar a cronometragem e ver a lista dos pontos de paragem.    |");
        ps.print("\n     | 2 - Escreva '2' para marcar um ponto de paragem neste instante.                    |");
        ps.print("\n     | 3 - Escreva '3' para recomeçar a cronometragem.                                    |");
        ps.print("\n     | 4 - Escreva '4' para ver estas instruções de novo.                                 |");
        ps.print("\n     | ---------------------------------------------------------------------------------- |");
        ps.print("\n     | 5 - Escreva '<-' para retroceder.                                                  |");
        ps.print("\n     \\___________________________________________________________________________________/\n");
    }
}