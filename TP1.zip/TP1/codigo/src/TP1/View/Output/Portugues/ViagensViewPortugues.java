
package TP1.View.Output.Portugues;

import TP1.Utils.Input.RecebeInput;
import java.io.BufferedReader;
import java.io.Serializable;
import TP1.Utils.Tuplo.Tuplo;
import static TP1.View.Output.View.Lingua.PORTUGUES;
import java.io.PrintStream;
import TP1.View.Output.View;

/**
 *  
 * Classe utilizada para apresentação dos menus
 * 
 */
public class ViagensViewPortugues implements Cloneable, Serializable, View{
    
    /**
     * Lingua em que esta classe vai imprimir
     */
    private final static Lingua L = PORTUGUES;
    
    /**
     * Buffered Reader onde esta classe deve receber input
     */
    private BufferedReader br;
    
    /**
     * Print Stream onde esta classe deve imprimir
     */
    private PrintStream ps;
    
    
    /**
     * Construtor
     * 
     * @param br
     * @param ps 
     */
    public ViagensViewPortugues (BufferedReader br, PrintStream ps) {
        this.br = br;
        this.ps = ps;
    }
    
    /**
     * 
     * @return a língua desta View 
     */
    @Override
    public Lingua getLingua(){
        return L;
    }
    
    /**
     * setInput
     * 
     * @param br 
     */
    @Override
    public void setInput(BufferedReader br){
        this.br = br;
    }
    
    /**
     * setOutput
     * 
     * @param ps 
     */
    @Override
    public void setOutput(PrintStream ps){
        this.ps = ps;
    }
    
    /**
     * 
     * @param t 
     */
    @Override
    public void imprime (Tuplo t){
        
        //ignorar
        if (t==null) return;
        
        int opcao = t.getValor(0);

	switch(opcao) {

            case -1:
                ps.print("\n      _________________VIAGENS________________");
                ps.print("\n     /                                        \\");
                ps.print("\n     |  Erro:                                 |");
                ps.print("\n     |  -----               Modo 3 - Viagens  |");
                ps.print("\n     | Forneceu dados inválidos.              |");
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
                
            case 0:
                ps.print("\n      _________________VIAGENS_______________");
                ps.print("\n     /                                       \\");
                ps.print("\n     |  Viagem:                              |");
                ps.print("\n     |  -------            Modo 3 - Viagens  |");
                ps.print("\n     | Viagem adicionada com sucesso.        |");
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
                
            case 99:
                ps.print("\n      _________________VIAGENS_______________");
                ps.print("\n     /                                       \\");
                ps.print("\n     |  Viagem:                              |");
                ps.print("\n     |  -------            Modo 3 - Viagens  |");
                ps.print("\n     | " + t.getValor(1) + " Viagens adicionadas com sucesso.");
                ps.print("\n     | " + t.getValor(2) + " Viagens no total.");
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
 
            case 51:
                ps.print("\n      _________________VIAGENS_______________");
                ps.print("\n     /                                       \\");
                ps.print("\n     |  Viagem:                              |");
                ps.print("\n     |  -------            Modo 3 - Viagens  |");
                ps.print("\n     | Viagem removida com sucesso.          |");
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
                
            case 52:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o ID da viagem que         |");
                ps.print("\n     | pretende. (pode listá-las de forma |");
                ps.print("\n     | a saber os ID's existentes).       |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     ID: ");
                break;         
            case 100:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o nome do ficheiro a ler.  |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Ficheiro: ");
                break;         
                
                
            case 5:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o número para o top que    |");
                ps.print("\n     | pretende.                          |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Top: ");
                break;

            case 2:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o tempo que a viagem       |");
                ps.print("\n     | demorou em minutos.                |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Tempo: ");
                break;
                
            case 50:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o preço da viagem.         |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Preco: ");
                break;
                
            case 60:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o Continente de onde partiu|");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Continente: ");
                break;    
            
            case 61:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique a cidade de onde partiu.   |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Cidade: ");
                break; 
                
            case 62:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o Continente de destino.   |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Continente: ");
                break;    
            
            case 63:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique a cidade de destino.       |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Cidade: ");
                break; 
                
            case 3:
                ps.print("\n      ________________VIAGENS________________");
                ps.print("\n     /                                       \\");
                ps.print("\n     |  Resultado:                           |");
                ps.print("\n     |  ----------         Modo 3 - Viagens  |");
                ps.print("\n     | Chegou na data: " + t.getValor(1));
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
                
            case 75:
                ps.print("\n      ________________VIAGENS________________");
                ps.print("\n     /                                       \\");
                ps.print("\n     |  Resultado:                           |");
                ps.print("\n     |  ----------         Modo 3 - Viagens  |");
                int i = t.getValor(2);
                if(i==1) ps.print("\n     | Tempo de viagem: "+ t.getValor(1) + " minutos");
                if(i==2) ps.print("\n     | Poupança de horas: "+ t.getValor(1) + " minutos");
                if(i==3) ps.print("\n     | Preço pago: "+ t.getValor(1));
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
               
            case 13:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o dia de partida.          |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Dia: ");
                break;
                
            case 12:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o mês de partida.          |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Mês: ");
                break;
                
            case 11:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o ano de partida.          |");
                ps.print("\n     | apenas são válidos valores entre   |");
                ps.print("\n     | 1 e 9999999.                       |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Ano: ");
                break;
                
            case 23:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique a hora de partida.         |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Hora: ");
                break;
                
            case 22:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o minuto de partida        |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Minuto: ");
                break;
                
            case 33:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique o dia da primeira data.    |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Dia: ");
                break;
                
            case 32:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique o mês da primeira data.    |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Mês: ");
                break;
                
            case 31:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique o ano da primeira data.    |");
                ps.print("\n     | apenas são válidos valores entre   |");
                ps.print("\n     | 1 e 9999999.                       |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Ano: ");
                break;
                
            case 43:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique a hora da primeira data.   |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Hora: ");
                break;
                
            case 42:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique o minuto da primeira data. |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Minuto: ");
                break;
                
                            
            case 73:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique o dia da segunda data.     |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Dia: ");
                break;
                
            case 72:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique o mês da segunda data.     |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Mês: ");
                break;
                
            case 71:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique o ano da segunda data.     |");
                ps.print("\n     | apenas são válidos valores entre   |");
                ps.print("\n     | 1 e 9999999.                       |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Ano: ");
                break;
                
            case 83:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique a hora da segunda data.    |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Hora: ");
                break;
                
            case 82:
                ps.print("\n      _______________VIAGENS______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique o minuto da segunda data.  |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Minuto: ");
                break;
                
            case 14:
                
                ps.print("\n      ______________________________________VIAGENS______________________________________");
                ps.print("\n     /                                                                                   \\");
                ps.print("\n     | Escolha de funcionalidade:                                                         |");
                ps.print("\n     |---------------------------                                                         |");
                ps.print("\n     |                                                                  Modo 3 - Viagens  |");
                ps.print("\n     | ---------------------------------------------------------------------------------- |");
                ps.print("\n     | 1  - Escreva '1'  para adicionar uma viagem.                                       |");
                ps.print("\n     | 2  - Escreva '2'  para inserir viagens a partir de um ficheiro.                    |"); 
                ps.print("\n     | 3  - Escreva '3'  para remover uma viagem.                                         |");
                ps.print("\n     | 4  - Escreva '4'  para ver a lista das suas viagens.                               |");
                ps.print("\n     | 5  - Escreva '5'  para ver as top n viagens mais caras.                            |");
                ps.print("\n     | 6  - Escreva '6'  para ver as top n viagens mais baratas                           |");
                ps.print("\n     | 7  - Escreva '7'  para ver as top n viagens mais longas.                           |");
                ps.print("\n     | 8  - Escreva '8'  para ver as top n viagens mais curtas.                           |");                
                ps.print("\n     | 9  - Escreva '9'  para ver as viagens entre duas datas por ordem crescente.        |");
                ps.print("\n     | 10 - Escreva '10' para ver as viagens entre duas datas por ordem decrescente.      |");
                ps.print("\n     | 11 - Escreva '11' para ver a data de chegada para uma determinada viagem.          |"); 
                ps.print("\n     | 12 - Escreva '12' para ver o preço total dispendido em viagens entre duas datas.   |");
                ps.print("\n     | 13 - Escreva '13' para ver o tempo total dispendido em viagens entre duas datas.   |");
                ps.print("\n     | 14 - Escreva '14' para ver o total de tempo ganho em diferenças de hora em viagens.|");
                ps.print("\n     | ---------------------------------------------------------------------------------- |");
                ps.print("\n     | Escreva '<-' para retroceder.                                                      |");
                ps.print("\n     \\___________________________________________________________________________________/\n");
                break;
        }

    }   
}