
package TP1.View.Output.Portugues;

import TP1.Controler.Controler;
import TP1.Controler.Controler.TipoPedido;
import TP1.Exceptions.GoBackException;
import TP1.Exceptions.PaginaInexistenteException;
import TP1.Model.EstadoConfiguracao.CalculadoraEstadoQueriesInterface.QuerieConfiguracao;
import TP1.Utils.ApresentacaoListada.Apresentacao;
import TP1.Utils.ApresentacaoListada.ApresentacaoInterface;
import TP1.Utils.Input.RecebeInput;
import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import TP1.View.Output.View;
import TP1.View.Output.View.Lingua;
import java.io.BufferedReader;
import java.io.PrintStream;
import java.io.Serializable;

/**
 * Implementa a interface View e representa uma classe que permite apresentar
 * no ecrã uma Apresentação Listada do tipo ApresentacaoInterface
 */
public class ApresentacaoViewPortugues implements Cloneable, Serializable, View{

     /**
      * Lingua em que esta classe vai imprimir
      */
    private final static Lingua L = Lingua.PORTUGUES;
    
    /**
     * Buffered Reader onde esta classe deve receber input
     */
    private BufferedReader br;
    
    /**
     * Print Stream onde esta classe deve imprimir
     */
    private PrintStream ps;
    
    /**
     * Controler para comunicação com outra View que apresente
     * o Header da aplicação
     */
    private final Controler c;
    
    /**
     * TuploTipo que permite a criação de um Tuplo para pedir o header ao Controler c
     */
    private final TuploTipo tt = TuploTipo.DefaultFactory
                      .create(TipoPedido.class,QuerieConfiguracao.class,Number.class);
    
    /**
     * Construtor
     * 
     * @param br
     * @param ps
     * @param c 
     */
    public ApresentacaoViewPortugues (BufferedReader br, PrintStream ps, Controler c) {
        this.br = br;
        this.ps = ps;
        this.c  = c;
    }
    
    /**
     * 
     * @return a língua desta View 
     */
    @Override
    public View.Lingua getLingua(){
        return L;
    }
    
    /**
     * Permite definir o BufferedReader onde receber Input
     * @param br 
     */
    @Override
    public void setInput(BufferedReader br){
        this.br = br;
    }
    
    /**
     * Permite definir os PrintWritter onde imprimir output
     * 
     * @param ps 
     */
    @Override
    public void setOutput(PrintStream ps){
        this.ps = ps;
    }
    
    /**
     * Recebe um tuplo t que indica o que imprimir.
     * 
     * caso o tuplo seja null então é ignorado de imediato
     * 
     * caso contrário o primeiro elemento deve ser um inteiro.
     * Se o inteiro for 14 então o segundo argumento deve ser 
     * uma Apresentação listada, sendo essa mesmo apresentada de seguida.
     * 
     * Outros valores de inteiros serão ignorados
     * 
     * @param t 
     */
    @Override
    public void imprime (Tuplo t){
        
        //ignorar
        if (t==null) return;
        
        int opcao = t.getValor(0);
        
        c.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2));
    
	switch(opcao) {
            
            case 14:
                Apresentacao a = t.getValor(1);
                apresenta(a);
                break;
        }

    }
    
    private void printInstrucoesLista(){
        /*Apresentacao de lista*/
        ps.print("\n      ______________APRESENTAÇÃO______________");
        ps.print("\n     /                                        \\");
        ps.print("\n     | Instruções:                            |");
        ps.print("\n     |-------------                           |");
        ps.print("\n     |                                        |");
        ps.print("\n     | 1 - Escreva a letra 'p' seguida de     |");
        ps.print("\n     |     um número para avançar para a      |");
        ps.print("\n     |     página desse número específico.    |");
        ps.print("\n     |                                        |");
        ps.print("\n     | 2 - Escreva '>' para avançar para a    |");
        ps.print("\n     |     página seguinte.                   |");
        ps.print("\n     |                                        |");
        ps.print("\n     | 3 - Escreva '<' para retroceder para   |");
        ps.print("\n     |     a página anterior.                 |");
        ps.print("\n     |                                        |");
        ps.print("\n     | 4 - Escreva '<-' para voltar.          |");
        ps.print("\n     |                                        |");
        ps.print("\n     | 5 - Escreva a letra 'h' para poder     |");
        ps.print("\n     |     Consultar estas instruções.        |");
        ps.print("\n     |                                        |");
        ps.print("\n     |----------------------------------------|");
        ps.print("\n     |                                        |");
        ps.print("\n     |       Prima Enter para continuar       |");
        ps.print("\n     |       --------------------------       |");
        ps.print("\n     |                                        |");
        ps.print("\n     \\________________________________________/");
        ps.print("\n");
        ps.print("\n");
        RecebeInput.esperarEnter(br);
    }
    

    private void apresenta(Apresentacao a) {
      
        //if (a.getTotal()==0) return;
        
	/*Imprimir instruções*/
	printInstrucoesLista();

        int z = a.getNpaginas();
        int w = a.getTotal();
        int i = 1;
        int r = 1;
	int y = a.getNlinhasPpagina();
        
        while(true){

            try {
                int avg = a.getMaxTam(i-1);
                c.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2));
                
                ps.print("\n      "+printUnderscores(avg)+"");
                ps.print("\n     /"+printEspacos(avg,true)+"\\");
                ps.print("\n     | PÁGINA "+i+" de "+z);
                ps.print("\n     | --------------------");
                ps.print("\n     | TOTAL "+w);
                ps.print("\n     \\"+printUnderscores(avg)+"/");
                ps.print("\n     /"+printEspacos(avg,true)+"\\\n");
                
                for(String s : a.getPagina(i-1)){
                    String linha = r+" - ";
                    ps.println("     | "+linha + s + printEspacos((avg-s.length())+(8-linha.length()),false)+" |");
                    r++;
                }
                
                ps.println("     \\"+printUnderscores(avg)+"/");
                
                String opcao;
                try {
                    opcao = RecebeInput.lerLinha(br);
                } catch (GoBackException ex) {
                    ps.println("\nA voltar ao menu anterior..");
                    return;
                }
                
                if (opcao==null || opcao.length()==0){
                    ps.println("ERRO: Inseriu uma opção inválida para a apresentacao.");
                    ps.println("Escreva 'h' para consultar as intruções.");
                    ps.println("A voltar à página "+i);
                    ps.println("Por favor tente novamente.");
                    ps.println("");
                    if (i==z){
                        r-=a.getPagina(i-1).size();
                        continue;
                    }
                    r-=y;
                    continue;
                }
                
                switch(opcao.toLowerCase().charAt(0)) {
                    
                    case 'p' :
                        try {
                            int p = Integer.parseInt(opcao.substring(1));
                            if(p>0 && p<=z){
                                i = p;
                                r = y*i-(y-1);
                                break;
                            }
                            ps.println("\nERRO: Inseriu uma página inválida: "+opcao);
                            ps.println("A voltar à página "+i);
                            r-=y;
                            break;
                        } catch (NumberFormatException nfe){
                            ps.println("\nERRO: Começou a sua opção com \""+opcao.charAt(0)+"\", no entanto não escolheu nenhum número válido para a página.");
                            if (i==z) r-=a.getPagina(i-1).size();
                            else r-=y;
                            break;
                        }
                        
                    case '>' :
                        if (i==z) return;
                        i++;
                        break;
                        
                    case '<' :
                        if (i<=1) {
                            if (r<=ApresentacaoInterface.N_ELEM_POR_PAG+1) {
                                r=1;
                                break;
                            }
                            r-=y*2;
                            break;
                        }
                        if (i==z){
                            r-=a.getPagina(i-1).size()+ApresentacaoInterface.N_ELEM_POR_PAG;
                            i--;
                            break;
                        }
                        i--;
                        r-=y*2;
                        break;
                        
                        
                    case 'h' :
                        c.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2));
                        printInstrucoesLista();
                        r-=y;
                        break;
                        
                        
                    default :
                        ps.println("ERRO: Inseriu uma opção inválida para a apresentacao.");
                        ps.println("Escreva 'h' para consultar as intruções.");
                        ps.println("A voltar à página "+i);
                        ps.println("Por favor tente novamente.");
                        ps.println("");
                        if (i==z) r-=a.getPagina(i-1).size();
                        else r-=y;
                }
            } catch (PaginaInexistenteException ex) {
                ps.println("     | A lista paginada\n     | está vazia.");
                ps.println("     \\"+printUnderscores(21)+"/");
                ps.println("      ENTER para continuar.");
                RecebeInput.esperarEnter(br);
                return;
            }
	}
    }
    
    private String printUnderscores(int i){
        StringBuilder sb = new StringBuilder();
        if(i<=0) i = 21;
        for(int j=0;j<i+10;j++){
            sb.append('_');
        }
        return sb.toString();
    }
    
    private String printEspacos(int i, boolean b){
        StringBuilder sb = new StringBuilder();
        int offset;
        if(i<=0 && b) i = 21;
        if(b) offset = 10;
        else offset = 0;
        for(int j=0;j<i+offset;j++){
            sb.append(' ');
        }
        return sb.toString();
    }
}
