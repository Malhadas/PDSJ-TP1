
package TP1.View.Output.Portugues;

import TP1.Main.MenusModos.MenuModoInterface.Modo;
import TP1.Utils.Input.RecebeInput;
import java.io.BufferedReader;
import java.io.Serializable;
import TP1.Utils.Tuplo.Tuplo;
import static TP1.View.Output.View.Lingua.PORTUGUES;
import java.io.PrintStream;
import TP1.View.Output.View;

/**
 *  
 * Classe utilizada para apresentação dos menus
 * 
 */
public class ConfiguracaoViewPortugues implements Cloneable, Serializable, View{
    
    /**
     * Lingua em que esta classe vai imprimir
     */
    private final static Lingua L = PORTUGUES;
    
    /**
     * Buffered Reader onde esta classe deve receber input
     */
    private BufferedReader br;
    
    /**
     * Print Stream onde esta classe deve imprimir
     */
    private PrintStream ps;
    
    /**
     * Construtor
     * 
     * @param br
     * @param ps 
     */
    public ConfiguracaoViewPortugues (BufferedReader br, PrintStream ps) {
        this.br = br;
        this.ps = ps;
    }
    
    /**
     * 
     * @return a língua desta View 
     */
    @Override
    public Lingua getLingua(){
        return L;
    }
    
    /**
     * set input
     * 
     * @param br 
     */
    @Override
    public void setInput(BufferedReader br){
        this.br = br;
    }
    
    /**
     * set output
     * 
     * @param ps 
     */
    @Override
    public void setOutput(PrintStream ps){
        this.ps = ps;
    }
    
    @Override
    public void imprime (Tuplo t){
        
        //ignorar
        if (t==null) return;
        
        int opcao = t.getValor(0);
        if (opcao!=-1)
            info(t.getValor(1));
       
	switch(opcao) {
            
            case -1:

                ps.print("\n      _____________CARREGAR ESTADO____________");
                ps.print("\n     /                                        \\");
                ps.print("\n     |  Erro:                                 |");
                ps.print("\n     |  -----                                 |");
                ps.print("\n     | Resultado de querie inválido.          |");
                ps.print("\n     | Os dados que forneceu não são válidos. |");
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
            
            case 0: 
                /*Logótipo*/
                ps.print("\n");
                ps.print("\n      __________________________________________________________");
                ps.print("\n     /                                                          \\");                                                             
                ps.print("\n    |   _____      _            _           _                    |");                    
                ps.print("\n    |  / ____|    | |          | |         | |                   |");                  
                ps.print("\n    | | |     __ _| | ___ _   _| | __ _  __| | ___  _ __ __ _    |");   
                ps.print("\n    | | |    / _` | |/ __| | | | |/ _` |/ _` |/ _ \\| '__/ _` |   |");   
                ps.print("\n    | | |___| (_| | | (__| |_| | | (_| | (_| | (_) | | | (_| |   |");  
                ps.print("\n    |  \\_____\\__,_|_|\\___|\\__,_|_|\\__,_|\\__,_|\\___/|_|  \\__,_|   |");
                ps.print("\n    |              | |          | |     | |                      |");                    
                ps.print("\n    |  ______    __| | ___    __| | __ _| |_ __ _ ___   ______   |");  
                ps.print("\n    | |______|  / _` |/ _ \\  / _` |/ _` | __/ _` / __| |______|  |"); 
                ps.print("\n    |          | (_| |  __/ | (_| | (_| | || (_| \\__ \\           |");          
                ps.print("\n    |           \\__,_|\\___|  \\__,_|\\__,_|\\__\\__,_|___/           |"); 
                ps.print("\n    |                                                            |");
                ps.print("\n    |                                                            |");
                ps.print("\n    |                 Prima Enter para continuar                 |");
                ps.print("\n    |                 --------------------------                 |");
                ps.print("\n    |    2017/2018                                               |");
                ps.print("\n     \\__________________________________________________________/");
                ps.print("\n");
                ps.print("\n");
                RecebeInput.esperarEnter(br);
        
                /* 
                 *   _____      _            _           _                    
                 *  / ____|    | |          | |         | |                   
                 * | |     __ _| | ___ _   _| | __ _  __| | ___  _ __ __ _    
                 * | |    / _` | |/ __| | | | |/ _` |/ _` |/ _ \| '__/ _` |   
                 * | |___| (_| | | (__| |_| | | (_| | (_| | (_) | | | (_| |   
                 *  \_____\__,_|_|\___|\__,_|_|\__,_|\__,_|\___/|_|  \__,_|   
                 *               | |          | |     | |                      font: big      
                 *   ______    __| | ___    __| | __ _| |_ __ _ ___   ______  
                 *  |______|  / _` |/ _ \  / _` |/ _` | __/ _` / __| |______| 
                 *           | (_| |  __/ | (_| | (_| | || (_| \__ \          
                 *            \__,_|\___|  \__,_|\__,_|\__\__,_|___/          
                 *                                                           
                 */                                             
                                                      
		break;

                                                      
            case 8:
                /*Texto de saída*/
                ps.print("\n      _______________________VOLTE SEMPRE_______________________");
                ps.print("\n     /                            |                             \\");
                ps.print("\n     |        A sair..            |           2017/2018         |");
                ps.print("\n     |____________________________|_____________________________|");
                ps.print("\n     |        Programadores:      |          Docente:           |");
                ps.print("\n     |                            |                             |");
                ps.print("\n     |  - Daniel Malhadas A72293  |   - Fernando Martins        |");
                ps.print("\n     |  - João   Dias     A72095  |                             |");
                ps.print("\n     |____________________________|_____________________________|");
                ps.print("\n     |                                                          |");
                ps.print("\n     |    Obrigado por utilizar a nossa Calculadora de Datas!   |");
                ps.print("\n     |                                                          |");
                ps.print("\n     |                 Prima Enter para terminar                |");
                ps.print("\n     |                 -------------------------                |");
                ps.print("\n     |                                                          |");
                ps.print("\n     \\__________________________________________________________/");
                ps.print("\n");
                RecebeInput.esperarEnter(br);
                break;

                                                                                                                  
            case 1:
                    
                ps.print("\n      ______________MENU PRINCIPAL____________");
                ps.print("\n     /                                        \\");
                ps.print("\n     | Menu principal:                        |");
                ps.print("\n     |-----------------                       |");
                ps.print("\n     |                  Calculadora de Datas  |");
                ps.print("\n     |                                        |");
                ps.print("\n     | Escreva a letra 'h' para consultar     |");
                ps.print("\n     | as instruções.                         |");
                ps.print("\n     |                                        |");
                ps.print("\n     \\________________________________________/");
                ps.print("\n");
		break;

            case 5:
			
                ps.print("\n      _______________________________MENU PRINCIPAL_______________________________");
                ps.print("\n     /                                                                            \\");
                ps.print("\n     | Instruções:                                                                 |");
                ps.print("\n     |-------------                                                                |");
                ps.print("\n     |                                                       Calculadora de Datas  |");
                ps.print("\n     | --------------------------------------------------------------------------- |");
                ps.print("\n     | 1 - Escreva a letra 'm' para escolher o modo da calculadora.                |");
                ps.print("\n     | --------------------------------------------------------------------------- |");
                ps.print("\n     | 2 - Escreva 'h' para ver de novo esta página de instruções.                 |");
                ps.print("\n     | --------------------------------------------------------------------------- |");
                ps.print("\n     | 3 - Escreva 't' para ver de novo o logótipo do projeto.                     |");
                ps.print("\n     | --------------------------------------------------------------------------- |");
                ps.print("\n     | 4 - Escreva 'a' para ver a página 'sobre' com informações sobre o projeto.  |");
                ps.print("\n     | --------------------------------------------------------------------------- |");
                ps.print("\n     | 5 - Escreva 's' para sair da aplicação.                                     |");
                ps.print("\n     | --------------------------------------------------------------------------- |");
                ps.print("\n     | 6 - Escreva 'g' para guardar o estado da aplicação num ficheiro.            |");
                ps.print("\n     | --------------------------------------------------------------------------- |");
                ps.print("\n     | 7 - Escreva 'c' para carregar o estado da aplicação de um ficheiro.         |");
                ps.print("\n     |-----------------------------------------------------------------------------|");
                ps.print("\n     |                                                                             |");
                ps.print("\n     |                         Prima Enter para continuar                          |");
                ps.print("\n     |                         --------------------------                          |");
                ps.print("\n     |                                                                             |");
                ps.print("\n     \\_____________________________________________________________________________/");
                ps.print("\n");
                ps.print("\n");
                RecebeInput.esperarEnter(br);
                break;

            case 6:
                /*About*/
                ps.print("\n      __________________________SOBRE__________________________");
                ps.print("\n     /                            |                             \\");
                ps.print("\n     |   Calculadora de Datas     |         2017/2018           |");
                ps.print("\n     |____________________________|_____________________________|");
                ps.print("\n     |        Programadores:      |          Docente:           |");
                ps.print("\n     |                            |                             |");
                ps.print("\n     |  - Daniel Malhadas A72293  |   - Fernando Martins        |");
                ps.print("\n     |  - João   Dias     A72095  |                             |");
                ps.print("\n     |____________________________|_____________________________|");
                ps.print("\n     |                                                          |");
                ps.print("\n     |                 Prima Enter para continuar               |");
                ps.print("\n     |                 --------------------------               |");
                ps.print("\n     |                                                          |");
                ps.print("\n     \\__________________________________________________________/");
                ps.print("\n");
                RecebeInput.esperarEnter(br);
                break;
        
            case 9:
			
                ps.print("\n      ______________MUDAR FUSO____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Mudar Fuso:                        |");
                ps.print("\n     |------------                        |");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o Continente do fuso que   |");
                ps.print("\n     | Pretende. Escreva '<-' para voltar |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Continente: ");
                break;
        
            case 10:

                ps.print("\n      ______________MUDAR FUSO____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Mudar Fuso:                        |");
                ps.print("\n     |------------                        |");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique a cidade do fuso que       |");
                ps.print("\n     | Pretende. Escreva '<-' para voltar |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Cidade: ");
                break;
                        
            case 11:

                ps.print("\n      _____________MUDAR OFFSET___________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Mudar Offset:                      |");
                ps.print("\n     |--------------                      |");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique '+' ou '-' para um offset  |");
                ps.print("\n     | positivo ou negativo. De seguida   |");
                ps.print("\n     | Escreva o offset no formato hh:mm  |");
                ps.print("\n     | Escreva '<-' para voltar           |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Offset: ");
                break;
                        
            case 12:
			
                ps.print("\n      ____________________CONFIGURAÇÃO__________________");
                ps.print("\n     /                                                  \\");
                ps.print("\n     | Configuração:                                     |");
                ps.print("\n     |--------------                                     |");
                ps.print("\n     |                                                   |");
                ps.print("\n     | Para mudar o fuso horário escreva '1'             |");
                ps.print("\n     | Para ver os fusos horários conhecidos escreva '2' |");
                ps.print("\n     | Escreva '<-' para voltar                          |");
                ps.print("\n     \\__________________________________________________/");
                ps.print("\n     Configuração: ");
                break;
                
            case 13:
                
                ps.print("\n      ______________MENU MUDANÇA DE MODO____________");
                ps.print("\n     /                                              \\");
                ps.print("\n     | Menu mudança de modo:                        |");
                ps.print("\n     |----------------------                        |");
                ps.print("\n     |                                              |");
                modos();
                Modo m = t.getValor(2);
                if (m==Modo.NONE) ps.print("\n     Ultimo modo usado: Nenhum");
                else              ps.print("\n     Ultimo modo usado: " + m.toString());
                ps.print("\n     ------------------");
                ps.print("\n     Escolha o modo pretendido: ");
                break;

            case 18:
                
                ps.print("\n      _________________GUARDAR ESTADO_______________");
                ps.print("\n     /                                              \\");
                ps.print("\n     | Menu guardar estado:                         |");
                ps.print("\n     |---------------------                         |");
                ps.print("\n     |                                              |");
                ps.print("\n     | Escreva o número do modo de que pretende     |");
                ps.print("\n     | guardar o estado da aplicação.               |");
                ps.print("\n     |                                              |");
                modos();
                ps.print("\n     Modo: ");
                break;
                
            case 19:
                
                ps.print("\n      ________________CARREGAR ESTADO_______________");
                ps.print("\n     /                                              \\");
                ps.print("\n     | Menu carregar estado:                        |");
                ps.print("\n     |----------------------                        |");
                ps.print("\n     |                                              |");
                ps.print("\n     | Escreva o número do modo de que pretende     |");
                ps.print("\n     | carregar o estado da aplicação.              |");
                ps.print("\n     |                                              |");
                modos();
                ps.print("\n     Modo: ");
                break;
                
            case 14:
                
                ps.print("\n      _________________GUARDAR ESTADO_______________");
                ps.print("\n     /                                              \\");
                ps.print("\n     | Menu guardar estado:                         |");
                ps.print("\n     |---------------------                         |");
                ps.print("\n     |                                              |");
                ps.print("\n     | Escreva o nome do ficheiro onde pretende     |");
                ps.print("\n     | guardar o estado da aplicação.               |");
                ps.print("\n     | Escreva '<-' para voltar ao menu anterior.   |");
                ps.print("\n     \\_____________________________________________/");
                ps.print("\n     Ficheiro: ");
                break;
                
            case 15:
                
                ps.print("\n      ________________CARREGAR ESTADO_______________");
                ps.print("\n     /                                              \\");
                ps.print("\n     | Menu carregar estado:                        |");
                ps.print("\n     |----------------------                        |");
                ps.print("\n     |                                              |");
                ps.print("\n     | Escreva o nome do ficheiro de onde pretende  |");
                ps.print("\n     | carregar o estado da aplicação.              |");
                ps.print("\n     | Escreva '<-' para voltar ao menu anterior.   |");
                ps.print("\n     \\_____________________________________________/");
                ps.print("\n     Ficheiro: ");
                break;

            case 30:

                ps.print("\n      _____________GUARDAR ESTADO_____________");
                ps.print("\n     /                                        \\");
                ps.print("\n     |  Estado guardado com sucesso.          |");
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
                
            case 31:

                ps.print("\n      _____________CARREGAR ESTADO____________");
                ps.print("\n     /                                        \\");
                ps.print("\n     |  Estado carregado com sucesso.         |");
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
                
            case 29:

                ps.print("\n      _____________CARREGAR ESTADO____________");
                ps.print("\n     /                                        \\");
                ps.print("\n     |  Erro:                                 |");
                ps.print("\n     |  -----                                 |");
                ps.print("\n     | Falha ao carregar ficheiro             |");
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
                
                
            case 28:

                ps.print("\n      _____________GUARDAR ESTADO_____________");
                ps.print("\n     /                                        \\");
                ps.print("\n     |  Erro:                                 |");
                ps.print("\n     |  -----                                 |");
                ps.print("\n     | Falha ao guardar no ficheiro           |");
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
        }

    }
    

    private void info(Tuplo t){
        if (t==null) return;
                
	ps.print("\n      ___________________________________________________________________________");
	ps.print("\n     /                                                                           \\");
	ps.print("\n     | Data base:                     " + t.getValor(0));
        ps.print("\n     | Hora base:                     " + t.getValor(1));
        ps.print("\n     | Fuso horário:                  " + t.getValor(2));
        ps.print("\n     | Precisão:                      " + t.getValor(3));
        ps.print("\n     | Cronologia:                    " + t.getValor(4));
        ps.print("\n     | Offset:                        " + t.getValor(5));
        ps.print("\n     | Data e Hora com fuso e offset: " + t.getValor(6));
        ps.print("\n     | Dia da semana: " + parserDiaSemana(t.getValor(7)) + ", dia do ano: " +  t.getValor(8));
	ps.print("\n     \\___________________________________________________________________________/");
        ps.print("\n     -----------------------------------------------------------------------------");
    }
    
    private void modos(){
                ps.print("\n     | Modos existentes:                            |");
                ps.print("\n     |----|--------- -------------------------------|");
                ps.print("\n     | M1 | Escreva '1' para modo de cronómetro.    |");
                ps.print("\n     |----|-----------------------------------------|");
                ps.print("\n     | M2 | Escreva '2' para modo de operações      |");
                ps.print("\n     |    | sobre idades.                           |");
                ps.print("\n     |----|-----------------------------------------|");
                ps.print("\n     | M3 | Escreva '3' para modo de registo de     |");
                ps.print("\n     |    | viagens.                                |");
                ps.print("\n     |----|-----------------------------------------|");
                ps.print("\n     | M4 | Escreva '4' para modo de calendário.    |");
                ps.print("\n     |----|-----------------------------------------|");
                ps.print("\n     | M5 | Escreva '5' para modo de configuração.  |");
                ps.print("\n     |----|-----------------------------------------|");
                ps.print("\n     | <- | Escreva '<-' para voltar ao menu        |");
                ps.print("\n     |    | principal.                              |");
                ps.print("\n     |----|-----------------------------------------|");
                ps.print("\n     |                                              |");
                ps.print("\n     \\_____________________________________________/");
    }
    
    private String parserDiaSemana(String diaSemana){
        switch(diaSemana){
            case "MONDAY":
                return "Segunda-feira";
            case "SUNDAY":
                return "Domingo";
            case "THURSDAY":
                return "Quinta-feira";
            case "WEDNESDAY":
                return "Quarta-feira";
            case "FRIDAY":
                return "Sexta-feira";
            case "SATURDAY":
                return "Sabado";
            case "TUESDAY":   
                return "Terca-feira";
            default:
                return "Dia da semana desconhecido";
        }
    }
}
