
package TP1.View.Output.Portugues;

import TP1.Utils.Input.RecebeInput;
import java.io.BufferedReader;
import java.io.Serializable;
import TP1.Utils.Tuplo.Tuplo;
import TP1.View.Output.View.Lingua;
import java.io.PrintStream;
import TP1.View.Output.View;

/**
 *  
 * Classe utilizada para apresentação de output do modo calendário
 * 
 */
public class CalendarioViewPortugues implements Cloneable, Serializable, View{
    
    /**
     * Lingua em que esta classe vai imprimir
     */     
    private static final Lingua L = Lingua.PORTUGUES;
    
    /**
     * Buffered Reader onde esta classe deve receber input
     */
    private BufferedReader br;
    
    /**
     * Print Stream onde esta classe deve imprimir
     */
    private PrintStream ps;
    
    /**
     * Construtor, recebe br para input e ps para output
     * 
     * @param br
     * @param ps 
     */
    public CalendarioViewPortugues (BufferedReader br, PrintStream ps) {
        this.br = br;
        this.ps = ps;
    }
    
    /**
     * 
     * @return a língua desta View 
     */
    @Override
    public Lingua getLingua(){
        return L;
    }
    
    /**
     * Set input
     * 
     * @param br 
     */
    @Override
    public void setInput(BufferedReader br){
        this.br = br;
    }
    
    /**
     * set output
     * 
     * @param ps 
     */
    @Override
    public void setOutput(PrintStream ps){
        this.ps = ps;
    }
    
    @Override
    public void imprime (Tuplo t){
        
        //ignorar
        if (t==null) return;
        
        int opcao = t.getValor(0);

	switch(opcao) {

            case -1:
                ps.print("\n      ________________CALENDÁRIO______________");
                ps.print("\n     /                                        \\");
                ps.print("\n     |  Erro:                                 |");
                ps.print("\n     |  -----            Modo 4 - Calendário  |");
                ps.print("\n     | Forneceu dados inválidos.              |");
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
                
            case 0:
                ps.print("\n      ________________CALENDÁRIO_____________");
                ps.print("\n     /                                       \\");
                ps.print("\n     |  Calendário:                          |");
                ps.print("\n     |  -----------     Modo 4 - Calendário  |");
                ps.print("\n     | Lembrete adicionado com sucesso.      |");
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;

            case 1:
                ps.print("\n      ________________CALENDÁRIO_____________");
                ps.print("\n     /                                       \\");
                ps.print("\n     |  Calendário:                          |");
                ps.print("\n     |  -----------     Modo 4 - Calendário  |");
                ps.print("\n     | Datas atualizadas com sucesso.        |");
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
                
            case 99:
                ps.print("\n      ________________CALENDÁRIO_____________");
                ps.print("\n     /                                       \\");
                ps.print("\n     |  Calendário:                          |");
                ps.print("\n     |  -----------     Modo 4 - Calendário  |");
                ps.print("\n     | " + t.getValor(1) + " lembretes adicionados com sucesso.");
                ps.print("\n     | " + t.getValor(2) + " lembretes no total.");
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
                
            case 102:
                ps.print("\n      ________________CALENDÁRIO_____________");
                ps.print("\n     /                                       \\");
                ps.print("\n     |  Calendário:                          |");
                ps.print("\n     |  -----------     Modo 4 - Calendário  |");
                ps.print("\n     | Recebendo        " + t.getValor(1));
                ps.print("\n     | No dia           " + t.getValor(2) + " de cada mês");
                ps.print("\n     | Começando em     " + t.getValor(3));
                ps.print("\n     | Então em         " + t.getValor(4));
                ps.print("\n     | Terá um total de " + t.getValor(5));
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
 
            case 51:
                ps.print("\n      ________________CALENDÁRIO_____________");
                ps.print("\n     /                                       \\");
                ps.print("\n     |  Calendário:                          |");
                ps.print("\n     |  -----------     Modo 4 - Calendário  |");
                ps.print("\n     | Lembrete removido com sucesso.        |");
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
                
            case 52:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o ID do lembrete que       |");
                ps.print("\n     | pretende. (pode listá-los de forma |");
                ps.print("\n     | a saber os ID's existentes).       |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     ID: ");
                break;         
            case 100:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o nome do ficheiro a ler.  |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Ficheiro: ");
                break;                         

                
            case 601:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o valor do pagamento       |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Valor: ");
                break;
                
            case 602:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o dia de pagamento.        |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Dia: ");
                break;
                
            case 13:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o dia do lembrete.         |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Dia: ");
                break;
                
            case 12:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o mês do lembrete.         |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Mês: ");
                break;
                
            case 11:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o ano do lembrete.         |");
                ps.print("\n     | apenas são válidos valores entre   |");
                ps.print("\n     | 1 e 9999999.                       |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Ano: ");
                break;
                
            case 103:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o nome do lembrete.        |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Nome: ");
                break;
                
            case 104:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique a descrição do lembrete.   |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Descrição: ");
                break;
                
            case 23:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique a hora do lembrete.        |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Hora: ");
                break;
                
            case 22:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o minuto do lembrete       |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Minuto: ");
                break;
                
            case 500:
                String desc = t.getValor(3);
                ps.print("\n      ________________CALENDÁRIO_____________");
                ps.print("\n     /                                       \\");
                ps.print("\n     |  Lembrete:                            |");
                ps.print("\n     |  ---------       Modo 4 - Calendário  |");
                ps.print("\n     | Nome:      " + t.getValor(2));
                ps.print("\n     | ID:        " + t.getValor(1));
                ps.print("\n     |---------------------------------------");
                try{
                    ps.print("\n     | Descrição: " + desc.substring(0,25));
                } catch(StringIndexOutOfBoundsException siobe) {
                    ps.print("\n     | Descrição: " + desc.substring(0,desc.length()));
                }
                for(int i = 25; i<desc.length(); i+=37) {
                    try{
                        ps.print("\n     | "+ desc.substring(i, i+37));
                    } catch(StringIndexOutOfBoundsException siobe){
                        ps.print("\n     | "+ desc.substring(i, desc.length()));
                    }
                }
                ps.print("\n     |---------------------------------------");
                ps.print("\n     | Dia:       " + t.getValor(4));
                ps.print("\n     | Hora:      " + t.getValor(5));
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
                
            case 33:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique o dia da primeira data.    |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Dia: ");
                break;
                
            case 32:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique o mês da primeira data.    |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Mês: ");
                break;
                
            case 31:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique o ano da primeira data.    |");
                ps.print("\n     | apenas são válidos valores entre   |");
                ps.print("\n     | 1 e 9999999.                       |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Ano: ");
                break;
                
            case 605:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique o dia da data.             |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Dia: ");
                break;
                
            case 604:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique o mês da data.             |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Mês: ");
                break;
                
            case 603:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique o ano da data.             |");
                ps.print("\n     | apenas são válidos valores entre   |");
                ps.print("\n     | 1 e 9999999.                       |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Ano: ");
                break;
                            
            case 73:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique o dia da segunda data.     |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Dia: ");
                break;
                
            case 72:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique o mês da segunda data.     |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Mês: ");
                break;
                
            case 71:
                ps.print("\n      _____________CALENDÁRIO_____________");
                ps.print("\n     /                                    \\");
                ps.print("\n     | Indique o ano da segunda data.     |");
                ps.print("\n     | apenas são válidos valores entre   |");
                ps.print("\n     | 1 e 9999999.                       |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Ano: ");
                break;
                
            case 14:
                
                ps.print("\n      _______________________________CALENDÁRIO_______________________________");
                ps.print("\n     /                                                                        \\");
                ps.print("\n     | Escolha de funcionalidade:                                              |");
                ps.print("\n     |---------------------------                                              |");
                ps.print("\n     |                                                    Modo 4 - Calendário  |");
                ps.print("\n     | ----------------------------------------------------------------------- |");
                ps.print("\n     | 1  - Escreva '1'  para adicionar um lembrete.                           |");
                ps.print("\n     | 2  - Escreva '2'  para inserir um lembrete sistemático.                 |"); 
                ps.print("\n     | 3  - Escreva '3'  para inserir lembretes a partir de um ficheiro.       |"); 
                ps.print("\n     | 4  - Escreva '4'  para remover um lembrete.                             |");
                ps.print("\n     | 5  - Escreva '5'  para ver a descrição de um lembrete.                  |");
                ps.print("\n     | 6  - Escreva '6'  para ver a lista dos lembretes.                       |");
                ps.print("\n     | 7  - Escreva '7'  para ver os lembretes entre duas datas.               |");
                ps.print("\n     | 8  - Escreva '8'  para ver a lista de lembretes numa dada data.         |");
                ps.print("\n     | 9  - Escreva '9'  para ver todas as datas disponiveis no calendário.    |");                
                ps.print("\n     | 10 - Escreva '10' para ver o resultado de um pagamento sistemático.     |");
                ps.print("\n     | 11 - Escreva '11' para redefinir as datas do início e fim do calendário.|");
                ps.print("\n     | ----------------------------------------------------------------------- |");
                ps.print("\n     | Escreva '<-' para retroceder.                                           |");
                ps.print("\n     \\________________________________________________________________________/\n");
                break;
        }

    }   
}