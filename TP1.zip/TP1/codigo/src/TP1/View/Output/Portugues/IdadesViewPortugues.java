
package TP1.View.Output.Portugues;

import TP1.Utils.Input.RecebeInput;
import java.io.BufferedReader;
import java.io.Serializable;
import TP1.Utils.Tuplo.Tuplo;
import TP1.View.Output.View.Lingua;
import java.io.PrintStream;
import TP1.View.Output.View;

/**
 *  
 * Classe utilizada para apresentação dos menus
 * 
 */
public class IdadesViewPortugues implements Cloneable, Serializable, View{
    
    /**
     * Lingua em que esta classe vai imprimir
     */
    private final static Lingua L = Lingua.PORTUGUES;
    
    /**
     * Buffered Reader onde esta classe deve receber input
     */
    private BufferedReader br;
    
    /**
     * Print Stream onde esta classe deve imprimir
     */
    private PrintStream ps;
    
    /**
     * Construtor
     * 
     * @param br
     * @param ps 
     */
    public IdadesViewPortugues (BufferedReader br, PrintStream ps) {
        this.br = br;
        this.ps = ps;
    }
    
    /**
     * 
     * @return a língua desta View 
     */
    @Override
    public Lingua getLingua(){
        return L;
    }
    
    /**
     * set input
     * 
     * @param br 
     */
    @Override
    public void setInput(BufferedReader br){
        this.br = br;
    }
    
    /**
     * set output
     * 
     * @param ps 
     */
    @Override
    public void setOutput(PrintStream ps){
        this.ps = ps;
    }
    
    /**
     * 
     * 
     * @param t 
     */
    @Override
    public void imprime (Tuplo t){
        
        //ignorar
        if (t==null) return;
        
        int opcao = t.getValor(0);

	switch(opcao) {

            case -1:
                ps.print("\n      _________________IDADES________________");
                ps.print("\n     /                                       \\");
                ps.print("\n     |  Erro:                                |");
                ps.print("\n     |  -----              Modo 2 - Idades   |");
                ps.print("\n     | Forneceu dados errados para as datas. |");
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
            
            case 13:
                ps.print("\n      ________________IDADES______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o seu dia de nascimento.   |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Dia: ");
                break;
            case 12:
                ps.print("\n      ________________IDADES______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o seu mês de nascimento.   |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Mês: ");
                break;
            case 11:
                ps.print("\n      ________________IDADES______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o seu ano de nascimento.   |");
                ps.print("\n     | apenas são válidos valores entre   |");
                ps.print("\n     | 1 e 9999999.                       |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Ano: ");
                break;
            case 23:
                ps.print("\n      ________________IDADES______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique a hora do seu nascimento.  |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Hora: ");
                break;
            case 22:
                ps.print("\n      ________________IDADES______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o minuto do seu nascimento |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Minuto: ");
                break;
            case 21:
                ps.print("\n      ________________IDADES______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o segundo do seu nascimento|");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Segundo: ");
                break;
                
            case 9:
                ps.print("\n      ________________IDADES______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o dia da data em que       |");
                ps.print("\n     | pretende saber a sua idade.        |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Dia: ");
                break;
            case 8:
                ps.print("\n      ________________IDADES______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o mês da data em que       |");
                ps.print("\n     | pretende saber a sua idade.        |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Mês: ");
                break;
            case 7:
                ps.print("\n      ________________IDADES______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o ano da data em que       |");
                ps.print("\n     | pretende saber a sua idade.        |");
                ps.print("\n     | apenas são válidos valores entre   |");
                ps.print("\n     | 1 e 9999999.                       |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Ano: ");
                break;
            case 19:
                ps.print("\n      ________________IDADES______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique a hora da data em que      |");
                ps.print("\n     | pretende saber a sua idade.        |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Hora: ");
                break;
            case 18:
                ps.print("\n      ________________IDADES______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o minuto da data em que    |");
                ps.print("\n     | pretende saber a sua idade.        |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Minuto: ");
                break;
            case 17:
                ps.print("\n      ________________IDADES______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique o segundo da data em que   |");
                ps.print("\n     | pretende saber a sua idade.        |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Segundo: ");
                break;
                
            case 6:
                ps.print("\n      ________________IDADES________________");
                ps.print("\n     /                                      \\");
                ps.print("\n     |                                      |");
                ps.print("\n     | Em que unidade pretende saber os     |");
                ps.print("\n     | resultados?                          |");
                unidades(t.getValor(1));
                break;
                
            case 5:
                ps.print("\n      ________________IDADES______________");
                ps.print("\n     /                                    \\");
                ps.print("\n     |                                    |");
                ps.print("\n     | Indique a idade que terá na data   |");
                ps.print("\n     | que pretende saber.                |");
                ps.print("\n     | Escreva '<-' para retroceder.      |");
                ps.print("\n     \\___________________________________/");
                ps.print("\n     Idade: ");
                break;
                
            case 4:
                ps.print("\n      ________________IDADES________________");
                ps.print("\n     /                                      \\");
                ps.print("\n     |                                      |");
                ps.print("\n     | Em que unidade está a idade que      |");
                ps.print("\n     | indicou?                             |");
                unidades(true);
                break;
                
            case 3:
                ps.print("\n      _________________IDADES________________");
                ps.print("\n     /                                       \\");
                ps.print("\n     |  Resultado:                           |");
                ps.print("\n     |  ----------         Modo 2 - Idades   |");
                ps.print("\n     | Tendo nascido em: " + t.getValor(1));
                ps.print("\n     | então, na data:   " + t.getValor(2));
                ps.print("\n     | Tem a idade:      " + t.getValor(3) +" "+t.getValor(4));
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
                
            case 2:
                ps.print("\n      ___________________IDADES__________________");
                ps.print("\n     /                                           \\");
                ps.print("\n     |  Resultado:                               |");
                ps.print("\n     |  ----------             Modo 2 - Idades   |");
                ps.print("\n     | Tendo nascido em:   " + t.getValor(1));
                ps.print("\n     | então, tem a idade: " + t.getValor(2) +" "+t.getValor(4));
                ps.print("\n     | Na data:            " + t.getValor(3));
                ps.print("\n     \\___________________________________________/");
                ps.print("\n     |        Prima ENTER para continuar         |");
                ps.print("\n     \\___________________________________________/");
                RecebeInput.esperarEnter(br);
                break;
                
            case 1:
                ps.print("\n      _________________IDADES________________");
                ps.print("\n     /                                       \\");
                ps.print("\n     |  Resultado:                           |");
                ps.print("\n     |  ----------         Modo 2 - Idades   |");
                ps.print("\n     | Tendo nascido em:  " + t.getValor(1));
                ps.print("\n     | Sendo hoje:        " + t.getValor(2));
                ps.print("\n     | Fará anos daqui a: " + t.getValor(3) +" "+t.getValor(4));
                ps.print("\n     \\_______________________________________/");
                ps.print("\n     |        Prima ENTER para continuar     |");
                ps.print("\n     \\_______________________________________/");
                RecebeInput.esperarEnter(br);
                break;
                
            case 14:
                
                ps.print("\n      _______________________________________IDADES______________________________________");
                ps.print("\n     /                                                                                   \\");
                ps.print("\n     | Escolha de funcionalidade:                                                         |");
                ps.print("\n     |---------------------------                                                         |");
                ps.print("\n     |                                                                  Modo 2 - Idades   |");
                ps.print("\n     | ---------------------------------------------------------------------------------- |");
                ps.print("\n     | 1 - Escreva '1' para ver a sua idade numa data específica.                         |");
                ps.print("\n     | 2 - Escreva '2' para ver a data em que terá uma idade específica.                  |");
                ps.print("\n     | 3 - Escreva '3' para ver quanto tempo falta para o seu aniversário.                |");
                ps.print("\n     | ---------------------------------------------------------------------------------- |");
                ps.print("\n     | Escreva '<-' para retroceder.                                                      |");
                ps.print("\n     \\___________________________________________________________________________________/\n");
                break;
        }

    }   
    
    private void unidades(Boolean tudo){
        ps.print("\n     | ---|-------------------------------- |");
        ps.print("\n     | 1  | Escreva '1' para nanosegundos.  |");
        ps.print("\n     | 2  | Escreva '2' para microsegundos. |");
        ps.print("\n     | 3  | Escreva '3' para milisegundos.  |");
        ps.print("\n     | 4  | Escreva '4' para segundos.      |");
        ps.print("\n     | 5  | Escreva '5' para minutos.       |");
        ps.print("\n     | 6  | Escreva '6' para horas.         |");
        ps.print("\n     | 7  | Escreva '7' para dias.          |");
        ps.print("\n     | 8  | Escreva '8' para semanas.       |");
        ps.print("\n     | 9  | Escreva '9' para mês.           |");
        if (tudo){
            ps.print("\n     | 10 | Escreva '10' para anos.         |");
            ps.print("\n     | 11 | Escreva '11' para décadas.      |");
            ps.print("\n     | 12 | Escreva '12' para centenas.     |");
            ps.print("\n     | 13 | Escreva '13' para milénios.     |");
        }
        ps.print("\n     | ---|-------------------------------- |");
        ps.print("\n     | Escreva '<-' para retroceder.        |");
        ps.print("\n     \\____________________________________/");
        ps.print("\n     Unidade: ");
    }
}