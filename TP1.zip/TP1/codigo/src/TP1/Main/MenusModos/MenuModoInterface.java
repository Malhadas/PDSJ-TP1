
package TP1.Main.MenusModos;

import TP1.Controler.Controler;
import TP1.Main.MenusModos.MenuModoInterface.Modo;
import TP1.Utils.Tuplo.Tuplo;
import java.io.IOException;

/**
 * Descreve um Menu que encapsula estado.
 * 
 * Este menu é capaz de operar sobre o seu próprio
 * estado. Implementações deste Menu devem utilizar
 * um Controler para comunicar com o seu estado.
 * 
 * O método mais importante desta interface é então
 * menuEntrada já que este permitirá navegar pelo menu
 * que for implementado, note-se que o Controler pode ser
 * criado no interior deste método podendo então ser
 * devolvido e acessado no exterior se houver interesse
 * para tal.
 */
public interface MenuModoInterface {
    
    /**
     * Define um modo de funcionamento do menu para depois ser usado
     * no DefaultFactory desta Interface e instanciar um novo
     * Menu sem que quem o faça tenha de ter conhecimento
     * algum sobre o Menu específico que implementa esta
     * interface.
     * 
     * Isto pode ser ignorado por quem decidir fazer uma classe que
     * implemente esta Interface e pode simplesmente instânciar novos
     * controlers não definidos no DefaultFactory se assim entender.
     */
    public enum Modo {
        M1, M2, M3, M4, M5, NONE
    }
    
    /**
     * Pode ser usado para definir o modo por
     * dfeito.
     */
    public static final Modo ULTIMO_MODO = Modo.NONE;
    
    /**
     * Recebe um Tuplo t que encapsula informação necessária
     * para o menu. Cabe às implementações específicas desta 
     * Interface definir o conteúdo e formato que este Tuplo 
     * deve ter.
     * 
     * @param t
     * @return controler a que este menu é relativo
     */
    public Controler menuEntrada(Tuplo t);
    
    /**
     * Devolve o modo a que este menu se refere, definido no enum Modo
     * 
     * @return modo de funcionamento
     */
    public Modo getModo();
    
    /**
     * Permite guardar o estado do menu num
     * ficheiro com o nome argumento.
     * 
     * @param ficheiro
     * @throws IOException 
     */
    public void guardarEstado(String ficheiro) throws IOException;
    
    /**
     * Permite carregar o estado deste menu de um
     * ficheiro com o nome argumento.
     * 
     * @param ficheiro
     * @throws IOException
     * @throws ClassNotFoundException 
     */
    public void carregarEstado(String ficheiro) throws IOException, ClassNotFoundException;
    
    /**
     * Permite apagar o estado do menu reinicializando
     * as suas variáveis de classe
     */
    public void apagarEstado();
    
    /**
     * Design Pattern DefaultFactory
     * 
     * Esta classe permite instanciar um novo Menu sem que 
     * quem o faça tenha de ter conhecimento algum sobre o
     * Menu específico que implementa esta interface.
     * 
     * Isto pode ser ignorado por quem decidir fazer uma classe que
     * implemente esta Interface e pode simplesmente instânciar novos
     * menus não definidos no DefaultFactory se assim entender.
     */
    public class DefaultFactory {
        
        /**
         * Cria um Menu recebendo um Tuplo t. O primeiro
         * elemento do Tuplo deve ser o Modo do menu e os
         * restantes elementos ficam reservados para algum
         * argumento que o Menu específico necessite para ser
         * instanciado.
         * 
         * @param t
         * @return Devolve uma instância do menu específico
         */
        public static MenuModoInterface create(Tuplo t) {
            Modo modo = t.getValor(0);
            switch(modo){
                case M1:
                    return new MenuCronometro();
                case M2:
                    return new MenuIdades();
                case M3:
                    return new MenuViagens(t.getValor(1),t.getValor(2),t.getValor(3));
                case M4:
                    return new MenuCalendario(t.getValor(1),t.getValor(2),t.getValor(3));
                case M5:
                    return new MenuConfiguracao();
                default:
                    return null;
            }     
        }
    }
}
