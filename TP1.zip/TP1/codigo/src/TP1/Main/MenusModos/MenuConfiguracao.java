
package TP1.Main.MenusModos;

import TP1.Controler.Controler;
import TP1.Controler.Controler.TipoControler;
import TP1.Controler.Controler.TipoPedido;
import TP1.Exceptions.GoBackException;
import TP1.Main.MenusModos.MenuModoInterface.Modo;
import TP1.Model.EstadoConfiguracao.CalculadoraEstadoModel;
import TP1.Model.EstadoConfiguracao.CalculadoraEstadoQueriesInterface.QuerieConfiguracao;
import TP1.Model.Model;
import TP1.Utils.Input.RecebeInput;
import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import TP1.View.Output.View;
import TP1.View.Output.View.TipoView;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;

/**
 * Encapsula o estado do modo de configuração e permite navegação do seu menu
 */
public class MenuConfiguracao implements MenuModoInterface{
    /**
     * model com o estado deste menu
     */
    private Model modo5;
    
    /**
     * modo deste menu
     */
    private static final Modo MODO = Modo.M5;
    
    /**
     * construtor
     * 
     */
    public MenuConfiguracao(){
        final TuploTipo ti = TuploTipo.DefaultFactory.create(Modo.class);
        modo5 = Model.DefaultFactory.create(ti.criar(MODO));
    }

    /**
     * Inicia o Menu deste modo
     * 
     *  O Tuplo args argumento deve conter os seguintes valores:
     * 
     *  View ol       = arg.getValor(0);
     *  0 ou 1        = arg.getValor(1);
     *  se 0 Tuplo tu = arg.getValor(2);
     *  se 1 PrintStream ps    = arg.getValor(2);
     *     e BufferedReader br = arg.getValor(3);
     * 
     * @param arg
     * @return 
     */
    @Override
    public Controler menuEntrada(Tuplo arg){
        View ol     = arg.getValor(0);
        Controler c = Controler.DefaultFactory.create(ol, modo5, TipoControler.CALCULADORA);
        
        int op = arg.getValor(1);
        switch(op){
            case 0:
                c.realizaPedido(arg.getValor(2));
            case 1:
                return c.clone();
        }
        PrintStream ps    = arg.getValor(2);
        BufferedReader br = arg.getValor(3);

        final TuploTipo t = TuploTipo.DefaultFactory
                             .create(TipoPedido.class, 
                                     QuerieConfiguracao.class, 
                                     Number.class);
        final Tuplo t1 = t.criar(TipoPedido.MODEL, 
                                       QuerieConfiguracao.GETZONA, 12);
            
        while (true){
            c.realizaPedido(t1);
            int conf;
            try {
                conf = RecebeInput.lerInt(br);
            } catch (GoBackException ex) {
                return c.clone();
            }
            
            if (conf == 1) {
                try {
                    mudarFuso(c,br);
                } catch (GoBackException ex) {
                    continue;
                }
                break;
            }
            if (conf == 2) {
                final TuploTipo tt = TuploTipo.DefaultFactory
                             .create(TipoPedido.class,
                                     QuerieConfiguracao.class, 
                                     Number.class);
                View a = View.DefaultFactory.create(ol.getLingua(), 
                                                    TipoView.APRESENTACAO, 
                                                    br, ps, c);
                Controler c2 = Controler.DefaultFactory.create(a, modo5, TipoControler.CALCULADORA);
                c2.realizaPedido(tt.criar(TipoPedido.MODEL, 
                                                QuerieConfiguracao.GETZONAS_DISPONIVEIS, 14));
            }
        }
        
        return c.clone();
    }
    
        
    private void mudarFuso(Controler c, BufferedReader br) throws GoBackException {
        final TuploTipo t = TuploTipo.DefaultFactory
                                     .create(TipoPedido.class,QuerieConfiguracao.class,Number.class);
        final Tuplo t1 = t.criar(TipoPedido.MODEL, 
                                       QuerieConfiguracao.GETZONA, 9);
        final Tuplo t2 = t.criar(TipoPedido.MODEL, 
                                       QuerieConfiguracao.GETZONA, 10);
        
        c.realizaPedido(t1);
        String continente = RecebeInput.lerLinha(br);

        c.realizaPedido(t2);
        String cidade = RecebeInput.lerLinha(br);

        final TuploTipo tt = TuploTipo.DefaultFactory
                             .create(TipoPedido.class,
                                     QuerieConfiguracao.class,
                                     String.class,
                                     String.class
                                    );
        c.realizaPedido(tt.criar(TipoPedido.MODEL, 
                                       QuerieConfiguracao.SETZONA, continente, cidade));
    }
    
    /**
     * Guarda estado do model deste menu no ficheiro argumento
     * 
     * @param ficheiro
     * @throws IOException 
     */
    @Override
    public void guardarEstado(String ficheiro) throws IOException {
        try(
            FileOutputStream fout  = new FileOutputStream(ficheiro, true);
            ObjectOutputStream oos = new ObjectOutputStream(fout);
            ){
                oos.writeObject(modo5);
        } catch (IOException ex) {
            throw new IOException();
        }
    }

    /**
     * Carrega o estado do model deste menu apartir do ficheiro argumento
     * 
     * @param ficheiro
     * @throws IOException
     * @throws ClassNotFoundException 
     */
    @Override
    public void carregarEstado(String ficheiro) throws IOException, ClassNotFoundException{
        FileInputStream fin = new FileInputStream(ficheiro);
        ObjectInputStream ois = new ObjectInputStream(fin);
        try {
            this.modo5 = (Model) (CalculadoraEstadoModel) ois.readObject();
        } catch (ClassCastException cce){
            throw new IOException();
        }
    }

    /**
     * reinicializa o model
     */
    @Override
    public void apagarEstado(){
        final TuploTipo ti = TuploTipo.DefaultFactory.create(Modo.class);
        modo5 = Model.DefaultFactory.create(ti.criar(MODO));
    }

    /**
     * 
     * @return o modo deste menu
     */
    @Override
    public Modo getModo() {
        return MenuConfiguracao.MODO;
    }
}
