
package TP1.Main.MenusModos;

import TP1.Main.MenusAuxiliares.MenuData;
import TP1.Controler.Controler;
import TP1.Controler.Controler.TipoControler;
import TP1.Controler.Controler.TipoPedido;
import TP1.Exceptions.GoBackException;
import TP1.Exceptions.RepeatException;
import TP1.Main.MenusAuxiliares.MenuLerFicheiro;
import TP1.Main.MenusModos.MenuModoInterface.Modo;
import TP1.Model.EstadoConfiguracao.CalculadoraEstadoQueriesInterface.QuerieConfiguracao;
import TP1.Model.Model;
import TP1.Model.Modulos.Viagens.ViagensModel;
import TP1.Model.Modulos.Viagens.ViagensQueriesInterface.QuerieViagens;
import TP1.Utils.Input.RecebeInput;
import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import TP1.View.Output.View;
import TP1.View.Output.View.TipoView;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.util.Collection;

/**
 *
 */
public class MenuViagens implements MenuModoInterface{
    
    private Model modo3;
    private static final Modo MODO = Modo.M3;
    
    public MenuViagens(String preco, String duracao, String data){
        final TuploTipo ti = TuploTipo.DefaultFactory.create(Modo.class,String.class,
                                                             String.class,String.class);
        modo3 = Model.DefaultFactory.create(ti.criar(MODO,preco,duracao,data));
    }
    
    /**
     * Inicia o Menu deste modo
     * 
     *  O Tuplo args argumento deve conter os seguintes valores:
     * 
     *  PrintStream ps    = arg.getValor(0);
     *  BufferedReader br = arg.getValor(1);
     *  Controler c1      = arg.getValor(2);
     *  View ol           = arg.getValor(3);
     * 
     * @param arg
     * @return 
     */
    @Override
    public Controler menuEntrada(Tuplo arg) {
        TuploTipo tt;
        View v;
        Controler c2;
        PrintStream ps    = arg.getValor(0);
        BufferedReader br = arg.getValor(1);
        Controler c1      = arg.getValor(2);
        View ol           = arg.getValor(3);
        
        v  = View.DefaultFactory.create(ol.getLingua(),TipoView.VIAGENS,br, ps, null);
        c2 = Controler.DefaultFactory.create(v,modo3,TipoControler.CALCULADORA);
                
        while (true) {
            tt = TuploTipo.DefaultFactory
                          .create(TipoPedido.class,QuerieConfiguracao.class,Number.class);
            c1.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2));
            
            tt = TuploTipo.DefaultFactory
                          .create(Number.class);                        
            v.imprime(tt.criar(14));
            
            int opcao;
            try {
                opcao = RecebeInput.lerInt(br);
            } catch (GoBackException ex) {
                return c2.clone();
            }
            
            switch(opcao){

                case 1:                    
                    querie1(br,v,c1,c2);
                    break;
                case 2:
                    querieLer(br,v,c1,c2);
                    break;
                case 3:
                    querieID(br,v,c1,c2, QuerieViagens.APAGAR);
                    break;
                    
                case 4:
                    querie3(br,ps,v,c1,c2);
                    break;

                case 5:
                    querieTop(br,ps,v,c1,c2,QuerieViagens.LISTARTOP_PRECODEC);
                    break;
                    
                case 6:
                    querieTop(br,ps,v,c1,c2,QuerieViagens.LISTARTOP_PRECOCRESC);
                    break;
                case 7:
                    querieTop(br,ps,v,c1,c2,QuerieViagens.LISTARTOP_TEMPODEC);
                    break;
                case 8:
                    querieTop(br,ps,v,c1,c2,QuerieViagens.LISTARTOP_TEMPOCRESC);
                    break;
                case 9:
                    querieEntre(br,ps,v,c1,c2,QuerieViagens.LISTARENTRE_DATASCRESC);
                    break;
                case 10:
                    querieEntre(br,ps,v,c1,c2,QuerieViagens.LISTARENTRE_DATASDEC);
                    break;
                case 11:
                    querieID(br,v,c1,c2,QuerieViagens.DATACHEGADA);
                    break;
                case 12:
                    querieTotal(br,v,c1,c2,QuerieViagens.TOTALPAGO);
                    break;
                case 13:
                    querieTotal(br,v,c1,c2,QuerieViagens.TOTALTEMPO);
                    break;
                case 14:
                    querieTotal(br,v,c1,c2,QuerieViagens.TOTALTEMPOGANHO);
                    break;
            }
            
        }
        
    }

    private static void querieLer(BufferedReader br, View v, Controler c1, Controler c2){
        try {
            Collection<String> c = MenuLerFicheiro.lerFicheiro(br, v, c1, 100);
            final TuploTipo tt = TuploTipo.DefaultFactory
                                          .create(TipoPedido.class,
                                                  QuerieViagens.class,
                                                  Collection.class);  
            final TuploTipo tc = TuploTipo.DefaultFactory
                                          .create(TipoPedido.class,
                                                  QuerieConfiguracao.class,
                                                  Number.class);
            
            c1.realizaPedido(tc.criar(TipoPedido.MODEL,
                                            QuerieConfiguracao.GETZONA,-2));
            c2.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieViagens.LER,c));
        } catch (GoBackException ex) {
            // voltar atrás
        }
    }
    
    private static void querieEntre(BufferedReader br, PrintStream ps, View v, Controler c1, Controler c2, QuerieViagens qv){
        final TuploTipo tt = TuploTipo.DefaultFactory
            .create(TipoPedido.class,QuerieViagens.class,
                    Controler.class,String.class, String.class,
                    String.class, String.class);
        Controler gereApresentacao;
        View a;
        
        while(true){
            String d1, d2, f1, f2;
            Tuplo t;
            try{
                t  = MenuData.lerDataHora(br, v, c1, 33);
                d1 = t.getValor(0);
                f1 = t.getValor(1);
            } catch(GoBackException gb){
                break;
            }
            try{
                t  = MenuData.lerDataHora(br, v, c1, 73);
                d2 = t.getValor(0);
                f2 = t.getValor(1);
                a = View.DefaultFactory.create(v.getLingua(),TipoView.APRESENTACAO, 
                                               br, ps, c1);
    
                gereApresentacao = Controler.DefaultFactory
                                            .create(a, null, TipoControler.CALCULADORA);
                c2.realizaPedido(tt.criar(TipoPedido.MODEL,qv,gereApresentacao,
                                                d1,f1,d2,f2));
            } catch (GoBackException gb){ 
            }
        }
    }
    
    private static void querieTop(BufferedReader br, PrintStream ps, View v, Controler c1, Controler c2, QuerieViagens qv){
        final TuploTipo tt = TuploTipo.DefaultFactory
                                      .create(TipoPedido.class,QuerieViagens.class,
                                              Controler.class,Number.class);   
        final TuploTipo ttt = TuploTipo.DefaultFactory.create(Number.class); 
        final TuploTipo te = TuploTipo.DefaultFactory.create(TipoPedido.class,
                                                             QuerieConfiguracao.class,
                                                             Number.class);
        final Tuplo t = te.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2);
        int i;
        View a;
        Controler gereApresentacao;
        
        c1.realizaPedido(t);
        v.imprime(ttt.criar(5));
        
        try {
            i = RecebeInput.lerInt(br);
        } catch (GoBackException go){
            return;
        }
        
        a = View.DefaultFactory.create(v.getLingua(),TipoView.APRESENTACAO, 
                                       br, ps, c1);

        gereApresentacao = Controler.DefaultFactory.create(a, null, 
                                                           TipoControler.CALCULADORA);
        c2.realizaPedido(tt.criar(TipoPedido.MODEL,qv,gereApresentacao,i));
    }
    
    private static void querie3(BufferedReader br, PrintStream ps, View v, Controler c1, Controler c2){
        final TuploTipo tt = TuploTipo.DefaultFactory
            .create(TipoPedido.class,QuerieViagens.class,Controler.class);  
        
        View a = View.DefaultFactory.create(v.getLingua(),TipoView.APRESENTACAO, 
                                            br, ps, c1);    
        Controler gereApresentacao = Controler.DefaultFactory
                                              .create(a, null, TipoControler.CALCULADORA);
        c2.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieViagens.LISTAR,
                                        gereApresentacao));
    }
    
    private static void querieID(BufferedReader br, View v, Controler c1, Controler c2, QuerieViagens qv){
        final TuploTipo tt = TuploTipo.DefaultFactory.create(TipoPedido.class,
                                                             QuerieConfiguracao.class,
                                                             Number.class);
        TuploTipo ttt; int i;
        final Tuplo t = tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2);

        while(true){
            c1.realizaPedido(t);
            ttt = TuploTipo.DefaultFactory
                           .create(Number.class);                        
            v.imprime(ttt.criar(52));
            try {
                i = RecebeInput.lerInt(br);
            } catch (GoBackException go){
                break;
            }
                        
                        
            ttt = TuploTipo.DefaultFactory.create(TipoPedido.class,
                                  QuerieViagens.class,Number.class);     
            c1.realizaPedido(t);
            c2.realizaPedido(ttt.criar(TipoPedido.MODEL,qv,i));
            return;
        }
    }
    
    private static String lerZona(Controler c1, View v, BufferedReader br, int indice) throws GoBackException{ 
        final TuploTipo tt = TuploTipo.DefaultFactory
                 .create(TipoPedido.class,QuerieConfiguracao.class,Number.class);
        final Tuplo t = tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2);
        TuploTipo ttt;
        String s1,s2;
        
        while(true){
            c1.realizaPedido(t);

            ttt = TuploTipo.DefaultFactory
                          .create(Number.class);                        
            v.imprime(ttt.criar(indice));
            s1 = RecebeInput.lerLinha(br);

            while(true){
                c1.realizaPedido(t);

                ttt = TuploTipo.DefaultFactory
                          .create(Number.class);                        
                v.imprime(ttt.criar(indice+1));
                try{
                    s2 = RecebeInput.lerLinha(br);
                    
                    return s1+'/'+s2;
                } catch (GoBackException go) {
                    break;
                }
            }
        }
    }
    
    private static void querie1(BufferedReader br, View v, Controler c1, Controler c2){
        TuploTipo ttt;
        final TuploTipo te = TuploTipo.DefaultFactory.create(TipoPedido.class,
                                                             QuerieConfiguracao.class,
                                                             Number.class);
        final Tuplo tee = te.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2);
        
        while(true){
            String d, f, z1,z2;
            Tuplo t;
            long n;
            double p;
            
            try {
                t = MenuData.lerDataHora(br, v, c1, 13);
                d = t.getValor(0);
                f = t.getValor(1);
            } catch (GoBackException ex) {
                break;
            }

            
            while(true){
                try{
                    z1 = lerZona(c1,v,br,60);
                    z2 = lerZona(c1,v,br,62);
                } catch (GoBackException gb){
                    break;
                }

                while(true){
                    ttt = TuploTipo.DefaultFactory
                          .create(Number.class);                        
                    v.imprime(ttt.criar(2));
                    try {
                        n = RecebeInput.lerLong(br);
                    } catch (RepeatException ex) {
                        continue;
                    } catch (GoBackException go){
                        break;
                    }
                    
                     while(true){
                        ttt = TuploTipo.DefaultFactory
                              .create(Number.class);                        
                        v.imprime(ttt.criar(50));
                        try {
                            p = RecebeInput.lerDouble(br);
                        } catch (GoBackException go){
                            break;
                        }
                        
                        
                        ttt = TuploTipo.DefaultFactory
                        .create(TipoPedido.class,QuerieViagens.class,
                          String.class, String.class, Number.class,
                          String.class, String.class, Number.class
                        );     
                                        
                        c1.realizaPedido(tee);
                        c2.realizaPedido(ttt.criar(TipoPedido.MODEL,
                                        QuerieViagens.ADDICIONAR,z1,z2,n,d,f,p));
                        return;
                    }  
                }
            }
        }
    }

    private static void querieTotal(BufferedReader br, View v, Controler c1, Controler c2, QuerieViagens qv) {
        final TuploTipo tt = TuploTipo.DefaultFactory
            .create(TipoPedido.class,QuerieViagens.class,
                    String.class, String.class,String.class, String.class);
        final TuploTipo te = TuploTipo.DefaultFactory.create(TipoPedido.class,
                                                             QuerieConfiguracao.class,
                                                             Number.class);
        final Tuplo tee = te.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2);
        
        while(true){
            String d1, d2, f1, f2;
            Tuplo t;
            try{
                t  = MenuData.lerDataHora(br, v, c1, 33);
                d1 = t.getValor(0);
                f1 = t.getValor(1);
            } catch(GoBackException gb){
                break;
            }
            try{
                t  = MenuData.lerDataHora(br, v, c1, 73);
                d2 = t.getValor(0);
                f2 = t.getValor(1);
                
                c1.realizaPedido(tee);
                c2.realizaPedido(tt.criar(TipoPedido.MODEL,qv, d1,f1,d2,f2));
            } catch (GoBackException gb){ 
            }
        }  
    }

    /**
     * Guarda o estado do model deste menu no ficheiro argumento
     * 
     * @param ficheiro
     * @throws IOException 
     */
    @Override
    public void guardarEstado(String ficheiro) throws IOException {
        try(
            FileOutputStream fout  = new FileOutputStream(ficheiro, true);
            ObjectOutputStream oos = new ObjectOutputStream(fout);
            ){
                oos.writeObject(modo3);
        } catch (IOException ex) {
            throw new IOException();
        }
    }

    /**
     * Carrega o estado do model deste menu apartir do ficheiro argumento
     * 
     * @param ficheiro
     * @throws IOException
     * @throws ClassCastException
     * @throws ClassNotFoundException 
     */
    @Override
    public void carregarEstado(String ficheiro) throws IOException, ClassCastException, ClassNotFoundException{
        FileInputStream fin = new FileInputStream(ficheiro);
        ObjectInputStream ois = new ObjectInputStream(fin);
        try {
            this.modo3 = (Model) (ViagensModel) ois.readObject();
        } catch (ClassCastException cce){
            throw new IOException();
        }
    }

    /**
     * Reinicializa o model deste menu
     */
    @Override
    public void apagarEstado() {
        final TuploTipo ti = TuploTipo.DefaultFactory.create(Modo.class);
        modo3 = Model.DefaultFactory.create(ti.criar(MODO));
    }

    /**
     * 
     * @return modo deste menu 
     */
    @Override
    public Modo getModo() {
        return MenuViagens.MODO;
    }

        
}
