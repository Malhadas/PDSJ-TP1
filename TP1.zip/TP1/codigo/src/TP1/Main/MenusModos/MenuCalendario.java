
package TP1.Main.MenusModos;

import TP1.Main.MenusAuxiliares.MenuData;
import TP1.Controler.Controler;
import TP1.Controler.Controler.TipoControler;
import TP1.Controler.Controler.TipoPedido;
import TP1.Exceptions.GoBackException;
import TP1.Main.MenusAuxiliares.MenuLerFicheiro;
import TP1.Main.MenusModos.MenuModoInterface.Modo;
import TP1.Model.EstadoConfiguracao.CalculadoraEstadoQueriesInterface.QuerieConfiguracao;
import TP1.Model.Model;
import TP1.Model.Modulos.Calendario.CalendarioModel;
import TP1.Model.Modulos.Calendario.CalendarioQueriesInterface.QuerieCalendario;
import TP1.Utils.Input.RecebeInput;
import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import TP1.View.Output.View;
import TP1.View.Output.View.TipoView;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.util.Collection;

/**
 * Encapsula o estado do modo calendario e permite navegação do seu menu
 */
public class MenuCalendario implements MenuModoInterface{
    
    /**
     * modelo com o estado
     */
    private Model modo4;
    
    /**
     * modo deste menu
     */
    private static final Modo MODO = Modo.M4;
    
    /**
     * Construtor
     * 
     * recebe 3 setings.
     * a primeira indica o que se pretende que apareça antes do dia absoluto do ano
     * (exemplo: dia do ano: 200)
     * a segunda é a mesnagem que deve ser apresentada quando um ano é bissexto e
     * a terceira quando o ano é não bissexto.
     * 
     * @param s1
     * @param s2
     * @param s3 
     */
    public MenuCalendario(String s1, String s2, String s3){
        final TuploTipo ttt = TuploTipo.DefaultFactory.create(Modo.class,String.class, 
                                                      String.class, String.class);
        modo4 = Model.DefaultFactory.create(ttt.criar(MODO,s1,s2,s3));
    }
    
    /**
     * Inicia o Menu deste modo
     * 
     *  O Tuplo args argumento deve conter os seguintes valores:
     * 
     *  PrintStream ps    = arg.getValor(0);
     *  BufferedReader br = arg.getValor(1);
     *  Controler c1      = arg.getValor(2);
     *  View ol           = arg.getValor(3);
     * 
     * @param arg
     * @return 
     */
    @Override
    public Controler menuEntrada(Tuplo arg) {
        View v;
        Controler c2;
        PrintStream ps    = arg.getValor(0);
        BufferedReader br = arg.getValor(1);
        Controler c1      = arg.getValor(2);
        View ol           = arg.getValor(3);
        
        v  = View.DefaultFactory.create(ol.getLingua(),TipoView.CALENDARIO,br, ps, null);
        c2 = Controler.DefaultFactory.create(v,modo4,TipoControler.CALCULADORA);
        
        return menuPrincipal(ps,br,c1,c2,v);
    }

    private Controler menuPrincipal(PrintStream ps, BufferedReader br, Controler c1, Controler c2, View v) {
        TuploTipo tt;      
        
        while (true) {
            tt = TuploTipo.DefaultFactory
                          .create(TipoPedido.class,QuerieConfiguracao.class,Number.class);
            c1.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2));
            
            tt = TuploTipo.DefaultFactory.create(Number.class);                        
            v.imprime(tt.criar(14));
            
            int opcao;
            try {
                opcao = RecebeInput.lerInt(br);
            } catch (GoBackException ex) {
                return c2.clone();
            }
            
            switch(opcao){
                case 1:                    
                    querieAdd(br,v,c1,c2, QuerieCalendario.ADDICIONAR);
                    break;
                case 2:                    
                    querieAdd(br,v,c1,c2, QuerieCalendario.ADDICIONAR_SISTEMATICO);
                    break;
                case 3:
                    querieLer(br,v,c1,c2);
                    break;
                case 4:
                    querieID(br,v,c1,c2, QuerieCalendario.APAGAR);
                    break;
                case 5:
                    querieID(br,v,c1,c2, QuerieCalendario.CONSULTAR);
                    break;
                case 6:
                    querieListar(br,ps,v,c1,c2,QuerieCalendario.LISTARLEMBRETES);
                    break;
                case 9:
                    querieListar(br,ps,v,c1,c2,QuerieCalendario.LISTARDATAS);
                    break;
                case 8:
                    querieParaData(br,ps,v,c1,c2);
                    break;
                case 7:
                    querieEntre(br,ps,v,c1,c2,QuerieCalendario.LISTARLEMBRETES_ENTREDATAS);
                    break;
                case 10:
                    queriePagamentoSistematico(br,v,c1,c2);
                    break;
                case 11:
                    querieRedefinir(br,v,c1,c2);
                    break;
            }
            
        }
        
    }
    
    private static void querieAdd(BufferedReader br, View v, Controler c1, Controler c2, QuerieCalendario qc){
        final TuploTipo tt = TuploTipo.DefaultFactory
                              .create(TipoPedido.class,QuerieConfiguracao.class,
                                      Number.class);
        final Tuplo te = tt.criar(TipoPedido.MODEL, 
                                        QuerieConfiguracao.GETZONA,-2);
        
        TuploTipo ttt = TuploTipo.DefaultFactory.create(Number.class);

        String n,d,h1,h2,d1,d2;
        Tuplo t;

        while(true){
            c1.realizaPedido(te);
            v.imprime(ttt.criar(103));
            try {
                n = RecebeInput.lerLinha(br);
            } catch (GoBackException ex) {
                break;
            }

            c1.realizaPedido(te);
            v.imprime(ttt.criar(104));
            try {
                d = RecebeInput.lerLinha(br);
            } catch (GoBackException ex) {
                continue;
            }

            while(true){
                try{
                    t  = MenuData.lerHora(br, v, c1, 13);
                    h1 = t.getValor(0);
                    h2 = t.getValor(1);
                }catch (GoBackException ex){
                      break;  
                }
                try{
                    t  = MenuData.lerData(br, v, c1, 13);
                    d1 = t.getValor(0);
                    d2 = t.getValor(1);
                } catch (GoBackException gb){
                    continue;
                }

                ttt = TuploTipo.DefaultFactory
                    .create(TipoPedido.class,QuerieCalendario.class,
                      String.class, String.class, String.class,
                      String.class, String.class, String.class
                    );     
                c1.realizaPedido(te);
                c2.realizaPedido(ttt.criar(TipoPedido.MODEL,
                                 qc,n,d,h1,h2,d1,d2));
                return;
            }
        }
    }

    private static void querieLer(BufferedReader br, View v, Controler c1, Controler c2){
        try {
            Collection<String> c = MenuLerFicheiro.lerFicheiro(br, v, c1, 100);
            final TuploTipo tt = TuploTipo.DefaultFactory.create(TipoPedido.class,
                                                            QuerieCalendario.class,
                                                            Collection.class);
            final TuploTipo te = TuploTipo.DefaultFactory.create(TipoPedido.class,
                                                            QuerieConfiguracao.class,
                                                            Number.class);
            final Tuplo t = te.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2);
            
            c1.realizaPedido(t);
            c2.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieCalendario.LER,c));
        } catch (GoBackException ex) {
            // voltar atrás
        }
    }
    
    private static void querieEntre(BufferedReader br, PrintStream ps, View v, Controler c1, Controler c2, QuerieCalendario qc){
        final TuploTipo tt = TuploTipo.DefaultFactory
            .create(TipoPedido.class,QuerieCalendario.class,
                    Controler.class,String.class, String.class,
                    String.class, String.class);
        
        while(true){
            String d1, d2, f1, f2;
            Tuplo t;
            try{
                t  = MenuData.lerData(br, v, c1, 33);
                d1 = t.getValor(0);
                f1 = t.getValor(1);
            } catch(GoBackException gb){
                break;
            }
            try{
                t  = MenuData.lerData(br, v, c1, 73);
                d2 = t.getValor(0);
                f2 = t.getValor(1);
                View a = View.DefaultFactory.create(v.getLingua(),TipoView.APRESENTACAO, 
                                                    br, ps, c1);
                Controler gereApresentacao = Controler.DefaultFactory
                                                .create(a, null, TipoControler.CALCULADORA);
                c2.realizaPedido(tt.criar(TipoPedido.MODEL,qc,gereApresentacao,
                                                d1,f1,d2,f2));
            } catch (GoBackException gb){ 
            }
        }
    }
    
    private static void querieRedefinir(BufferedReader br, View v, Controler c1, Controler c2){
        final TuploTipo tt = TuploTipo.DefaultFactory
            .create(TipoPedido.class, QuerieCalendario.class,
                    String.class,     String.class,
                    String.class,     String.class);
        
        while(true){
            String d1, d2, f1, f2;
            Tuplo t;
            try{
                t  = MenuData.lerData(br, v, c1, 33);
                d1 = t.getValor(0);
                f1 = t.getValor(1);
            } catch(GoBackException gb){
                break;
            }
            try{
                t  = MenuData.lerData(br, v, c1, 73);
                d2 = t.getValor(0);
                f2 = t.getValor(1);
                c2.realizaPedido(tt.criar(TipoPedido.MODEL,
                                                QuerieCalendario.INICIALIZAR,
                                                d1,f1,d2,f2));
            } catch (GoBackException gb){ 
            }
        }
    }
    
    private static void querieParaData(BufferedReader br, PrintStream ps, View v, Controler c1, Controler c2){
        final TuploTipo tt = TuploTipo.DefaultFactory
            .create(TipoPedido.class,QuerieCalendario.class,
                    Controler.class,String.class, String.class);
        
        while(true){
            try{
                Tuplo t   = MenuData.lerData(br, v, c1, 33);
                String d1 = t.getValor(0);
                String f1 = t.getValor(1);
                
                View a = View.DefaultFactory.create(v.getLingua(),TipoView.APRESENTACAO, 
                                                br, ps, c1);
                Controler gereApresentacao = Controler.DefaultFactory
                                                .create(a, null, TipoControler.CALCULADORA);
                c2.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieCalendario.LISTARLEMBRETES_DATA,
                                                gereApresentacao,d1,f1));
                return;
            } catch(GoBackException gb){
                break;
            }
        }
    }
    
    private static void querieListar(BufferedReader br, PrintStream ps, View v, Controler c1, Controler c2, QuerieCalendario qc){
        final TuploTipo tt = TuploTipo.DefaultFactory
            .create(TipoPedido.class,QuerieCalendario.class,Controler.class);  
        
        View a = View.DefaultFactory.create(v.getLingua(),TipoView.APRESENTACAO, 
                                            br, ps, c1);
        Controler gereApresentacao = Controler.DefaultFactory
                                              .create(a, null, TipoControler.CALCULADORA);
        c2.realizaPedido(tt.criar(TipoPedido.MODEL,qc,gereApresentacao));
    }
    
    private static void querieID(BufferedReader br, View v, Controler c1, Controler c2, QuerieCalendario qc){
        final TuploTipo tt = TuploTipo.DefaultFactory
                              .create(TipoPedido.class,QuerieConfiguracao.class,
                                      Number.class);
        TuploTipo ttt; int i;
        final Tuplo t = tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2);
        
        while(true){
            c1.realizaPedido(t);
            ttt = TuploTipo.DefaultFactory.create(Number.class);                        
            v.imprime(ttt.criar(52));
            try {
                i = RecebeInput.lerInt(br);
            } catch (GoBackException go){
                break;
            }
                        
                        
            ttt = TuploTipo.DefaultFactory
            .create(TipoPedido.class,QuerieCalendario.class,
              Number.class
            );     
            c1.realizaPedido(t);
            c2.realizaPedido(ttt.criar(TipoPedido.MODEL,qc,i));
            return;
        }
    }
 
    private void queriePagamentoSistematico(BufferedReader br, View v, Controler c1, Controler c2) {
        final TuploTipo tt,apresentar,querie;
        tt = TuploTipo.DefaultFactory.create(TipoPedido.class,
                              QuerieConfiguracao.class,Number.class);
        apresentar = TuploTipo.DefaultFactory.create(Number.class); 
        querie = TuploTipo.DefaultFactory.create(TipoPedido.class,QuerieCalendario.class,
                                  Number.class, Number.class, String.class, String.class);
            
        final Tuplo t = tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2);
        double pagamento;
        int dia;
        String d, f;
        
        while(true){
            c1.realizaPedido(t);                       
            v.imprime(apresentar.criar(601));
            try {
                pagamento = RecebeInput.lerDouble(br);
                if(pagamento==0) continue;
            } catch (GoBackException go){
                break;
            }
                        
            while (true){
                c1.realizaPedido(t);                       
                v.imprime(apresentar.criar(602));
                try {
                    dia = RecebeInput.lerInt(br);
                    if(dia<1 || dia >31) continue;
                } catch (GoBackException go){
                    break;
                }
                
                try{
                    Tuplo data = MenuData.lerData(br, v, c1, 605);
                    d = data.getValor(0);
                    f = data.getValor(1);
                } catch(GoBackException go){
                    continue;
                }
                c1.realizaPedido(t);   
                c2.realizaPedido(querie.criar(TipoPedido.MODEL,
                                 QuerieCalendario.QUANTORECEBO,
                                 pagamento, dia, d, f));
                return;
            }            
        }
    }

    /**
     * guarda o estado no ficheiro argumento
     * 
     * @param ficheiro
     * @throws IOException 
     */
    @Override
    public void guardarEstado(String ficheiro) throws IOException {
        try(
            FileOutputStream fout  = new FileOutputStream(ficheiro, true);
            ObjectOutputStream oos = new ObjectOutputStream(fout);
            ){
                oos.writeObject(modo4);
        } catch (IOException ex) {
            throw new IOException(ex);
        }
    }

    /**
     * Carrega o estado do ficheiro argumento
     * 
     * @param ficheiro
     * @throws IOException
     * @throws ClassNotFoundException 
     */
    @Override
    public void carregarEstado(String ficheiro) throws IOException, ClassNotFoundException{
        FileInputStream fin = new FileInputStream(ficheiro);
        ObjectInputStream ois = new ObjectInputStream(fin);
        try {
            this.modo4 = (Model) (CalendarioModel) ois.readObject();
        } catch (ClassCastException cce){
            throw new IOException(cce);
        }
    }

    /**
     * reinicializa o model
     */
    @Override
    public void apagarEstado() {
        final TuploTipo ti = TuploTipo.DefaultFactory.create(Modo.class);
        modo4 = Model.DefaultFactory.create(ti.criar(MODO));
    }

    /**
     * 
     * @return o modo deste menu 
     */
    @Override
    public Modo getModo() {
        return MenuCalendario.MODO;
    }
       
}
