/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TP1.Main.MenusModos;

import TP1.Controler.Controler;
import TP1.Controler.Controler.TipoControler;
import TP1.Controler.Controler.TipoPedido;
import TP1.Exceptions.GoBackException;
import TP1.Exceptions.RepeatException;
import TP1.Main.MenusModos.MenuModoInterface.Modo;
import TP1.Model.EstadoConfiguracao.CalculadoraEstadoQueriesInterface.QuerieConfiguracao;
import TP1.Model.Model;
import TP1.Model.Modulos.Cronometro.Cronometro;
import TP1.Model.Modulos.Cronometro.CronometroLugares.CronometroCrescente;
import TP1.Model.Modulos.Cronometro.CronometroLugares.CronometroDecrescente;
import TP1.Model.Modulos.Cronometro.CronometroModel;
import TP1.Model.Modulos.Cronometro.CronometroQueriesInterface.QuerieCronometro;
import TP1.Utils.Input.RecebeInput;
import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import TP1.View.Output.View;
import TP1.View.Output.View.TipoView;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;

/**
 * Menu que encapsula o estado do modo Cronometro
 */
public class MenuCronometro implements MenuModoInterface {
    
    /**
     * modo deste menu
     */
    private static final Modo MODO = Modo.M1;
    
    /**
     * model que encapsula o estado deste menu
     */
    private Model modo1;
    
    /**
     * construtor
     * 
     */
    public MenuCronometro(){
        final TuploTipo ti = TuploTipo.DefaultFactory.create(Modo.class, Cronometro.class);
        final Tuplo t3 = ti.criar(MODO, new CronometroCrescente());
        modo1 = Model.DefaultFactory.create(t3);
    }
    /**
     * Inicia o Menu deste modo
     * 
     *  O Tuplo args argumento deve conter os seguintes valores:
     * 
     *  PrintStream ps    = arg.getValor(0);
     *  BufferedReader br = arg.getValor(1);
     *  Controler c1      = arg.getValor(2);
     *  View ol           = arg.getValor(3);
     * 
     * @param arg
     * @return
     */
    @Override
    public Controler menuEntrada(Tuplo arg) {
        
        final TuploTipo tt,ttt,ti;
        final Tuplo t1,t2;
        Tuplo t3;
        View v;
        Controler c2;
        long milis; int opcao;
        
        PrintStream ps    = arg.getValor(0);
        BufferedReader br = arg.getValor(1);
        Controler c1      = arg.getValor(2);
        View ol           = arg.getValor(3);
        
        tt= TuploTipo.DefaultFactory
                          .create(TipoPedido.class,QuerieConfiguracao.class,Number.class);
        ttt = TuploTipo.DefaultFactory.create(Number.class); 
        ti = TuploTipo.DefaultFactory.create(Modo.class, Cronometro.class);
        t1 = tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2);
        t2 = ttt.criar(14);
        
        v = View.DefaultFactory.create(ol.getLingua(),TipoView.CRONOMETRO,br, ps, null);
        
        while (true) {
            c1.realizaPedido(t1);                     
            v.imprime(t2);
            
            try {
                opcao = RecebeInput.lerInt(br);
            } catch (GoBackException ex) {
                return null;
            }
            
            switch(opcao){
                case 1:
                    t3    = ti.criar(getModo(), new CronometroCrescente());
                    modo1 = Model.DefaultFactory.create(t3);
                    c2 = Controler.DefaultFactory.create(v,modo1,TipoControler.CALCULADORA);
                    menuPrincipal(c1, c2, v, br, ps);
                    break;
                case 2:
                    while(true){
                        c1.realizaPedido(t1);      
                        v.imprime(ttt.criar(13));
                        
                        try {
                            milis = RecebeInput.lerLong(br);
                        } catch (RepeatException ex) {
                            continue;
                        } catch (GoBackException ex) {
                            break;
                        }
                        t3    = ti.criar(getModo(), new CronometroDecrescente(milis));
                        modo1 = Model.DefaultFactory.create(t3);
                        c2 = Controler.DefaultFactory.create(v,modo1,TipoControler.CALCULADORA);
                        menuPrincipal(c1, c2, v, br, ps);
                        break;
                    }
            }
            
        }
        
    }
    
    private void menuPrincipal(Controler c1, Controler c2, View v, BufferedReader br, PrintStream ps) {
        TuploTipo tt;
        boolean go = true;
        Controler gereApresentacao;
        while (go) {
            tt = TuploTipo.DefaultFactory
                          .create(TipoPedido.class,QuerieCronometro.class,Controler.class);
            c2.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieCronometro.START,
                                            Controler.DefaultFactory.create(c2)));

            while (true) {
                tt = TuploTipo.DefaultFactory
                          .create(TipoPedido.class,QuerieConfiguracao.class,Number.class);
                c1.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2));
                tt = TuploTipo.DefaultFactory
                          .create(Number.class);
                v.imprime(tt.criar(18));
                int conf;
                try {
                    conf = RecebeInput.lerInt(br);
                } catch (GoBackException ex) {
                    conf = 1;
                }
                
                if (conf==1) {
                    try {
                        Thread.sleep(500);
                        //wait for the final clock prints
                    } catch (InterruptedException ex) {}
                    tt = TuploTipo.DefaultFactory
                          .create(TipoPedido.class,QuerieCronometro.class, Controler.class);
    
                    View a = View.DefaultFactory.create(v.getLingua(),TipoView.APRESENTACAO, 
                                                        br, ps, c1);
    
                    gereApresentacao = Controler.DefaultFactory
                                                .create(a, null, TipoControler.CALCULADORA);
                    
                    c2.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieCronometro.END,
                                                    gereApresentacao));
                    go = false;
                    break;
                }
                if (conf==2) {
                    tt = TuploTipo.DefaultFactory
                          .create(TipoPedido.class,QuerieCronometro.class);
                    c2.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieCronometro.STOP));
                }
                if (conf==3) break;
                
                if (conf==4) v.imprime(tt.criar(14));
         
            }
        }
    }

    /**
     * Guardar estado do model deste menu no ficheiro argumento
     * 
     * @param ficheiro
     * @throws IOException 
     */
    @Override
    public void guardarEstado(String ficheiro) throws IOException {
        try(
            FileOutputStream fout  = new FileOutputStream(ficheiro, true);
            ObjectOutputStream oos = new ObjectOutputStream(fout);
            ){
                oos.writeObject(modo1);
        } catch (IOException ex) {
            throw new IOException(ex);
        }
    }

    /**
     * Carregar o estado do model deste menu apartir do ficheiro argumento
     * 
     * @param ficheiro
     * @throws IOException
     * @throws ClassNotFoundException 
     */
    @Override
    public void carregarEstado(String ficheiro) throws IOException, ClassNotFoundException{
        FileInputStream fin = new FileInputStream(ficheiro);
        ObjectInputStream ois = new ObjectInputStream(fin);
        try {
            this.modo1 = (Model) (CronometroModel) ois.readObject();
        } catch (ClassCastException cce){
            throw new IOException(cce);
        }
    }

    /**
     * reiniciar model deste menu
     */
    @Override
    public void apagarEstado() {
        this.modo1 = null;
    }

    /**
     * 
     * @return modo deste menu 
     */
    @Override
    public Modo getModo() {
        return MenuCronometro.MODO;
    }
}
