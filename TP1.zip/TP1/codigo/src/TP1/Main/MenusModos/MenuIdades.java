
package TP1.Main.MenusModos;

import TP1.Main.MenusAuxiliares.MenuData;
import TP1.Controler.Controler;
import TP1.Controler.Controler.TipoControler;
import TP1.Controler.Controler.TipoPedido;
import TP1.Exceptions.GoBackException;
import TP1.Exceptions.RepeatException;
import TP1.Main.MenusModos.MenuModoInterface.Modo;
import TP1.Main.ValoresFixos;
import TP1.Main.ValoresFixos.IntervaloTempo;
import TP1.Model.EstadoConfiguracao.CalculadoraEstadoQueriesInterface.QuerieConfiguracao;
import TP1.Model.Model;
import TP1.Model.Modulos.Idade.IdadesModel;
import TP1.Model.Modulos.Idade.IdadesQueriesInterface.QuerieIdade;
import TP1.Utils.Input.RecebeInput;
import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import TP1.View.Output.View;
import TP1.View.Output.View.TipoView;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;

/**
 * Menu que encapsula o estado do modo idades
 */
public class MenuIdades implements MenuModoInterface{
    /**
     * model com o estado deste menu
     */
    private Model modo2;
    
    /**
     * modo deste menu
     */
    private static final Modo MODO = Modo.M2;
    
    /**
     * Construtor
     * 
     */
    public MenuIdades(){
        final TuploTipo ti = TuploTipo.DefaultFactory.create(Modo.class);
        modo2 = Model.DefaultFactory.create(ti.criar(MODO));
    }
    
    /**
     * Inicia o Menu deste modo
     * 
     *  O Tuplo args argumento deve conter os seguintes valores:
     * 
     *  PrintStream ps    = arg.getValor(0);
     *  BufferedReader br = arg.getValor(1);
     *  Controler c1      = arg.getValor(2);
     *  View ol           = arg.getValor(3);
     * 
     * @param arg
     * @return 
     */
    @Override
    public Controler menuEntrada(Tuplo arg) {
        TuploTipo tt;
        View v;
        PrintStream ps    = arg.getValor(0);
        BufferedReader br = arg.getValor(1);
        Controler c1      = arg.getValor(2);
        View ol           = arg.getValor(3);
        
        v = View.DefaultFactory.create(ol.getLingua(),TipoView.IDADES,br, ps, null);
        
        while (true) {
            tt = TuploTipo.DefaultFactory
                          .create(TipoPedido.class,QuerieConfiguracao.class,Number.class);
            c1.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2));
            
            tt = TuploTipo.DefaultFactory
                          .create(Number.class);                        
            v.imprime(tt.criar(14));
            
            int opcao;
            try {
                opcao = RecebeInput.lerInt(br);
            } catch (GoBackException ex) {
                return null;
            }
            
            Controler c2 = Controler.DefaultFactory.create(v,modo2,TipoControler.CALCULADORA);
            
            switch(opcao){

                case 1:                    
                    querie1(br,v,c1,c2);
                    break;
                case 2:
                    querie2(br,v,c1,c2);
                    break;
                case 3:
                    querie3(br,v,c1,c2);
                    break;
            }
            
        }
        
    }
    
    
    private void querie3(BufferedReader br, View v, Controler c1, Controler c2){
        TuploTipo tt;
        while(true){
            String d, f;
            Tuplo t;
            long n;
            try{
                t  = MenuData.lerDataHora(br, v, c1, 13);
                d = t.getValor(0);
                f = t.getValor(1);
            } catch (GoBackException gb){ 
                break;
            }

            while(true){
                tt = TuploTipo.DefaultFactory
                              .create(TipoPedido.class,QuerieConfiguracao.class,Number.class);
                c1.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2));
                tt = TuploTipo.DefaultFactory
                              .create(Number.class, Boolean.class);                        
                v.imprime(tt.criar(6,false));

                try{
                    int opcao = RecebeInput.lerInt(br);
                    if (opcao < 1 || opcao > 9 ) continue;
                    tt = TuploTipo.DefaultFactory
                              .create(TipoPedido.class,QuerieConfiguracao.class,Number.class);
                    c1.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2));
                    tt = TuploTipo.DefaultFactory
                              .create(TipoPedido.class,QuerieIdade.class,
                                      String.class,String.class,
                                      IntervaloTempo.class
                                     );     
                    c2.realizaPedido(tt.criar(TipoPedido.MODEL,
                                                    QuerieIdade.QUANTOFALTA,
                                                    d,f,
                                                    ValoresFixos.getEnum(opcao-1, 
                                                                         IntervaloTempo.class
                                                                        )
                                                   )
                                    );
                    break;
                } catch (GoBackException gb) {
                    break;
                }
            }
        }
    }
    
    
    private void querie2(BufferedReader br, View v, Controler c1, Controler c2){
        TuploTipo tt;
        while(true){
            String d, f;
            Tuplo t;
            long n;
            try{
                t  = MenuData.lerDataHora(br, v, c1, 13);
                d = t.getValor(0);
                f = t.getValor(1);
            } catch (GoBackException gb){ 
                break;
            }

            while(true){
                 tt = TuploTipo.DefaultFactory
                              .create(TipoPedido.class,QuerieConfiguracao.class,Number.class);
                c1.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2));
                tt = TuploTipo.DefaultFactory
                              .create(Number.class);                        
                v.imprime(tt.criar(5));
                try{
                    n = RecebeInput.lerLong(br);
                } catch (GoBackException go) {
                    break;
                } catch (RepeatException re){
                    continue;
                }

                while(true){
                    tt = TuploTipo.DefaultFactory
                                  .create(TipoPedido.class,QuerieConfiguracao.class,Number.class);
                    c1.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2));
                    tt = TuploTipo.DefaultFactory
                                  .create(Number.class);                        
                    v.imprime(tt.criar(4));

                    try{
                        int opcao = RecebeInput.lerInt(br);
                        if (opcao < 1 || opcao > 13 ) continue;
                        tt = TuploTipo.DefaultFactory
                                  .create(TipoPedido.class,QuerieConfiguracao.class,Number.class);
                        c1.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2));
                        tt = TuploTipo.DefaultFactory
                                  .create(TipoPedido.class,QuerieIdade.class,
                                          String.class,String.class,
                                          Number.class,IntervaloTempo.class
                                         );     
                        c2.realizaPedido(tt.criar(TipoPedido.MODEL,
                                                        QuerieIdade.QUANDOIDADE,
                                                        d,f,n,
                                                        ValoresFixos.getEnum(opcao-1, 
                                                                             IntervaloTempo.class
                                                                            )
                                                       )
                                        );
                        break;
                    } catch (GoBackException gb) {
                        break;
                    }
                }
            }
        }
    }
    
    private void querie1(BufferedReader br, View v, Controler c1, Controler c2){
        TuploTipo tt;
        int fim = 0;
        while(fim==0){
            fim = 1;
            String d1, d2, f1, f2;
            Tuplo t;
            try{
                t  = MenuData.lerDataHora(br, v, c1, 13);
                d1 = t.getValor(0);
                f1 = t.getValor(1);
            } catch(GoBackException gb){
                break;
            }
            try{
                t  = MenuData.lerDataHora(br, v, c1, 9);
                d2 = t.getValor(0);
                f2 = t.getValor(1);
            } catch (GoBackException gb){ 
                fim = 0;
                continue;
            }

            while(true){
                tt = TuploTipo.DefaultFactory
                              .create(TipoPedido.class,QuerieConfiguracao.class,Number.class);
                c1.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2));
                tt = TuploTipo.DefaultFactory
                              .create(Number.class, Boolean.class);                        
                v.imprime(tt.criar(6,true));

                try{
                    int opcao = RecebeInput.lerInt(br);
                    if (opcao < 1 || opcao > 13 ) continue;
                    tt = TuploTipo.DefaultFactory
                              .create(TipoPedido.class,QuerieConfiguracao.class,Number.class);
                    c1.realizaPedido(tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2));
                    tt = TuploTipo.DefaultFactory
                              .create(TipoPedido.class,QuerieIdade.class,
                                      String.class,String.class,
                                      String.class,String.class,
                                      IntervaloTempo.class
                                     );     
                    c2.realizaPedido(tt.criar(TipoPedido.MODEL,
                                                    QuerieIdade.QUEIDADE,
                                                    d1,d2,f1,f2,
                                                    ValoresFixos.getEnum(opcao-1, 
                                                                         IntervaloTempo.class
                                                                        )
                                                   )
                                    );
                    fim = 1;
                                                    break;
                } catch (GoBackException gb) {
                    fim = 0;
                    break;
                }
            }
        }
    }

    /**
     * Guarda estado do model deste menu no ficheiro argumento
     * 
     * @param ficheiro
     * @throws IOException 
     */
    @Override
    public void guardarEstado(String ficheiro) throws IOException {
        try(
            FileOutputStream fout  = new FileOutputStream(ficheiro, true);
            ObjectOutputStream oos = new ObjectOutputStream(fout);
            ){
                oos.writeObject(modo2);
        } catch (IOException ex) {
            throw new IOException(ex);
        }
    }

    /**
     * Carrega o estado do model deste menu apartir do ficheiro argumento
     * 
     * @param ficheiro
     * @throws IOException
     * @throws ClassNotFoundException 
     */
    @Override
    public void carregarEstado(String ficheiro) throws IOException, ClassNotFoundException{
        FileInputStream fin = new FileInputStream(ficheiro);
        ObjectInputStream ois = new ObjectInputStream(fin);
        try {
            this.modo2 = (Model) (IdadesModel) ois.readObject();
        } catch (ClassCastException cce){
            throw new IOException(cce);
        }
    }

    /**
     * reinicializa o model deste menu
     */
    @Override
    public void apagarEstado() {
        final TuploTipo ti = TuploTipo.DefaultFactory.create(Modo.class);
        modo2 = Model.DefaultFactory.create(ti.criar(MODO));
    }

    /**
     * 
     * @return modo do menu
     */
    @Override
    public Modo getModo() {
        return MenuIdades.MODO;
    }
}
