
package TP1.Main;

import java.io.Serializable;
import java.time.temporal.ChronoUnit;

/**
 * Definição de algumas constantes e funções genéricas
 * 
 */
public class ValoresFixos implements Cloneable, Serializable{
    
    /**
     * Intervalos de tempo
     */
    public enum IntervaloTempo {
        NANOSEGUNDOS, MICROSEGUNDOS, MILISEGUNDOS, SEGUNDOS, MINUTOS, HORAS,
        DIAS, SEMANAS, MESES, ANOS, DECADAS, SECULOS, MILENIOS
    }
    
    
    /**
     * Conversão de um valor númerico para a respetiva designação
     * no enum de class argumento
     * @param <E>
     * @param value
     * @param enumClass
     * @return 
     */
    public static <E extends Enum<E>> E getEnum(int value, Class<E> enumClass) {
        for (E e : enumClass.getEnumConstants()) {
            if(e.ordinal()==value) { 
                return e; 
            }
        }
        return null;
    }

    /**
     * continente por defeito
     */
    public static final String CONTINENTE_DEFEITO = "Europe";
    /**
     * cidade por defeito
     */
    public static final String CIDADE_DEFEITO     = "Lisbon";
    
    /**
     * offset por defeito
     */
    public static final String OFFSET_DEFEITO     = "+00:00";
    

    /**
     * 
     * @param unidade
     * @return representação em forma de String do enum IntervaloTempo
     */
    public static String intervalotoString(IntervaloTempo unidade){
        switch (unidade){
            case NANOSEGUNDOS:
                return "ns";
            case MILISEGUNDOS:
                return "ms";
            case MICROSEGUNDOS:
                return "mms";
            case DIAS:
                return "d";
            case MESES:
                return "m";
            case ANOS:
                return "Y";
            case HORAS:
                return "H";
            case MINUTOS:
                return "m";
            case SEGUNDOS:
                return "s";
            case SEMANAS:
                return "w";
            case DECADAS:
                return "D";
            case SECULOS:
                return "C";
            case MILENIOS:
                return "M";
        }
        
        return "";
    }
    
    /**
     * Conversor de IntervaloTempo para ChronoUnit
     * @param unidade
     * @return ChronoUnit equivalente a unidade argumento
     */
    public static ChronoUnit parserDeUnidadeTemporal(IntervaloTempo unidade){
        switch (unidade){
            case NANOSEGUNDOS:
                return ChronoUnit.MILLIS;
            case MILISEGUNDOS:
                return ChronoUnit.MILLIS;
            case MICROSEGUNDOS:
                return ChronoUnit.MICROS;
            case DIAS:
                return ChronoUnit.DAYS;
            case MESES:
                return ChronoUnit.MONTHS;
            case ANOS:
                return ChronoUnit.YEARS;
            case HORAS:
                return ChronoUnit.HOURS;
            case MINUTOS:
                return ChronoUnit.MINUTES;
            case SEGUNDOS:
                return ChronoUnit.SECONDS;
            case SEMANAS:
                return ChronoUnit.WEEKS;
            case DECADAS:
                return ChronoUnit.DECADES;
            case SECULOS:
                return ChronoUnit.CENTURIES;
            case MILENIOS:
                return ChronoUnit.MILLENNIA;
        }
        
        return null;
    }
   
}
