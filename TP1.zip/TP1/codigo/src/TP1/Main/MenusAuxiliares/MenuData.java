
package TP1.Main.MenusAuxiliares;

import TP1.Controler.Controler;
import TP1.Controler.Controler.TipoPedido;
import TP1.Exceptions.GoBackException;
import TP1.Model.EstadoConfiguracao.CalculadoraEstadoQueriesInterface.QuerieConfiguracao;
import TP1.Utils.Input.RecebeInput;
import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import TP1.View.Output.View;
import java.io.BufferedReader;

/**
 * Esta classe consiste num Menu que é capaz de ler datas que o utilizador forneça.
 */
public class MenuData {
    
    /**
     * Pede ao utilizador e recebe input pelo br de uma hora e um minuto.
     * 
     * Usa c para requerir a impressão do header da aplicação
     * 
     * usa v para imprimir as mensagens relativas a cada campo da data que o utilizador
     * deve inserir. O int inicio irá indicar qual o índica da primeira impressão que
     * deve ser requerida a v.
     * 
     * @param br
     * @param v
     * @param c
     * @param inicio
     * @return Tuplo onde a posição 0 é uma representação em String da data e a posição 1 é a representação em String do formato da data
     * @throws GoBackException se o utilizador escrever seta para trás seguido de - enquanto insere o primeiro campo
     */
    public static Tuplo lerHora(BufferedReader br, View v, Controler c, int inicio) throws GoBackException {
        int hora = getCampo(br, inicio+10, c, v, 0, 24);
        int minu = getCampo(br, inicio+9, c, v, 0, 60);
                        
        return parseFormatoHora(hora, minu);
    }

    /**
     * Pede ao utilizador e recebe input pelo br de um dia, mês, ano, hora e minuto.
     * 
     * Usa c para requerir a impressão do header da aplicação
     * 
     * usa v para imprimir as mensagens relativas a cada campo da data que o utilizador
     * deve inserir. O int inicio irá indicar qual o índica da primeira impressão que
     * deve ser requerida a v.
     * 
     * @param br
     * @param v
     * @param c
     * @param inicio
     * @return Tuplo onde a posição 0 é uma representação em String da data e a posição 1 é a representação em String do formato da data
     * @throws GoBackException se o utilizador escrever seta para trás seguido de - enquanto insere o primeiro campo
     */    
    public static Tuplo lerDataHora(BufferedReader br, View v, Controler c, int inicio) throws GoBackException {
        int dia = getCampo(br, inicio  , c, v, 1, 31);
        int mes = getCampo(br, inicio-1, c, v, 1, 12);
        int ano = getCampo(br, inicio-2, c, v, 1, 9999999);
        
        int hora = getCampo(br, inicio+10, c, v, 0, 24);
        int minu = getCampo(br, inicio+9, c, v, 0, 60);
                        
        return parseFormatoDataHora(dia, mes, ano, hora, minu);
    }
    
    /**
     * Pede ao utilizador e recebe input pelo br de um dia, mês e ano.
     * 
     * Usa c para requerir a impressão do header da aplicação
     * 
     * usa v para imprimir as mensagens relativas a cada campo da data que o utilizador
     * deve inserir. O int inicio irá indicar qual o índica da primeira impressão que
     * deve ser requerida a v.
     * 
     * @param br
     * @param v
     * @param c
     * @param inicio
     * @return Tuplo onde a posição 0 é uma representação em String da data e a posição 1 é a representação em String do formato da data
     * @throws GoBackException se o utilizador escrever seta para trás seguido de - enquanto insere o primeiro campo
     */
    public static Tuplo lerData(BufferedReader br, View v, Controler c, int inicio) throws GoBackException {
        int dia = getCampo(br, inicio  , c, v, 1, 31);
        int mes = getCampo(br, inicio-1, c, v, 1, 12);
        int ano = getCampo(br, inicio-2, c, v, 1, 9999999);
                        
        return parseFormatoData(dia, mes, ano);
    }
        
    private static int getCampo(BufferedReader br, int offset, Controler c, View v, int inferior, int superior) throws GoBackException{
        TuploTipo tt;
        int var = inferior -1;
        while(var < inferior){
            tt = TuploTipo.DefaultFactory
              .create(TipoPedido.class,QuerieConfiguracao.class,Number.class);
            c.realizaPedido(tt.criar(TipoPedido.MODEL,
                                           QuerieConfiguracao.GETZONA,-2));

            tt = TuploTipo.DefaultFactory
              .create(Number.class);                        
            v.imprime(tt.criar(offset));

            var = RecebeInput.lerInt(br);
            if(superior > inferior && 
               var      > superior
              ) var = inferior-1;

        }
        return var;
    }
    
    private static Tuplo parseFormatoDataHora(int dia, int mes, int ano, int hora, int minuto){
        final TuploTipo tt = TuploTipo.DefaultFactory
                          .create(String.class, String.class);
        
        StringBuilder data = new StringBuilder();
        data.append(ano).append('-');
        if (mes<10)data.append('0');
        data.append(mes).append('-');
        if (dia<10) data.append('0');
        data.append(dia).append(':');
        if (hora<10) data.append('0');
        data.append(hora).append(':');
        if (minuto<10) data.append('0');
        data.append(minuto);
        StringBuilder formato = new StringBuilder();
        String a = Integer.toString(ano);
        int l = a.length();
        for(int i = 0; i<l; i++)
            formato.append('u');
        formato.append("-MM-dd:HH:mm");

        return tt.criar(data.toString(),
                              formato.toString()
                             );
    }
    
    private static Tuplo parseFormatoHora(int hora, int minuto){
        final TuploTipo tt = TuploTipo.DefaultFactory
                          .create(String.class, String.class);
        
        StringBuilder data = new StringBuilder();
        if (hora<10) data.append('0');
        data.append(hora).append(':');
        if (minuto<10) data.append('0');
        data.append(minuto);
        StringBuilder formato = new StringBuilder();
        formato.append("HH:mm");

        return tt.criar(data.toString(),
                              formato.toString()
                             );
    }
    
    private static Tuplo parseFormatoData(int dia, int mes, int ano){
        final TuploTipo tt = TuploTipo.DefaultFactory
                          .create(String.class, String.class);
        
        StringBuilder data = new StringBuilder();
        data.append(ano).append('-');
        if (mes<10)data.append('0');
        data.append(mes).append('-');
        if (dia<10) data.append('0');
        data.append(dia);
        StringBuilder formato = new StringBuilder();
        String a = Integer.toString(ano);
        int l = a.length();
        for(int i = 0; i<l; i++)
            formato.append('u');
        formato.append("-MM-dd");

        return tt.criar(data.toString(),
                              formato.toString()
                             );
    }

}
