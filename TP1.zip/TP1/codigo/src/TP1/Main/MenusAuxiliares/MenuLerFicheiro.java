
package TP1.Main.MenusAuxiliares;

import TP1.Controler.Controler;
import TP1.Controler.Controler.TipoPedido;
import TP1.Exceptions.GoBackException;
import TP1.Model.EstadoConfiguracao.CalculadoraEstadoQueriesInterface.QuerieConfiguracao;
import TP1.Utils.Input.RecebeInput;
import TP1.Utils.Tuplo.TuploTipo;
import TP1.View.Output.View;
import java.io.BufferedReader;
import java.util.Collection;

/**
 * Esta classe consiste num menu que permite a leitura de
 * um ficheiro cujo nome é fornecido pelo utilizador.
 */
public class MenuLerFicheiro {
    
    /**
     * 
     * Pede ao utilizador e recebe input pelo br do nome de um ficheiro e lê
     * o seu conteúdo colocando cada linha sobre a forma de String numa 
     * posição distinta de uma collection.
     * 
     * Usa c para requerir a impressão do header da aplicação
     * 
     * usa v para imprimir as mensagens que pedem o nome do ficheiro
     * O int indice irá indicar qual o índica da impressão que
     * deve ser requerida a v.
     * 
     * @param br
     * @param v
     * @param c
     * @param indice
     * @return collection de linhas
     * @throws GoBackException caso o utilizador escreva seta para trás seguido de -
     */
    public static Collection<String> lerFicheiro(BufferedReader br, View v, Controler c, int indice) throws GoBackException {
        TuploTipo tt = TuploTipo.DefaultFactory
              .create(TipoPedido.class,
                      QuerieConfiguracao.class,
                      Number.class);
        c.realizaPedido(tt.criar(TipoPedido.MODEL,
                                       QuerieConfiguracao.GETZONA,-2));

        tt = TuploTipo.DefaultFactory
              .create(Number.class);                        
        v.imprime(tt.criar(indice));
        
        String fich = RecebeInput.lerLinha(br);
        return RecebeInput.lerComStream(fich);
    }
}
