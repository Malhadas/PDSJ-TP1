
package TP1.Main.MenusAuxiliares;

import TP1.Controler.Controler.TipoPedido;
import TP1.Exceptions.GoBackException;
import TP1.Main.MenusModos.MenuModoInterface;
import TP1.Main.MenusModos.MenuModoInterface.Modo;
import TP1.Main.ValoresFixos;
import TP1.Model.EstadoConfiguracao.CalculadoraEstadoQueriesInterface.QuerieConfiguracao;
import TP1.Utils.Input.RecebeInput;
import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import TP1.View.Output.View;
import java.io.BufferedReader;
import java.io.IOException;

/**
 * Permite guardar o estado de vários menus que encapsulam os models
 */
public class MenuEstado {

    /**
     * Recebe os vários menus para questionar qual o utilizador pretende guardar,
     * a view ol imprimir o header da aplicação e para imprimir outros prints
     * necessários.
     * 
     * pedido indica se pretendemos guardar ou carregar estado. Se for o número 18 então
     * pretende-se guardar, caso contrário, carregar
     * 
     * br permite receber input do utilizador
     * 
     * @param ol
     * @param br
     * @param modo1
     * @param modo2
     * @param modo3
     * @param modo4
     * @param modo5
     * @param pedido 
     */
    public static void estado(View ol, BufferedReader br,
                               MenuModoInterface modo1, MenuModoInterface modo2, 
                               MenuModoInterface modo3, MenuModoInterface modo4,
                               MenuModoInterface modo5, int pedido) {
        TuploTipo tt,ttt,targ;
        final Tuplo t;
        tt   = TuploTipo.DefaultFactory.create(TipoPedido.class,QuerieConfiguracao.class,Number.class);
        ttt  = TuploTipo.DefaultFactory.create(Number.class, Object.class);
        targ = TuploTipo.DefaultFactory.create(View.class,Number.class,Tuplo.class);
        t    = tt.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA,-2);
        int modo; String ficheiro; Modo m;
        
        while(true){
            modo5.menuEntrada(targ.criar(ol,0,t));
                     
            ol.imprime(ttt.criar(pedido,null));
            try {
                modo = RecebeInput.lerInt(br);
            } catch (GoBackException ex) {
                return;
            }
            m = ValoresFixos.getEnum(modo-1, Modo.class);
            if(m==null || m==Modo.NONE) continue;
            System.out.println(m);
            modo5.menuEntrada(targ.criar(ol,0,t));
                    
            ol.imprime(ttt.criar(pedido-4,null));
            try {
                ficheiro = RecebeInput.lerLinha(br);
            } catch (GoBackException ex) {
                continue;
            }
            
            try{
                switch(m){
                    case M1:
                        tratarEstado(modo1,ficheiro,pedido);
                        break;
                    case M2:
                        tratarEstado(modo2,ficheiro,pedido);
                        break;
                   case M3:
                        tratarEstado(modo3,ficheiro,pedido);
                        break;
                    case M4:
                        tratarEstado(modo4,ficheiro,pedido);
                        break;
                    case M5:
                        tratarEstado(modo5,ficheiro,pedido);
                        break;
                }
                ol.imprime(ttt.criar(pedido+12,null));
            } catch (IOException | ClassNotFoundException | ClassCastException ex) {
                ol.imprime(ttt.criar(pedido+10,null));
            }
        }
    }

    private static void tratarEstado(MenuModoInterface modo, String ficheiro, int pedido) throws IOException, ClassCastException, ClassNotFoundException {
        if(pedido == 18) modo.guardarEstado(ficheiro);
        else             modo.carregarEstado(ficheiro);
    }

    
}
