
package TP1.Main;

import TP1.Controler.Controler;
import TP1.Controler.Controler.TipoPedido;
import TP1.Utils.Input.RecebeInput;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import TP1.Exceptions.GoBackException;
import TP1.Main.MenusAuxiliares.MenuEstado;
import TP1.Main.MenusModos.MenuModoInterface;
import TP1.Main.MenusModos.MenuModoInterface.Modo;
import TP1.Model.EstadoConfiguracao.CalculadoraEstadoQueriesInterface.QuerieConfiguracao;
import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import java.io.PrintStream;
import TP1.View.Output.View;
import TP1.View.Output.View.Lingua;
import TP1.View.Output.View.TipoView;

/**
 *
 */
public class Main {

    
    private static void cicloPrincipal(PrintStream ps, BufferedReader br, View ol){
        String opcao;Controler c;
        
        MenuModoInterface modo1 = InstanciaModo(Modo.M1,ol.getLingua());
        MenuModoInterface modo2 = InstanciaModo(Modo.M2,ol.getLingua());
        MenuModoInterface modo3 = InstanciaModo(Modo.M3,ol.getLingua());
        MenuModoInterface modo4 = InstanciaModo(Modo.M4,ol.getLingua());
        MenuModoInterface modo5 = InstanciaModo(Modo.M5,ol.getLingua());

        TuploTipo  tt = TuploTipo.DefaultFactory.create(View.class,Number.class,Tuplo.class);
        TuploTipo  t  = TuploTipo.DefaultFactory.create(TipoPedido.class, 
                                             QuerieConfiguracao.class,Number.class);
        modo5.menuEntrada(tt.criar(ol,0,t.criar(TipoPedido.MODEL, 
                                                       QuerieConfiguracao.GETZONA, 0)));
        
        final TuploTipo tMenu  = TuploTipo.DefaultFactory.create(PrintStream.class,BufferedReader.class,
                                                                Controler.class, View.class);
        final TuploTipo tMenu5 = TuploTipo.DefaultFactory.create(View.class, Number.class,PrintStream.class,
                                                                 BufferedReader.class);
        
        //Apresentar titulo

        while(true){

            try {

                c = modo5.menuEntrada(tt.criar(ol,0,t.criar(TipoPedido.MODEL,
                                                     QuerieConfiguracao.GETZONA,1)));

                opcao = RecebeInput.lerLinha(br);
                
                if ("".equals(opcao) || opcao == null) continue;
                
                switch(opcao.toLowerCase().charAt(0)){
                    
                    case 'h' :
                        c.realizaPedido(t.criar(TipoPedido.MODEL,
                                                      QuerieConfiguracao.GETZONA,5));
                        break;
                        
                    case 's' :
                        c.realizaPedido(t.criar(TipoPedido.MODEL,
                                                      QuerieConfiguracao.GETZONA,8));
                        return;
                        
                    case 't' :
                        c.realizaPedido(t.criar(TipoPedido.MODEL,
                                                      QuerieConfiguracao.GETZONA,0));
                        break;
                        
                    case 'a' :
                        c.realizaPedido(t.criar(TipoPedido.MODEL,
                                                      QuerieConfiguracao.GETZONA,6));
                        break;
                    
                    case 'g' :
                        MenuEstado.estado(ol,br,modo1,modo2,modo3,modo4,modo5,18);
                        break;
                
                    case 'c' :
                        MenuEstado.estado(ol,br,modo1,modo2,modo3,modo4,modo5,19);
                        break;
                        
                    case 'm':
                        Modo modo_atual = mudarModo(br,modo5,ol);
                        
                        switch(modo_atual){
                            case M1:
                                modo1.menuEntrada(tMenu.criar(ps,br,c,ol));
                                break;
                            case M2:
                                modo2.menuEntrada(tMenu.criar(ps,br,c,ol));
                                break;
                            case M3:
                                modo3.menuEntrada(tMenu.criar(ps,br,c,ol));
                                break;
                            case M4:
                                modo4.menuEntrada(tMenu.criar(ps,br,c,ol));
                                break;
                            case M5:
                                modo5.menuEntrada(tMenu5.criar(ol,2,ps,br));
                                break;
                        }
                        break;
                        
                    default :
                        break;
                }
                //ignorar maus inputs e pedidos para retroceder
            } catch (GoBackException | NumberFormatException e){}

	}
    }
 
    
    private static Modo mudarModo(BufferedReader br, MenuModoInterface modo5, View ol) throws GoBackException {
        TuploTipo t, tt;
        tt = TuploTipo.DefaultFactory.create(View.class,Number.class,Tuplo.class);
        t =  TuploTipo.DefaultFactory.create(TipoPedido.class,QuerieConfiguracao.class, Number.class);
        Tuplo t1 = t.criar(TipoPedido.MODEL,QuerieConfiguracao.GETZONA_GETMODO,13);
        
        while (true){
            modo5.menuEntrada(tt.criar(ol,0,t1));
            
            int modo = RecebeInput.lerInt(br);
            Modo m = ValoresFixos.getEnum(modo-1, Modo.class);
            if (m!=null && m!=Modo.NONE){
                t = TuploTipo.DefaultFactory.create(TipoPedido.class,
                                                QuerieConfiguracao.class,Modo.class);
                t1 = t.criar(TipoPedido.MODEL,QuerieConfiguracao.SETMODO,m);
                modo5.menuEntrada(tt.criar(ol,0,t1));
                return m;
            }
        }
    }
    
    private static View escolherLingua(BufferedReader br, PrintStream ps){
        while(true){
            try {
                ps.println("       _______________");
                ps.println("      /               \\");
                ps.println("     | Português  (1)  |");
                ps.println("     | English    (2)  |");
                ps.println("      \\_______________/");
                ps.println("      Choice : ");
                
                int choice = RecebeInput.lerInt(br);
                
                switch (choice){
                    case 1:
                        return View.DefaultFactory.create(Lingua.PORTUGUES, 
                                                          TipoView.CONFIGURACAO, 
                                                          br, ps, null);
                    case 2:
                        //return View.DefaultFactory.create(Lingua.INGLES, 
                          //        TipoView.CONFIGURACAO, 
                            //      br, ps, null);
                        
                }
            } catch (GoBackException ex) {} //Ignorar pedido para retroceder.
            
        }
    }
    
    public static void main(String[] args) {
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        PrintStream ps    = new PrintStream(System.out);
        
        View ol = escolherLingua(br,ps);
        final TuploTipo ti = TuploTipo.DefaultFactory.create(Modo.class);
        
        //Método main deve ser simples e conciso.
        cicloPrincipal(ps, br, ol); //Menu principal
        //fim
    }

    private static MenuModoInterface InstanciaModo(Modo modo, View.Lingua lingua) {
        TuploTipo tt;
        Tuplo t;
        
        switch(modo){
            case M1:
                tt = TuploTipo.DefaultFactory.create(Modo.class);
                t  = tt.criar(Modo.M1); 
                return MenuModoInterface.DefaultFactory.create(t);
            case M2:
                tt = TuploTipo.DefaultFactory.create(Modo.class);
                t  = tt.criar(Modo.M2); 
                return MenuModoInterface.DefaultFactory.create(t);
            case M3:
                switch(lingua){
                    case PORTUGUES:
                        tt = TuploTipo.DefaultFactory.create(Modo.class, String.class, 
                                                             String.class, String.class);
                        t  = tt.criar(Modo.M3,"preco","duracao","data"); 
                        return MenuModoInterface.DefaultFactory.create(t);
                    case INGLES:
                        return null;
                }
            case M4:
                switch(lingua){
                    case PORTUGUES:
                        tt = TuploTipo.DefaultFactory.create(Modo.class, String.class, 
                                                             String.class, String.class);
                        t  = tt.criar(Modo.M4,"dia do ano","ano bissexto","ano nao bissexto"); 
                        return MenuModoInterface.DefaultFactory.create(t);
                    case INGLES:
                        return null;
                }
            case M5:
                switch(lingua){
                    case PORTUGUES:
                        tt = TuploTipo.DefaultFactory.create(Modo.class);
                        t  = tt.criar(Modo.M5); 
                        return MenuModoInterface.DefaultFactory.create(t);
                    case INGLES:
                        return null;
                }
                
        }
        return null;
    }
}
