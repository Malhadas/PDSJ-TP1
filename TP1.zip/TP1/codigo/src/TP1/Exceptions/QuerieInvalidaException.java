
package TP1.Exceptions;

/**
 * Poderá ser lançada ao receber uma querie inexistente num determinado modo
 * da calculadora.
 */
public class QuerieInvalidaException extends Exception{
 
    /**
     * COnstrutor para objetos da classe QuerieInvalidaException
     */
    public QuerieInvalidaException(){
        super();
    }

    /**
     * COnstrutor para objetos da classe QuerieInvalidaException
     * @param mensagem
     */
    public QuerieInvalidaException(String mensagem){
        super(mensagem);
    }
}
