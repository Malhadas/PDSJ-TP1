
package TP1.Exceptions;


/**
 * Poderá ser lançada para repetir qualquer input nos menus.
 */
public class RepeatException extends Exception{
 
    /**
     * COnstrutor para objetos da classe RepeatException
     */
    public RepeatException(){
        super();
    }

    /**
     * COnstrutor para objetos da classe RepeatException
     * @param mensagem
     */
    public RepeatException(String mensagem){
        super(mensagem);
    }
}