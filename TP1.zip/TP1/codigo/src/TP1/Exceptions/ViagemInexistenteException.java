
package TP1.Exceptions;

/**
 * Poderá ser lançada ao detetar um id de viagem mal fornecido pelo utilizador.
 */
public class ViagemInexistenteException extends Exception{
 
    /**
     * COnstrutor para objetos da classe ViagemInexistenteException
     */
    public ViagemInexistenteException(){
        super();
    }

    /**
     * COnstrutor para objetos da classe ViagemInexistenteException
     * @param mensagem
     */
    public ViagemInexistenteException(String mensagem){
        super(mensagem);
    }
}
