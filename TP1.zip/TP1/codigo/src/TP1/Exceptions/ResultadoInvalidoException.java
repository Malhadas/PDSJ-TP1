
package TP1.Exceptions;

/**
 * Poderá ser lançada ao obter um resultado invalido de uma querie num 
 * determinado modo da calculadora.
 */
public class ResultadoInvalidoException extends Exception{
 
    /**
     * COnstrutor para objetos da classe ResultadoInvalidoException
     */
    public ResultadoInvalidoException(){
        super();
    }

    /**
     * COnstrutor para objetos da classe ResultadoInvalidoException
     * @param mensagem
     */
    public ResultadoInvalidoException(String mensagem){
        super(mensagem);
    }
}
