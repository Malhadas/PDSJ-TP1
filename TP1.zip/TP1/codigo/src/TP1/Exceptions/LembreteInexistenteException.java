
package TP1.Exceptions;

/**
 * Poderá ser lançada ao detetar um id de lembrete mal fornecido pelo utilizador.
 */
public class LembreteInexistenteException extends Exception{
 
    /**
     * COnstrutor para objetos da classe LembreteInexistenteException
     */
    public LembreteInexistenteException(){
        super();
    }

    /**
     * COnstrutor para objetos da classe LembreteInexistenteException
     * @param mensagem
     */
    public LembreteInexistenteException(String mensagem){
        super(mensagem);
    }
}
