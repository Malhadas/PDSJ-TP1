
package TP1.Exceptions;


/**
 * Poderá ser lançada ao cancelar qualquer acção nos menus.
 */
public class GoBackException extends Exception{
 
    /**
     * COnstrutor para objetos da classe GoBackException
     */
    public GoBackException(){
        super();
    }

    /**
     * COnstrutor para objetos da classe GoBackException
     * @param mensagem
     */
    public GoBackException(String mensagem){
        super(mensagem);
    }
}