
package TP1.Controler.CalculadoraControler;

import TP1.Controler.Controler;
import TP1.Controler.Controler.TipoControler;
import TP1.Exceptions.QuerieInvalidaException;
import TP1.Exceptions.ResultadoInvalidoException;
import TP1.Model.Model;
import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import java.io.Serializable;
import TP1.View.Output.View;

/**
 * Esta classe implementa a classe Controler para definir um controler imutável
 * capaz de servir como ponte de comunicação ente uma View e um Model
 * genéricos dos quais nada conhece para além das suas interfaces.
 */
public class CalculadoraControler implements Serializable, Controler{
    /**
     * entidade view
     */
    private final View  view;
    /**
     * entidade model
     */
    private final Model model;
    
    /**
     * Constante que define o tipo deste controler
     */
    public static final TipoControler TIPO = TipoControler.CALCULADORA;
    
    /**
     * Construtor
     * 
     * Recebe uma View e um Model que serão as entidades às quais
     * este controler vai auxiliar a comunicação
     * 
     * @param view
     * @param model 
     */
    public CalculadoraControler(View view, Model model){
        this.view  = view;
        this.model = model;
    }
    
    /**
     * Receb um Tuplo t que irá definir o tipo a realizar.
     * 
     * O primeiro elemento do tuplo deve ser um valor do tipo
     * TipoPedido que identifica a quem deve ser enviados os restantes
     * valores do tuplo.
     * 
     * caso o primeiro valor seja MODEL então o tuplo inteiro é enviado
     * para o model atraves do método da sua interface realizaQuerie.
     * O resultado de realiza querie é automáticamente enviado para a view
     * utilizando o método da sua interface imprime.
     * 
     * Caso o primeiro valor seja VIEW então o segundo valor deve ser um outro
     * Tuplo que é enviado para a view com recurso ao método da sua interface
     * imprime.
     * 
     * @param t 
     */
    @Override
    public void realizaPedido(Tuplo t) {
        TipoPedido tipo_pedido = t.getValor(0);
        
        switch(tipo_pedido){
            case VIEW:
                //Queremos fazer update da view
                updateView(t.getValor(1));
                break;
                
            case MODEL:
                //Queremos realizar uma querie do model
                usaModel(t);
                break;
        }
    }

    private void updateView(Tuplo t){
        this.view.imprime(t);
    }
    
    private void usaModel(Tuplo t){
        try {
            Tuplo t1 = this.model.realizaQuerie(t);
            this.updateView(t1);
        } catch (QuerieInvalidaException | ResultadoInvalidoException ex) {
            final TuploTipo tt = TuploTipo.DefaultFactory
                                     .create(Number.class);
            final Tuplo t1 = tt.criar(-1);
            updateView(t1);
        }
    }
    
    /**
     * Colona este controler e garante o encapsulamento do estado do model
     * ao colonar o model também.
     * 
     * @return novo Controler
     */
    @Override
    public Controler clone(){ //encapsula o model
        return new CalculadoraControler(view,model.clone());
    }
    
}
