
package TP1.Controler;

import TP1.Controler.CalculadoraControler.CalculadoraControler;
import TP1.Model.Model;
import TP1.Utils.Tuplo.Tuplo;
import TP1.View.Output.View;

/**
 *
 * Descreve uma entidade que serve como ponte entre outras duas entidades
 * Essas duas entidades tipicamente serão uma view e um model definidos no
 * Design Pattern Model View Controler (MVC), no entanto cabe ao programador
 * que implemente esta interface decidir quais as entidades que pretende.
 * Note-se no entanto que, a terminologia presente nesta intrface assume 
 * um Model e uma View.
 * 
 * É desejável que as entidades às quais este controlador serve de ponte 
 * estejam devidamente encapsuladas nas suas respetivas interfaces. Deste
 * modo garante-se que uma implementação desta classe pode ser
 * reutilizada para quaisquer entidades desde que estas implementem os
 * mesmos métodos, não havendo então necessidade de criar novos controladores
 * para implementações específicas das mesmas interfaces.
 */
public interface Controler{
    
    /**
     * Define um tipo de controlador para depois ser usado
     * no DefaultFactory desta Interface e instanciar um novo
     * Controler sem que quem o faça tenha de ter conhecimento
     * algum sobre o Controler específico que implementa esta
     * interface.
     * 
     * Isto pode ser ignorado por quem decidir fazer uma classe que
     * implemente esta Interface e pode simplesmente instânciar novos
     * controlers não definidos no DefaultFactory se assim entender.
     */
    public enum TipoControler{
        CALCULADORA
    }
    
    /**
     * Sendo o Controler uma ponte entre duas entidades ele deve ter alguma
     * forma de distinguir se recebe um pedido acerca
     * de uma entidade ou outra.
     * 
     * Este enum define então nomes para o tipo de pedidos:
     * VIEW e MODEL.
     */
    public enum TipoPedido{
        VIEW, MODEL
    }
    
    /**
     * Recebe um Tuplo t que encapsula pedidos
     * efetuados ao Controler. Cabe às implementações
     * específicas desta Interface definir o conteúdo
     * e formato que este Tuplo deve ter.
     * 
     * @param t 
     */
    public void realizaPedido(Tuplo t);
    
    /**
     * Permite colonar o controler que implemente esta
     * interface. Note-se que, se alguma das entidades
     * presentes no controler tiver algum estado que seja
     * mutável então também deve ser colonado na implementação
     * deste método
     * 
     * @return um novo Controler
     */
    public Controler clone();
    
    /**
     * Design Pattern DefaultFactory
     * 
     * Esta classe permite instanciar um novo Controler sem que 
     * quem o faça tenha de ter conhecimento algum sobre o Controler 
     * específico que implementa esta interface.
     * 
     * Isto pode ser ignorado por quem decidir fazer uma classe que
     * implemente esta Interface e pode simplesmente instânciar novos
     * controlers não definidos no DefaultFactory se assim entender.
     */
    public class DefaultFactory {
        /**
         * Cria um Controler recebendo uma entidade
         * View v e Model m e um tipo de Controler tc que deve estar
         * definido no enum desta Interface.
         * 
         * @param v
         * @param m
         * @param tc
         * @return 
         */
        public static Controler create(View v, Model m, TipoControler tc) {
            switch(tc){
                case CALCULADORA:
                    return new CalculadoraControler(v,m);  
                default:
                    return null;
            }
        }
        
        /**
         * Cria um novo Controler a partir de um
         * Controler c argumento já existente.
         * 
         * @param c
         * @return 
         */
        public static Controler create(Controler c) {
            return c.clone();
        }
    }
}
