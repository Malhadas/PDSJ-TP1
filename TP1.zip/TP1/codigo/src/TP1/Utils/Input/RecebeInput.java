
package TP1.Utils.Input;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;
import TP1.Exceptions.GoBackException;
import TP1.Exceptions.RepeatException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * Classe usada para qualquer tipo de entrada de Input.
 */
public class RecebeInput implements Cloneable, Serializable{
    
    /**
     * Recebe uma linha lida em br
     * 
     * @param br
     * @return a String lida
     * @throws GoBackException caso seja escrito seta para trás seguido de -
     */
    public static String lerLinha(BufferedReader br) throws GoBackException{
        String input = null;
        try {
            input = br.readLine();
        } catch (IOException ex) {}
        
        if (input!=null){
            if(input.equals("<-"))
                throw new GoBackException();
        }
        
        return input;
    }

    /**
     * Recebe um inteiro lido em br
     * 
     * @param br
     * @return inteiro lido
     * @throws GoBackException caso seja escrito seta para trás seguido de -
     */
    public static int lerInt(BufferedReader br) throws GoBackException{
        String input;
        int numero = 0;
        try {
            input  = br.readLine();
            if (input!=null){
                if(input.equals("<-"))
                    throw new GoBackException();
            }
            numero = Integer.parseInt(input);
            if (numero<0) numero = 0;
        } catch (NumberFormatException | IOException ex) {}
    
        return numero;
    }

    /**
     * Recebe um long lido em br
     * 
     * @param br
     * @return long lido
     * @throws GoBackException caso seja escrito seta para trás seguido de -
     * @throws TP1.Exceptions.RepeatException caso seja um valor igual ou menor a zero
     */
    public static long lerLong(BufferedReader br) throws GoBackException, RepeatException{
        String input;
        long numero = 0;
        try {
            input  = br.readLine();
            if (input!=null){
                if(input.equals("<-"))
                    throw new GoBackException();
            }
            numero = Long.parseLong(input);
            if (numero<0) numero = 0;
        } catch (NumberFormatException | IOException ex) {
            throw new RepeatException();
        }
    
        return numero;
    }
    
    /**
     * Recebe um double lido em br
     * 
     * @param br
     * @return double lido
     * @throws GoBackException caso seja escrito seta para trás seguido de -
     */
    public static double lerDouble(BufferedReader br) throws GoBackException{
        String input;
        double numero = 0.0;
        try {
            input  = br.readLine();
            if (input!=null){
                if(input.equals("<-"))
                    throw new GoBackException();
            }
            numero = Double.parseDouble(input);
            if (numero<0) numero = 0.0;
        } catch (NumberFormatException | IOException ex) {}
    
        return numero;
    }
    
   /**
    * Espera por qualquer tipo de input em br até ser premido ENTER
    * e ignora
    * 
    * @param br 
    */
    public static void esperarEnter(BufferedReader br) {
        try{
            br.readLine();
        } catch (IOException ioe){
            Logger.getLogger(RecebeInput.class.getName()).log(Level.SEVERE, null, ioe);
        }
    }

    /**
     * Lê ficheiro argumento com stream e coloca numa lista
     * onde cada posição é uma linha do ficheiro em formato de string
     * 
     * @param fich
     * @return linhas em formato string numa lista
     */
    public static List<String> lerComStream(String fich){
        //ler ficheiro para stream, try-with-resources
        List<String> linhas = new ArrayList<>();
        
        try (Stream<String> stream = Files.lines(Paths.get(fich))) {
                stream.forEach(l -> linhas.add(l));
        } catch (IOException e) {}
        
        return linhas;
    }
    
    
}
