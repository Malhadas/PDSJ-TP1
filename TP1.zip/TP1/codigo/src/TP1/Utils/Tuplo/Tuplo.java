
package TP1.Utils.Tuplo;

/**
 * Classes que implementem esta interface identificam-se como classes que 
 * representam tuplos. Esta interface apresenta tuplos como objetos imutaveis.
 * Por consequencia entende-se que o conteudo de um tuplo imutável deve ser
 * tambem imutável por si só ou pelo menos que permaneça imutável
 * enquanto for parte de um Tuplo.
 * 
 * Note-se que o tuplo que esta interface define não tem um tipo 'rigido',
 * ou seja, diferentes valores do tuplo podem ter diferentes tipos sem ser
 * necessário 'casts' por parte do programador que use este código como uma
 * API.
 */
public interface Tuplo {

    /**
     * Uma implementação deste método irá retornar os tipos dos valores do tuplo em
     * questão. Sendo este um tuplo quão genérico possível então
     * diferentes valores do tuplo podem ter difrentes tipos.
     * 
     * @return tipos do tuplo
     */
    public TuploTipo getTipo();
    
    /**
     * Uma implementação deste método irá retornar o número de
     * elementos que o tuplo em questão tem.
     * 
     * @return número de elementos
     */
    public int tamanho();
    
    /**
     * Uma implementação deste método irá retornar o elemento do tuplo que
     * estiver na posição argumento i.
     * 
     * 
     * 
     * @param <T>
     * @param i
     * @return elemento na posicao i
     */
    public <T> T getValor(int i);

}