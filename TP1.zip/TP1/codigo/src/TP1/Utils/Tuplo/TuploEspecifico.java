
package TP1.Utils.Tuplo;

import java.util.ArrayList;
import java.util.List;

class TuploEspecifico implements Tuplo {

    /**
     * Definição dos tipos do tuplo
     */
    private final TuploTipo type;
    
    /**
     * Lista de valores do Tuplo ainda por fazer casting
     */
    private final List<Object> values;

    /**
     * Construtor que recebe os tipos encapsulados em type
     * e uma lista de valores values
     * 
     * @param type
     * @param values 
     */
    TuploEspecifico(TuploTipo type, List<Object> values) {
        this.type = type;
        if (values == null || values.isEmpty()) {
            this.values = new ArrayList<>();
        } else {
            this.values = new ArrayList<>(values.size());
            this.values.addAll(values);
        }
    }

    /**
     * Devolve os tipos dos valores do Tuplo. Sendo este um tuplo quão genérico possível então
     * diferentes valores do tuplo podem ter difrentes tipos.
     * 
     * @return tipos do tuplo
     */
    @Override
    public TuploTipo getTipo() {
        return type;
    }

    /**
     * Numero de elemntos do Tuplo
     * 
     * @return numero de elementos no tuplo
     */
    @Override
    public int tamanho() {
        return values.size();
    }

    /**
     * Obtém o valor na posição i e faz o cast antes
     * de o devolver de forma a permitir que quem use
     * um Tuplo não tenha necessidade de fazer nenhum
     * tipo de casts
     * 
     * @param <T>
     * @param i
     * @return valor na posição i com o cast já feito
     */
    @SuppressWarnings("unchecked")
    @Override
    public <T> T getValor(int i) {
        return (T) values.get(i);
    }

    /**
     * método equals
     * 
     * @param object
     * @return 
     */
    @Override
    public boolean equals(Object object) {
        if (object == null)   return false;
        if (this == object)   return true;

        if (! (object instanceof Tuplo))   return false;

        final Tuplo other = (Tuplo) object;
        if (other.tamanho() != tamanho())   return false;

        final int size = tamanho();
        for (int i = 0; i < size; i++) {
            final Object thisNthValue = getValor(i);
            final Object otherNthValue = other.getValor(i);
            if ((thisNthValue == null && otherNthValue != null) ||
                    (thisNthValue != null && ! thisNthValue.equals(otherNthValue))) {
                return false;
            }
        }

        return true;
    }

    
    /**
     * 
     * @return codigo hash
     */
    @Override
    public int hashCode() {
        int hash = 17;
        for (Object value : values) {
            if (value != null) {
                hash = hash * 37 + value.hashCode();
            }
        }
        return hash;
    }

    /**
     *
     * @return representação sobre forma de String 
     */
    @Override
    public String toString() {
        return values.toString();
    }
}