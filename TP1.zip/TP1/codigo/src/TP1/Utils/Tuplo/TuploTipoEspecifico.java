
package TP1.Utils.Tuplo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class TuploTipoEspecifico implements TuploTipo {

    /**
     * Lista de classes que estarão no Tuplo que este
     * TuploTipoEspecifico poderá gerar
     */
    final List<Class<?>> types;

    /**
     * Construtor de TuploTipoEspecifico.
     * Cria um TuploTipoEspecifico que pode gerar um Tuplo com
     * os tipos argumento
     * 
     * @param types 
     */
    TuploTipoEspecifico(Class<?>[] types) {
        this.types = (types != null ? Arrays.asList(types) : new ArrayList<>());
    }

    /**
     * número de classes fornecidas
     * 
     * @return número de classes 
     */
    @Override
    public int tamanho() {
        return types.size();
    }

    /**
     * 
     * @param i
     * @return classe do elemento que deverá ser inserido na posição i
     */
    @Override
    public Class<?> getTipo(int i) {
        return types.get(i);
    }

    /**
     * Gera um Tuplo com os valores argumento
     * 
     * @param values
     * @return Tuplo com valores argumento inseridos
     */
    @Override
    public Tuplo criar(Object... values) {
        List<Object> l = Arrays.asList(values);
        if ((l == null && types.isEmpty()) ||
                (l != null && l.size() != types.size())) {
            throw new IllegalArgumentException(
                    "Tamanho esperado: "+types.size()+", Tamanho obtido:  "+
                    (l == null ? "(null)" : l.size()));
        }

        if (l != null) {
            for (int i = 0; i < types.size(); i++) {
                final Class<?> nthType = types.get(i);
                final Object nthValue = l.get(i);
                if (nthValue != null && ! nthType.isAssignableFrom(nthValue.getClass())) {
                    throw new IllegalArgumentException(
                            "Valor no índice "+i+" ('"+
                            nthValue+"') deveria ser "+
                            nthType+", mas é " +
                            (nthValue != null ? nthValue.getClass() : "(null type)"));
                }
            }
        }
        
        return new TuploEspecifico(this, l);
    }
}
