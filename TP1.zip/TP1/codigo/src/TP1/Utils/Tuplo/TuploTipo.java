
package TP1.Utils.Tuplo;

/**
 * 
 * Esta Interface descreve o processo de criação de um Tuplo e permite
 * definir o seu tipo.
 * 
 * Note-se que os Tuplos aqui referidos são tidos como objetos imutaveis.
 * Por consequencia entende-se que o conteudo de um tuplo imutável deve ser
 * tambem imutável por si só ou pelo menos que permaneça imutável
 * enquanto for parte de um Tuplo.
 * 
 * Note-se que é esta interface que permite que diferentes valores do tuplo 
 * possam ter diferentes tipos sem ser necessário 'casts' por parte do 
 * programador que use este código como uma API.
 */
public interface TuploTipo {

    /**
     * 
     * @return Tamanho do Tuplo que este TuploTipo poderá criar 
     */
    public int tamanho();

    /**
     * 
     * @param i
     * @return class do valor que deve ser inserido na posição i 
     */
    public Class<?> getTipo(int i);

    /**
     * @param values
     * @return Tuplo com os valores argumentos inseridos
     * @throws IllegalArgumentException caso sejam dados um número de argumentos diferentes do tamanho do Tuplo ou com tipos diferentes dos definidos ao instanciar o TuplTipo especifico
     */
    public Tuplo criar(Object... values);

    public class DefaultFactory {
        public static TuploTipo create(final Class<?>... types) {
            return new TuploTipoEspecifico(types);
        }
    }

}
