/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TP1.Utils.ApresentacaoListada;

import TP1.Exceptions.PaginaInexistenteException;
import java.io.Serializable;
import java.util.Collection;
import java.util.List;

/**
 *
 * Descreve uma Apresentação listada que encapsula o conteúdo das suas páginas
 * e o returna sobre forma de lsitas de String para fácil acesso a
 * uma dada página ou a um elemento de uma página. 
 * 
 * Cabe ao programador que implemente esta interface decidir qual a melhor forma
 * de organizar as páginas em questão, duas hipóteses aconselháveis são: 1) um 
 * mapeamento entre o número de página e uma lista de elementos; 2) uma lista de páginas
 * em que cada lista de páginas é uma lista de elementos.
 * 
 * Sets podem ainda ser usados ao invés de listas de páginas de forma a criar
 * implementações que não aceitam elementos repetidos. Estruturas do tipo árvore
 * poderão também ser interessantes para proporcionar ordenações automáticas com
 * um comparador que pode ser dado como argumento ao construtor da classe que
 * implemente esta interface.
 */
public interface ApresentacaoInterface extends Cloneable, Serializable {

    /**
     * Constante que indica o número de elementos por página.
     * Não é aconselhável modificá-lo pois mais do que 20 elementos
     * é demasiado para apresentar num só ecrã sem que haja necessidade 
     * de fazer scroll do mesmo.
     */
    public static final int N_ELEM_POR_PAG = 20;    

    /**
     * Devolve uma lista de páginas onde cada página é uma lista de elementos sobre
     * forma de String.
     * 
     * @return lista de páginas onde cada página é uma lista de elementos sobre forma de String.
     */
    public List<List<String>> getPaginas();
    
    /**
     * 
     * @param pagina
     * @return Lista de elementos da página argumento
     * @throws PaginaInexistenteException se a página argumento não existir
     */
    public Collection<String> getPagina(int pagina) throws PaginaInexistenteException;
    
    /**
     * 
     * @param pagina
     * @return tamanho do maior elemento da pagina de id argumento
     */
    public int getMaxTam(int pagina);
    
    /**
     * 
     * @param pagina
     * @param linha
     * @return elemento na pagina arguemnto e na linha argumento
     * @throws PaginaInexistenteException caso a pagina argumento não exista
     */
    public String getElemento(int pagina, int linha) throws PaginaInexistenteException;
    
    /**
     * insere páginas argumento
     * 
     * @param dm 
     */
    public void setPaginas(Collection<Collection<String>> dm);
    
    /**
     * insere página argumento
     * 
     * @param pagina 
     */
    public void setPagina(Collection<String> pagina);
    
    /**
     * Adiciona elemento no fim da lista paginada
     * 
     * @param elemento 
     */
    public void add(String elemento);
    
    /**
     * 
     * @return número de páginas na lista paginada 
     */
    public int getNpaginas();
    
    /**
     * 
     * @return número de elementos na lista paginada 
     */
    public int getTotal();
    
    /**
     * 
     * @return número de linahs por pagina 
     */
    public int getNlinhasPpagina();
    
    /**
     * Usando os métodos recomecarApresentacao(), hasNext() and next()
     * é possível iterar ao longo das páginas, este método permite
     * saber se a apresentação já terminou.
     * 
     * @return true se ainda houver mais páginas a apresentar, false caso contrário 
     */
    public boolean hasNext();
    
    /**
     * 
     * @return próxima página da apresentação (ver método hasNext())
     * @throws PaginaInexistenteException caso não haja mais páginas
     */
    public Collection<String> next() throws PaginaInexistenteException;
    
    /**
     * Recomeçar apresentação (ver hasNext())
     */
    public void recomecarApresentacao();
    
    /**
     * colona a apresentação
     * 
     * @return Apresentação 
     */
    ApresentacaoInterface clone();
    
    /**
     * metodo equals
     * 
     * @param obj
     * @return 
     */
    @Override
    boolean equals(Object obj);
    
    /**
     * 
     * @return codigo hash 
     */
    @Override
    int hashCode();
    
    /**
     * 
     * @return apresentacao sobre fp«orma de String 
     */
    @Override
    String toString();
 
    /**
     * Design Pattern DefaultFactory
     * 
     * Esta classe permite instanciar uma nova ApresentaçãoInterface sem que 
     * quem o faça tenha de ter conhecimento algum sobre a Apresentação 
     * específica que implementa esta interface.
     * 
     * Isto pode ser ignorado por quem decidir fazer uma classe que
     * implemente esta Interface e pode simplesmente instânciar novas
     * Apresentações não definidas no DefaultFactory se assim entender.
     */
    public class DefaultFactory {
        
        /**
         * Instancia uma Apresentação apartir de uma collection de Strings
         * 
         * @param c
         * @return a nova Apresentação 
         */
        public static ApresentacaoInterface create(Collection<String> c) {
            return new Apresentacao(c);
        }
    }
}
