
package TP1.Utils.MetricasPerformance;

import static java.lang.System.nanoTime;

/**
 * Crono = mede um tempo entre start() e stop()
 * O tempo e medido em nanosegundos e convertido para 
 * um double que representa os segs na sua parte inteira.
 * 
 * @author FMM 
 * @version 1-2009
 *
 * Uso:
 * Crono.start();
 * Crono.stop();
 * Crono.print();
 */
public class Crono {
  /**
   * inicio
   */
  private static long inicio = 0L;
  
  /**
   * fim
   */
  private static long fim = 0L;
  
  /**
   * começar contagem de tempo
   */
  public static void start() { 
      fim = 0L; inicio = nanoTime();  
  }
  
  /**
   * 
   * @return tempo em segundos desde start()
   */
  public static double stop() { 
      fim = nanoTime();
      long elapsedTime = fim - inicio;
      // segundos
      return elapsedTime / 1.0E09;
  }
  
  /*
  * Tempo em segundos desde start() em formato String
  */
  public static String print() {
      return "" + stop();
  }

}
