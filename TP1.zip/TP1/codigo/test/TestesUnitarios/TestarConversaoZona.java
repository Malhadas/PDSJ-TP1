/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestesUnitarios;

import TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries.ConversaoZona;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalQuery;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 */
public class TestarConversaoZona {

    /**
     */
    @Test
    public void testarTemporalQueryConversaoZona() {
        LocalDateTime agora       = LocalDateTime.now();

        TemporalQuery<TemporalAccessor> tq = new ConversaoZona(ZoneId.of("Europe/Lisbon"),
                                                               ZoneId.of("America/Belize"));
        ZonedDateTime zdt2 = ZonedDateTime.from(agora.query(tq));
        ZonedDateTime zdt1 = ZonedDateTime.of(agora, ZoneId.of("Europe/Lisbon"));
        
        //Garantir que os objetos são diferentes já que têm zonas e offset diferentes
        assertFalse(zdt1.equals(zdt2));
        
        //mas garantir que são relativos ao mesmo instante 
        assertEquals(0, ChronoUnit.MINUTES.between(zdt1, zdt2));
    }
    
}
