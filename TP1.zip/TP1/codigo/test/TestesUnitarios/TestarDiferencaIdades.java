/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestesUnitarios;

import TP1.Main.ValoresFixos.IntervaloTempo;
import TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries.DiferencaIdades;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalQuery;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 */
public class TestarDiferencaIdades {

    /**
     * Test of queryFrom method, of class AteAniversario.
     */
    @Test
    public void testarTemporalQueryDiferencaIdadesAnos() {
        LocalDateTime data1 = LocalDateTime.of(1995,9,3,0,0,0);
        LocalDateTime data2 = data1.plus(3, ChronoUnit.YEARS);

        TemporalQuery<Long> tq = new DiferencaIdades(data1, IntervaloTempo.ANOS);
        long result = data2.query(tq);
        
        //garantir que há uma diferança de idades de 3 anos
        assertEquals(3, result);
    }
    
    @Test
    public void testarTemporalQueryDiferencaIdadesMeses() {
        LocalDateTime data1 = LocalDateTime.of(1995,9,3,0,0,0);
        LocalDateTime data2 = data1.plus(3, ChronoUnit.MONTHS);

        TemporalQuery<Long> tq = new DiferencaIdades(data1, IntervaloTempo.MESES);
        long result = data2.query(tq);
        
        //garantir que há uma diferança de idades de 3 meses
        assertEquals(3, result);
    }
    
        @Test
    public void testarTemporalQueryDiferencaIdadesDias() {
        LocalDateTime data1 = LocalDateTime.of(1995,9,3,0,0,0);
        LocalDateTime data2 = data1.plus(3, ChronoUnit.DAYS);

        TemporalQuery<Long> tq = new DiferencaIdades(data1, IntervaloTempo.DIAS);
        long result = data2.query(tq);
        
        //garantir que há uma diferança de idades de 3 dias
        assertEquals(3, result);
    }
    
        @Test
    public void testarTemporalQueryDiferencaIdadesSemanas() {
        LocalDateTime data1 = LocalDateTime.of(1995,9,3,0,0,0);
        LocalDateTime data2 = data1.plus(3, ChronoUnit.WEEKS);

        TemporalQuery<Long> tq = new DiferencaIdades(data1, IntervaloTempo.SEMANAS);
        long result = data2.query(tq);
        
        //garantir que há uma diferança de idades de 3 semanas
        assertEquals(3, result);
    }
    
    @Test
    public void testarTemporalQueryDiferencaIdadesHoras() {
        LocalDateTime data1 = LocalDateTime.of(1995,9,3,0,0,0);
        LocalDateTime data2 = data1.plus(3, ChronoUnit.HOURS);

        TemporalQuery<Long> tq = new DiferencaIdades(data1, IntervaloTempo.HORAS);
        long result = data2.query(tq);
        
        //garantir que há uma diferança de idades de 3 horas
        assertEquals(3, result);
    }
        @Test
    public void testarTemporalQueryDiferencaIdadesMinutos() {
        LocalDateTime data1 = LocalDateTime.of(1995,9,3,0,0,0);
        LocalDateTime data2 = data1.plus(3, ChronoUnit.MINUTES);

        TemporalQuery<Long> tq = new DiferencaIdades(data1, IntervaloTempo.MINUTOS);
        long result = data2.query(tq);
        
        //garantir que há uma diferança de idades de 3 minutos
        assertEquals(3, result);
    }
        @Test
    public void testarTemporalQueryDiferencaIdadesSegundos() {
        LocalDateTime data1 = LocalDateTime.of(1995,9,3,0,0,0);
        LocalDateTime data2 = data1.plus(3, ChronoUnit.SECONDS);

        TemporalQuery<Long> tq = new DiferencaIdades(data1, IntervaloTempo.SEGUNDOS);
        long result = data2.query(tq);
        
        //garantir que há uma diferança de idades de 3 segundos
        assertEquals(3, result);
    }
}
