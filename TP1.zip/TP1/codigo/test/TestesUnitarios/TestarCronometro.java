

package TestesUnitarios;

import TP1.Model.Modulos.Cronometro.Cronometro;
import TP1.Model.Modulos.Cronometro.CronometroLugares.CronometroCrescente;
import TP1.Model.Modulos.Cronometro.CronometroLugares.CronometroDecrescente;
import junit.framework.TestCase;
import org.junit.Test;

public class TestarCronometro extends TestCase {
    
    @Test
    public void testarCronometroCrescente() throws InterruptedException{
        
        Cronometro c = new CronometroCrescente();
        c.start();
        c.stop();

        String s1 = c.toString();

        c.stop();c.stop();c.stop();c.stop();c.stop();c.stop();c.stop();c.stop();c.stop();
        
        String s2 = c.toString();
        
        assertFalse(s1.length()>=s2.length());
    }
    
        @Test
    public void testarCronometroDecrescente() throws InterruptedException{
        
        Cronometro c = new CronometroDecrescente(90);
        c.start();
        
        c.stop();
        
        String s1 = c.toString();

        c.stop();c.stop();c.stop();c.stop();c.stop();c.stop();c.stop();c.stop();c.stop();
        
        String s2 = c.toString();
        
        assertFalse(s1.length()>=s2.length());
    }
}