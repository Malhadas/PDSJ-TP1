
package TestesUnitarios;

import TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries.DiferencaHoraEntreZonas;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.TemporalQuery;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 */
public class TestarDiferencaHoraEntreZonas {

    /**
     * garantir que a diferenca em minutos é a diferença de offset em minutos
     * (neste caso, como o offset de Europe/Lisbon é +00:00 e o de America/Belize é
     * de +06:00, então será uma diferença de 6*60 minutos
     */
    @Test
    public void testarTemporalQueryDiferencaEntreZonas() {
        LocalDateTime agora       = LocalDateTime.now();

        TemporalQuery<Duration> tq = new DiferencaHoraEntreZonas(ZoneId.of("Europe/Lisbon"),
                                                                 ZoneId.of("America/Belize"));
        long result = agora.query(tq).toMinutes();
        
        //garantir que a diferenca em minutos é a diferença de offset em minutos
        //(neste caso, como o offset de Europe/Lisbon é +00:00 e o de America/Belize é
        // de +06:00, então será uma diferença de 6*60 minutos
        assertEquals(6*60, result);
    }
    
}
