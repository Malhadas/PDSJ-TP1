
package TestesUnitarios;

import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import junit.framework.TestCase;
import org.junit.Test;

public class TestarTuplo extends TestCase {

    @Test
    public void testeCriarTriplo() {
        final TuploTipo tripletTuploTipo =
            TuploTipo.DefaultFactory.create(
                    Number.class,
                    String.class,
                    Character.class);

        final Tuplo t1 = tripletTuploTipo.criar(1, "um", 'a');
        assertEquals ((int) t1.getValor(0), 1);
        assertEquals (t1.getValor(1), "um");
        assertEquals ((char) t1.getValor(2), 'a');
    }

    @Test
    public void testeTiposErrados(){
        final TuploTipo tripletTuploTipo =
            TuploTipo.DefaultFactory.create(
                    Number.class,
                    String.class,
                    Character.class);
        
        try {
            final Tuplo terror = tripletTuploTipo.criar(1, 2, 3);
            fail("O tuplo devia ter falhado");
        } catch (IllegalArgumentException e) {
            
        }
    }
    
    @Test
    public void testeNelementosErrado(){
        final TuploTipo emptyTuploTipo =
            TuploTipo.DefaultFactory.create();
        
        try {
            final Tuplo terror = emptyTuploTipo.criar(1);
            fail("O tuplo devia ter falhado");
        } catch (IllegalArgumentException e) {

        }
    }
    
    @Test
    public void testeGetTipoErrado(){
        final TuploTipo tripletTuploTipo =
            TuploTipo.DefaultFactory.create(
                    Number.class,
                    String.class,
                    Character.class);
        
        try {
            final Tuplo t9 = tripletTuploTipo.criar(9, "nove", 'i');
            final String s = t9.getValor(0);
            fail("O get devia ter falhado");
        } catch (ClassCastException e) {

        }
    }

}