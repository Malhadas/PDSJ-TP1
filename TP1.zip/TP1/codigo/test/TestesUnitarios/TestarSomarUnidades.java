
package TestesUnitarios;

import TP1.Main.ValoresFixos.IntervaloTempo;
import TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries.SomarUnidades;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalQuery;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 */
public class TestarSomarUnidades {


    @Test
    public void testarTemporalQuerySomarUnidadesAnos() {
        LocalDateTime data1 = LocalDateTime.of(1995,9,3,0,0,0);

        TemporalQuery<TemporalAccessor> tq = new SomarUnidades(3,IntervaloTempo.ANOS);
        LocalDateTime result = LocalDateTime.from(data1.query(tq));
        
        //garantir que há uma diferança de 3 anos
        assertEquals(LocalDateTime.of(1998,9,3,0,0,0), result);
    }
    
    @Test
    public void testarTemporalQuerySomarUnidadesMeses() {
        LocalDateTime data1 = LocalDateTime.of(1995,9,3,0,0,0);

        TemporalQuery<TemporalAccessor> tq = new SomarUnidades(3,IntervaloTempo.MESES);
        LocalDateTime result = LocalDateTime.from(data1.query(tq));
        
        //garantir que há uma diferança de 3 meses
        assertEquals(LocalDateTime.of(1995,12,3,0,0,0), result);
    }

    @Test
    public void testarTemporalQuerySomarUnidadesDias() {
        LocalDateTime data1 = LocalDateTime.of(1995,9,3,0,0,0);

        TemporalQuery<TemporalAccessor> tq = new SomarUnidades(3,IntervaloTempo.DIAS);
        LocalDateTime result = LocalDateTime.from(data1.query(tq));
        
        //garantir que há uma diferança de 3 meses
        assertEquals(LocalDateTime.of(1995,9,6,0,0,0), result);
    }
}
