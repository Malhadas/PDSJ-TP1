/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestesUnitarios;

import TP1.Main.ValoresFixos.IntervaloTempo;
import TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries.SubtrairUnidades;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalQuery;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 */
public class TestarSubtrairUnidades {


    @Test
    public void testarTemporalQuerySomarUnidadesAnos() {
        LocalDateTime data1 = LocalDateTime.of(1995,9,3,0,0,0);

        TemporalQuery<TemporalAccessor> tq = new SubtrairUnidades(3,IntervaloTempo.ANOS);
        LocalDateTime result = LocalDateTime.from(data1.query(tq));
        
        //garantir que há uma diferança de 3 anos
        assertEquals(LocalDateTime.of(1992,9,3,0,0,0), result);
    }
    
    @Test
    public void testarTemporalQuerySomarUnidadesMeses() {
        LocalDateTime data1 = LocalDateTime.of(1995,9,3,0,0,0);

        TemporalQuery<TemporalAccessor> tq = new SubtrairUnidades(3,IntervaloTempo.MESES);
        LocalDateTime result = LocalDateTime.from(data1.query(tq));
        
        //garantir que há uma diferança de 3 meses
        assertEquals(LocalDateTime.of(1995,6,3,0,0,0), result);
    }

    @Test
    public void testarTemporalQuerySomarUnidadesDias() {
        LocalDateTime data1 = LocalDateTime.of(1995,9,3,0,0,0);

        TemporalQuery<TemporalAccessor> tq = new SubtrairUnidades(3,IntervaloTempo.DIAS);
        LocalDateTime result = LocalDateTime.from(data1.query(tq));
        
        //garantir que há uma diferança de 3 meses
        assertEquals(LocalDateTime.of(1995,8,31,0,0,0), result);
    }
}
