/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestesUnitarios;

import TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries.PagamentoSistematico;
import java.time.LocalDate;
import java.time.temporal.TemporalQuery;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 */
public class TestarPagamentoSistematico {

    /**
     * Test of queryFrom method
     */
    @Test
    public void testarTemporalQueryPagamentoSistematico() {
        LocalDate data1 = LocalDate.now();
        LocalDate data2 = data1.plusMonths(3);

        TemporalQuery<Double> tq = new PagamentoSistematico(31, 700);
        double result = data2.query(tq);
        
        assertEquals(3*700, result, 0.00001);
    }
    
    @Test
    public void testarTemporalQueryPagamentoSistematico2() {
        LocalDate data1 = LocalDate.now();
        LocalDate data2;
        
        if(data1.getDayOfMonth()<28) data2 = data1.withDayOfMonth(data1.lengthOfMonth());
        else data2 = data1.plusMonths(1);
            
        TemporalQuery<Double> tq = new PagamentoSistematico(28, 700);
        double result = data2.query(tq);
        
        assertEquals(700, result, 0.00001);
    }
    
    @Test
    public void testarTemporalQueryPagamentoSistematico3() {
        LocalDate data2 = LocalDate.now();

        TemporalQuery<Double> tq = new PagamentoSistematico(30, 700);
        double result = data2.query(tq);
        
        assertEquals(0, result, 0.00001);
    }
}
