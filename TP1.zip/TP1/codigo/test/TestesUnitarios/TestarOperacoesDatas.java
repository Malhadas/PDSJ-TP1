

package TestesUnitarios;

import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import junit.framework.TestCase;
import org.junit.Test;

public class TestarOperacoesDatas extends TestCase {
    
    
    @Test
    public void testarConversoesDatas(){
        LocalDateTime ldc = LocalDateTime.of(2017, Month.NOVEMBER, 04, 19, 30, 40);
        ZonedDateTime z = ldc.atZone(ZoneId.of("America/Belize"));
        z = z.minusSeconds(z.getOffset().getTotalSeconds());
        ZonedDateTime z2 = z.toLocalDateTime().atZone(ZoneId.of("Europe/Lisbon"));
        assertEquals(z2.toString(), "2017-11-05T01:30:40Z[Europe/Lisbon]");
    }
}