

package TestesUnitarios;

import TP1.Model.Modulos.AuxiliaresModulos.FormatacaoDeDatas;
import java.time.DateTimeException;
import junit.framework.TestCase;
import static junit.framework.TestCase.assertEquals;
import org.junit.Test;

public class TestarFormatacaoDeDatas extends TestCase {
                              
   @Test
   public void testarFormatacao(){   
       //Garantir coerência no formatador. Duas datas que representam o mesmo
       //momento, mas com formatações diferentes, devem resultar em duas
       //LocalDateTime iguais
        assertEquals(FormatacaoDeDatas.stringParaData("3-9-1995:3:2:1","d-M-uuuu:H:m:s"), 
                     FormatacaoDeDatas.stringParaData("3/9/1995/3:2:1","d/M/uuuu/H:m:s"));
    }
   
   @Test
   public void testarValidacaoDia(){                                                                                     
        try{
            FormatacaoDeDatas.stringParaData("33-9-1995:3:2:1","dd-M-uuuu:H:m:s");
            fail();
        } catch (DateTimeException ex){
            //deve dar exceção já que não existem meses ccom 33 dias
        }
    }
   
   @Test
   public void testarValidacaoMes(){                                                                                     
        try{
            FormatacaoDeDatas.stringParaData("3-90-1995:3:2:1","d-MM-uuuu:H:m:s");
            fail();
        } catch (DateTimeException ex){
            //deve dar exceção já que não existem anos com 90 meses
        }
    }
   
   @Test
   public void testarValidacaoAno(){                                                                                     
        try{
            FormatacaoDeDatas.stringParaData("3-9-9999999999999:3:2:1","d-M-uuuuuuuuuuuuu:H:m:s");
            fail();
        } catch (DateTimeException ex){
            //deve dar exceção já que este é um valor exageradamente grande para o ano
        }
    }
   
   @Test
   public void testarValidacaoHora(){                                                                                     
        try{
            FormatacaoDeDatas.stringParaData("3-3-1995:70:2:1","d-M-uuuu:HH:m:s");
            fail();
        } catch (DateTimeException ex){
            //deve dar exceção já que não existem dias com 70 horas
        }
    }
   
   @Test
   public void testarValidacaoMinuto(){                                                                                     
        try{
            FormatacaoDeDatas.stringParaData("3-9-1995:7:90:1","d-M-uuuu:H:mm:s");
            fail();
        } catch (DateTimeException ex){
            //deve dar exceção já que não existem horas com 90 minutos
        }
    }
   
   @Test
   public void testarValidacaoSegundo(){                                                                                     
        try{
            FormatacaoDeDatas.stringParaData("3-3-1995:7:9:78","d-M-uuuu:H:m:ss");
            fail();
        } catch (DateTimeException ex){
            //deve dar exceção já que não existem minutos com 78 segundos
        }
    }
   
   @Test
   public void testarValidacaoFebreiro(){                                                                                     
        try{
            FormatacaoDeDatas.stringParaData("30-2-1995:7:9:7","dd-M-uuuu:H:m:s");
            fail();
        } catch (DateTimeException ex){
            //deve dar exceção já que febreiro nunca tem 30 dias
        }
    }
   
    @Test
    public void testarValidacaoAnoBissexto(){                                                                                     
        try{
            FormatacaoDeDatas.stringParaData("29-2-2021:7:2:7","dd-M-uuuu:H:m:s");
            fail();
        } catch (DateTimeException ex){
            //deve dar exceção já que febreiro não tem 29 dias no ano
            //2021 já que este não é bissexto
        }
        
        try{
            FormatacaoDeDatas.stringParaData("29-2-2020:7:2:7","dd-M-uuuu:H:m:s");
        } catch (DateTimeException ex){
            //não deve dar exceção já que febreiro tem 29 dias no ano
            //2020 já que este é bissexto
            fail();
        }
    }
}