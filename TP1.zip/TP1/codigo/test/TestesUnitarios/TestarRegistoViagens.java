package TestesUnitarios;


import TP1.Model.Modulos.Viagens.RegistoViagens;
import TP1.Model.Modulos.Viagens.Viagem;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collections;
import java.util.List;
import static junit.framework.TestCase.assertEquals;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class Utilizadores.
 * 
 */
public class TestarRegistoViagens{

    private RegistoViagens a, c;
    
    
    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp(){
        Viagem v1  = new Viagem(ZoneId.of("Europe/Lisbon"), ZoneId.of("America/Belize"),Duration.ofMinutes(120), LocalDateTime.of(2017,4,3,8,5), 50);
        Viagem v2  = new Viagem(ZoneId.of("Europe/Lisbon"), ZoneId.of("America/Belize"),Duration.ofMinutes(300), LocalDateTime.of(2017,3,4,8,5), 100);
        Viagem v3  = new Viagem(ZoneId.of("Europe/Lisbon"), ZoneId.of("America/Belize"),Duration.ofMinutes(90), LocalDateTime.of(2016,3,4,8,5), 40);
        Viagem v4  = new Viagem(ZoneId.of("Europe/Lisbon"), ZoneId.of("America/Belize"),Duration.ofMinutes(10), LocalDateTime.of(2017,3,2,8,5), 90);
        Viagem v5  = new Viagem(ZoneId.of("Europe/Lisbon"), ZoneId.of("America/Belize"),Duration.ofMinutes(12), LocalDateTime.of(2018,3,4,8,5), 340);
        Viagem v6  = new Viagem(ZoneId.of("Europe/Lisbon"), ZoneId.of("America/Belize"),Duration.ofMinutes(70), LocalDateTime.of(2015,3,4,8,5), 800);
        Viagem v7  = new Viagem(ZoneId.of("Europe/Lisbon"), ZoneId.of("America/Belize"),Duration.ofMinutes(15), LocalDateTime.of(2012,3,4,8,5), 10);
        Viagem v8  = new Viagem(ZoneId.of("Europe/Lisbon"), ZoneId.of("America/Belize"),Duration.ofMinutes(60), LocalDateTime.of(2014,3,4,8,5), 5);
        Viagem v9  = new Viagem(ZoneId.of("Europe/Lisbon"), ZoneId.of("America/Belize"),Duration.ofMinutes(1), LocalDateTime.of(2011,3,4,8,5), 20);
        Viagem v10 = new Viagem(ZoneId.of("Europe/Lisbon"), ZoneId.of("America/Belize"),Duration.ofMinutes(900), LocalDateTime.of(2010,3,4,8,5), 0);
        
        a = new RegistoViagens();
        a.adicionaViagem(v1);
        a.adicionaViagem(v2);
        a.adicionaViagem(v3);
        a.adicionaViagem(v4);
        a.adicionaViagem(v5);
        a.adicionaViagem(v6);
        a.adicionaViagem(v7);
        a.adicionaViagem(v8);
        a.adicionaViagem(v9);
        a.adicionaViagem(v10);
        
        c = a.clone();
    }

    @Test
    public void testarGetListaViagens() {
        List<Viagem> l = a.getListaViagens();
        
        assertEquals(l.size(),10);
    }
    
    @Test
    public void testarListarViagensEntreDatas() {
       List<Viagem> l = a.getViagensEntreDatasDecrescente(LocalDateTime.of(2015,3,4,8,5), LocalDateTime.of(2020,3,4,8,5));
       List<Viagem> l2 = a.getViagensEntreDatasCrescente(LocalDateTime.of(2015,3,4,8,5), LocalDateTime.of(2020,3,4,8,5));
        
        assertEquals(l.size(),5);
        assertEquals(l2.size(),5);
        Collections.reverse(l);
        assertEquals(l,l2);
    }
    
    @Test
    public void testarTopPrecos() {
       List<Viagem> l = a.getTopViagensMaisBaratas(7);
       List<Viagem> l2 = a.getTopViagensMaisCaras(7);
        
        assertEquals(l.size(),7);
        assertEquals(l2.size(),7);
    }

    @Test
    public void testarTopDuracao() {
       List<Viagem> l = a.getTopViagensMaisCurtas(7);
       List<Viagem> l2 = a.getTopViagensMaisLongas(7);

        assertEquals(l.size(),7);
        assertEquals(l2.size(),7);
    }
    
    @Test
    public void testarDuracaoEntre() {
        long l = a.getMinutosEntreDatas(LocalDateTime.of(2015,3,4,8,5), LocalDateTime.of(2020,3,4,8,5));
        assertEquals(l,532);
    }
    
    @Test
    public void testarPrecoEntre() {
        double l = a.getPrecoEntreDatas(LocalDateTime.of(2015,3,4,8,5), LocalDateTime.of(2020,3,4,8,5));
        assertEquals(l,620.0);
    }
    
    
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown(){
          //Setting everything to null after each test 
         //allows for garbage collection to collect it
        //before the end of all test cases
        a = null;
        c = null;
    }
}
