/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestesUnitarios;

import TP1.Main.ValoresFixos.IntervaloTempo;
import TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries.AteAniversario;
import java.time.LocalDateTime;
import java.time.temporal.TemporalQuery;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 */
public class TestarAteAniversario {

    /**
     * Test of queryFrom method, of class AteAniversario.
     */
    @Test
    public void testarTemporalQueryAteAniversario() {
        LocalDateTime aniversario = LocalDateTime.of(1995,9,3,0,0,0);
        LocalDateTime agora       = LocalDateTime.now();

        TemporalQuery<Long> tq = new AteAniversario(IntervaloTempo.MESES);
        long result = aniversario.query(tq);
        
        long expectedResult = 0;
        int mes = agora.getMonthValue();
        int dia = agora.getDayOfMonth();
        
        if (mes <  9) expectedResult = 9-mes;
        if (mes >  9) expectedResult = (12-mes) + 9;
        if (mes == 9) expectedResult = 12;
        
        if (dia > 3) expectedResult -= 1;
        
        assertEquals(expectedResult, result);
    }
    
}
