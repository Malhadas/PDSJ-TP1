/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TestesUnitarios;

import TP1.Model.Modulos.AuxiliaresModulos.TemporalQueries.FiltroEntreDatas;
import TP1.Model.Modulos.Intervalos.IntervaloDatas;
import java.time.LocalDate;
import java.time.temporal.TemporalQuery;
import java.util.List;
import java.util.stream.Collectors;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 */
public class TestarFiltroEntreDatas {

    /**
     */
    @Test
    public void testarTemporalQueryFiltroEntreDatas() {
        
        LocalDate inicio  = LocalDate.of(2017, 1 , 1);
        LocalDate fim     = LocalDate.of(2017, 12, 1);
        IntervaloDatas id = new IntervaloDatas(inicio,fim);
        
        LocalDate d1 = LocalDate.of(2017,2,1);
        LocalDate d2 = LocalDate.of(2017,3,1);
        
        TemporalQuery<Boolean> tq = new FiltroEntreDatas(d1,d2);
        
        List<LocalDate> l1 = id.toList();
        List<LocalDate> l2 = id.stream()
                               .filter(ld -> ld.query(tq))
                               .collect(Collectors.toList());
        
        assertEquals(l1.size(), 335);
        assertEquals(l2.size(), 27);
    }
    
}
