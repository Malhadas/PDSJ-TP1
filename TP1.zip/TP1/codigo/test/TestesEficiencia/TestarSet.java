
package TestesEficiencia;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;
import TP1.Exceptions.GoBackException;
import TP1.Utils.MetricasPerformance.Crono;
import TP1.Utils.Input.RecebeInput;

public class TestarSet {
    
    public static void main(String[] args) {
        //Declara-se este buffered reader para que o mesmo não seja reinstânciado sempre que se pretende obter input do terminal.
        final BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        double tempo;
        int numero;
            try {
            System.out.println("==============================");
            System.out.println("=Testes de eficiência de Sets:");
            System.out.println("==============================");
            while(true){
                System.out.println("Escreva o número de elementos nos Sets para comparar eficiência.");
                System.out.println("Escreva \"<-\" ou algo que não seja um número para parar os testes de Sets.");
                System.out.print  ("Input: ");
                numero = RecebeInput.lerInt(br);
                System.out.println("");

                System.out.println("=======================================");
                System.out.println("= TESTE COM HASHSET                   =");
                Set<Integer>  hset  = new HashSet<>(numero);
                
                testaInserir(hset, numero);
                testaConsulta(hset, numero);
                testaModificar(hset);
                testaApagar(hset);
                
                System.out.println("= PRIMA ENTER PARA CONTINUAR...       =");
                System.out.println("=======================================");
                RecebeInput.esperarEnter(br);

                System.out.println("=======================================");
                System.out.println("= TESTE COM TREESET                   =");
                Set<Integer>      tSet      = new TreeSet<>();
                
                testaInserir(tSet, numero);
                testaConsulta(tSet, numero);
                testaModificar(tSet);
                testaApagar(tSet);
                
                System.out.println("= PRIMA ENTER PARA CONTINUAR...       =");
                System.out.println("=======================================");
                RecebeInput.esperarEnter(br);
                
                System.out.println("=======================================");
                System.out.println("= TESTE COM LINKEDHASHSET             =");
                Set<Integer> linkedSet = new LinkedHashSet<>(numero);
                
                testaInserir(linkedSet, numero);
                testaConsulta(linkedSet, numero);
                testaModificar(linkedSet);
                testaApagar(linkedSet);
                
                System.out.println("= PRIMA ENTER PARA CONTINUAR...       =");
                System.out.println("=======================================");
                RecebeInput.esperarEnter(br);

            }
        } catch(GoBackException gbe){
            //sair do ciclo, <- foi pressionado.
            System.out.println("Testes de eficiência de Sets terminados.");
        }
    }

    private static void testaInserir(Set<Integer> o, int numero) {
        Crono.start();
        Iterator it = o.iterator();
        
        for (int i = 0; i < numero; i++)
            o.add(i);
        double tempo = Crono.stop();
        
        System.out.println("-> Tempo para Adicionar "+numero+" elementos: "+(tempo*1000)+"ms / "+tempo+"s");
    }


    private static void testaConsulta(Set<Integer> o, int numero) {
        Integer valor;
        Iterator it = o.iterator();
        
        Crono.start();

        while(it.hasNext()){
            valor = (Integer) it.next();
        }
        double tempo = Crono.stop();
        
        System.out.println("-> Tempo para Consultar "+o.size()+" elementos: "+(tempo*1000)+"ms / "+tempo+"s");
    }

    private static void testaModificar(Set<Integer> o) {
        Integer valor;
        Iterator it = o.iterator();
        
        Crono.start();

        while(it.hasNext()){
            valor = (Integer) it.next();
            valor++;
        }
        double tempo = Crono.stop();
        
        System.out.println("-> Tempo para Modificar "+o.size()+" elementos: "+(tempo*1000)+"ms / "+tempo+"s");
    }

    private static void testaApagar(Set<Integer> o) {
        
        Crono.start();
        int i = 0;
        for (; i<o.size(); i++)
            o.remove(i);
        double tempo = Crono.stop();
        
        System.out.println("-> Tempo para Apagar "+i+" elementos: "+(tempo*1000)+"ms / "+tempo+"s");
    }
    
    
}