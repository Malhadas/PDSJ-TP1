
package TestesEficiencia;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Map;
import TP1.Exceptions.GoBackException;
import TP1.Utils.MetricasPerformance.Crono;
import TP1.Utils.Input.RecebeInput;

public class TestarMap {
    
    public static void main(String[] args) {
        //Declara-se este buffered reader para que o mesmo não seja reinstânciado sempre que se pretende obter input do terminal.
        final BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        double tempo;
        int numero;
            try {
            System.out.println("==============================");
            System.out.println("=Testes de eficiência de Maps:");
            System.out.println("==============================");
            while(true){
                System.out.println("Escreva o número de elementos nos Maps para comparar eficiência.");
                System.out.println("Escreva \"<-\" ou algo que não seja um número para parar os testes de Maps.");
                System.out.print  ("Input: ");
                numero = RecebeInput.lerInt(br);
                System.out.println("");

                System.out.println("=======================================");
                System.out.println("= TESTE COM TREEMAP                   =");
                Map<Integer,Integer>  treeMap  = new TreeMap<>();
                
                testaInserir(treeMap, numero);
                testaConsulta(treeMap, numero);
                testaModificar(treeMap);
                testaApagar(treeMap);
                
                System.out.println("= PRIMA ENTER PARA CONTINUAR...       =");
                System.out.println("=======================================");
                RecebeInput.esperarEnter(br);

                System.out.println("=======================================");
                System.out.println("= TESTE COM HASHMAP                   =");
                Map<Integer,Integer>      hashMap      = new HashMap<>(numero);
                
                testaInserir(hashMap, numero);
                testaConsulta(hashMap, numero);
                testaModificar(hashMap);
                testaApagar(hashMap);
                
                System.out.println("= PRIMA ENTER PARA CONTINUAR...       =");
                System.out.println("=======================================");
                RecebeInput.esperarEnter(br);
                
                System.out.println("=======================================");
                System.out.println("= TESTE COM LINKEDHASHMAP             =");
                Map<Integer,Integer> linkedMap = new LinkedHashMap<>(numero);
                
                testaInserir(linkedMap, numero);
                testaConsulta(linkedMap, numero);
                testaModificar(linkedMap);
                testaApagar(linkedMap);
                
                System.out.println("= PRIMA ENTER PARA CONTINUAR...       =");
                System.out.println("=======================================");
                RecebeInput.esperarEnter(br);

            }
        } catch(GoBackException gbe){
            //sair do ciclo, <- foi pressionado.
            System.out.println("Testes de eficiência de Maps terminados.");
        }
    }

    private static void testaInserir(Map<Integer,Integer> o, int numero) {
        Crono.start();
        
        for (int i = 0; i < numero; i++)
            o.put(i,i);
        double tempo = Crono.stop();
        
        System.out.println("-> Tempo para Adicionar "+numero+" elementos: "+(tempo*1000)+"ms / "+tempo+"s");
    }


    private static void testaConsulta(Map<Integer,Integer> o, int numero) {
        Integer valor;
        
        Crono.start();
        int i = 0;
        for(; i<o.size(); i++){
            valor = o.get(i);
        }
        double tempo = Crono.stop();
        
        System.out.println("-> Tempo para Consultar "+i+" elementos: "+(tempo*1000)+"ms / "+tempo+"s");
    }

    private static void testaModificar(Map<Integer,Integer> o) {
        Integer valor;
        
        Crono.start();
        int i = 0;
        for(; i<o.size(); i++){
            valor = o.get(i);
            valor++;
        }
        double tempo = Crono.stop();
        
        System.out.println("-> Tempo para Modificar "+i+" elementos: "+(tempo*1000)+"ms / "+tempo+"s");
    }

    private static void testaApagar(Map<Integer,Integer> o) {
        
        Crono.start();
        int i = 0;
        for (; i<o.size(); i++)
            o.remove(i);
        double tempo = Crono.stop();
        
        System.out.println("-> Tempo para Apagar "+i+" elementos: "+(tempo*1000)+"ms / "+tempo+"s");
    }
    
    
}