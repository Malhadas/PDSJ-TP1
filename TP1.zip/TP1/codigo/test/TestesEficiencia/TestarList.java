
package TestesEficiencia;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;
import java.util.Vector;
import TP1.Exceptions.GoBackException;
import TP1.Utils.MetricasPerformance.Crono;
import TP1.Utils.Input.RecebeInput;

public class TestarList {
    
    public static void main(String[] args) {
        //Declara-se este buffered reader para que o mesmo não seja reinstânciado sempre que se pretende obter input do terminal.
        final BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        double tempo;
        int numero;
            try {
            System.out.println("==============================");
            System.out.println("=Testes de eficiência de Lists:");
            System.out.println("==============================");
            while(true){
                System.out.println("Escreva o número de elementos nas Lists para comparar eficiência.");
                System.out.println("Escreva \"<-\" ou algo que não seja um número para parar os testes de Lists.");
                System.out.print  ("Input: ");
                numero = RecebeInput.lerInt(br);
                System.out.println("");

                System.out.println("=======================================");
                System.out.println("= TESTE COM ARRAYLIST                 =");
                ArrayList<Integer>  arrayList  = new ArrayList<>(numero); //Tem a vantagem de poder ser dado um tamanho como argumento do construtor
                
                testaInserir(arrayList, numero);
                testaConsulta(arrayList, numero);
                testaModificar(arrayList);
                testaApagar(arrayList);
                
                System.out.println("= PRIMA ENTER PARA CONTINUAR...       =");
                System.out.println("=======================================");
                RecebeInput.esperarEnter(br);

                System.out.println("=======================================");
                System.out.println("= TESTE COM STACK                     =");
                Stack<Integer>      stack      = new Stack<>();
                
                testaInserir(stack, numero);
                testaConsulta(stack, numero);
                testaModificar(stack);
                testaApagar(stack);
                
                System.out.println("= PRIMA ENTER PARA CONTINUAR...       =");
                System.out.println("=======================================");
                RecebeInput.esperarEnter(br);
                
                System.out.println("=======================================");
                System.out.println("= TESTE COM LINKEDLIST                =");
                LinkedList<Integer> linkedList = new LinkedList<>();
                
                testaInserir(linkedList, numero);
                testaConsulta(linkedList, numero);
                testaModificar(linkedList);
                testaApagar(linkedList);
                
                System.out.println("= PRIMA ENTER PARA CONTINUAR...       =");
                System.out.println("=======================================");
                RecebeInput.esperarEnter(br);
                
                System.out.println("=======================================");
                System.out.println("= TESTE COM VECTOR                    =");
                Vector<Integer>     vetor      = new Vector<>(numero); //Tem a vantagem de poder ser dado um tamanho como argumento do construtor
                                                               //  e de suportar sincronização
                
                testaInserir(vetor, numero);
                testaConsulta(vetor, numero);
                testaModificar(vetor);
                testaApagar(vetor);
                
                System.out.println("= PRIMA ENTER PARA CONTINUAR...       =");
                System.out.println("=======================================");
                RecebeInput.esperarEnter(br);

            }
        } catch(GoBackException gbe){
            //sair do ciclo, <- foi pressionado.
            System.out.println("Testes de eficiência de List terminados.");
        }
    }

    private static void testaInserir(List<Integer> o, int numero) {
        Crono.start();
        
        for (int i = 0; i < numero; i++)
            o.add(i);
        double tempo = Crono.stop();
        
        System.out.println("-> Tempo para Adicionar "+numero+" elementos: "+(tempo*1000)+"ms / "+tempo+"s");
    }


    private static void testaConsulta(List<Integer> o, int numero) {
        Integer valor;
        Iterator iterator = o.iterator();
        
        Crono.start();
        while (iterator.hasNext())
            valor = (Integer) iterator.next();
        double tempo = Crono.stop();
        
        System.out.println("-> Tempo para Consultar "+numero+" elementos: "+(tempo*1000)+"ms / "+tempo+"s");
    }

    private static void testaModificar(List<Integer> o) {
        Integer valor;
        
        Crono.start();
        int i = 0;
        for(; i<o.size(); i++){
            valor = o.get(i);
            valor++;
        }
        double tempo = Crono.stop();
        
        System.out.println("-> Tempo para Modificar "+i+" elementos: "+(tempo*1000)+"ms / "+tempo+"s");
    }

    private static void testaApagar(List<Integer> o) {
        
        Crono.start();
        int i = 0;
        for (; i<o.size(); i++)
            o.remove(i);
        double tempo = Crono.stop();
        
        System.out.println("-> Tempo para Apagar "+i+" elementos: "+(tempo*1000)+"ms / "+tempo+"s");
    }
    
    
}