
package TestesEficiencia;

import TP1.Utils.Input.RecebeInput;
import TP1.Utils.MetricasPerformance.Crono;
import TP1.Utils.Tuplo.Tuplo;
import TP1.Utils.Tuplo.TuploTipo;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class TestarTuplo {

    public static void main(String[] args) {
        //Declara-se este buffered reader para que o mesmo não seja reinstânciado sempre que se pretende obter input do terminal.
        final BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        double tempo;
        int numero;
        
        System.out.println("=================================");
        System.out.println("= Testes de eficiência de Tuplos:");
        System.out.println("=================================");
        
        System.out.println("Vamos testar com 74 elementos.\n");

        System.out.println("=======================================");
        System.out.println("= TESTE COM INTEIROS                  =");

        testaConsulta(testaInserir(0));

        System.out.println("= PRIMA ENTER PARA CONTINUAR...       =");
        System.out.println("=======================================");
        RecebeInput.esperarEnter(br);

        System.out.println("=======================================");
        System.out.println("= TESTE COM DOUBLES                   =");

        testaConsulta(testaInserir(1));

        System.out.println("= PRIMA ENTER PARA CONTINUAR...       =");
        System.out.println("=======================================");
        RecebeInput.esperarEnter(br);

        System.out.println("=======================================");
        System.out.println("= TESTE COM STRINGS                   =");

        testaConsulta(testaInserir(2));

        System.out.println("= PRIMA ENTER PARA CONTINUAR...       =");
        System.out.println("=======================================");
        RecebeInput.esperarEnter(br);
    }

    private static Tuplo testaInserir(int caso) {
        double tempo;
        Tuplo t = null;
        TuploTipo tt = TuploTipo.DefaultFactory.create(Object.class, Object.class,
                Object.class, Object.class,Object.class, Object.class,Object.class, Object.class,
                Object.class, Object.class,Object.class, Object.class,Object.class, Object.class,
                Object.class, Object.class,Object.class, Object.class,Object.class, Object.class,
                Object.class, Object.class,Object.class, Object.class,Object.class, Object.class,
                Object.class, Object.class,Object.class, Object.class,Object.class, Object.class,
                Object.class, Object.class,Object.class, Object.class,Object.class, Object.class,
                Object.class, Object.class,Object.class, Object.class,Object.class, Object.class,
                Object.class, Object.class,Object.class, Object.class,Object.class, Object.class,
                Object.class, Object.class,Object.class, Object.class,Object.class, Object.class,
                Object.class, Object.class,Object.class, Object.class,Object.class, Object.class,
                Object.class, Object.class,Object.class, Object.class,Object.class, Object.class,
                Object.class, Object.class,Object.class, Object.class,Object.class, Object.class);
        switch(caso){
            case 0:
                Crono.start();
                t = tt.criar(1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                               1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                               1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1);
                tempo = Crono.stop();
                System.out.println("-> Tempo para Adicionar 74 inteiros: "+(tempo*1000)+"ms / "+tempo+"s");
                break;
            case 1:
                Crono.start();
                t = tt.criar(1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,
                               1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,
                               1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2,1.2);
                tempo = Crono.stop();
                System.out.println("-> Tempo para Adicionar 74 doubles: "+(tempo*1000)+"ms / "+tempo+"s");
                break;
            case 2:
                Crono.start();
                t = tt.criar("1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1",
                               "1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1",
                               "1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1");
                tempo = Crono.stop();
                System.out.println("-> Tempo para Adicionar 74 Strings: "+(tempo*1000)+"ms / "+tempo+"s");
                break;
        }
        return t;
        
    }


    private static void testaConsulta(Tuplo t) {
        Object valor;
        
        Crono.start();

        for(int i=0;i<74;i++){
            valor = t.getValor(i);
        }
        double tempo = Crono.stop();
        
        System.out.println("-> Tempo para Consultar 74 elementos: "+(tempo*1000)+"ms / "+tempo+"s");
    }

}